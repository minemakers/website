execute as @e[type=area_effect_cloud,tag=end] at @s positioned ~ ~-5 ~ run fill ~-1 ~ ~-1 ~1 ~4 ~1 air

kill @e[type=area_effect_cloud,tag=powerup]
kill @e[type=area_effect_cloud,tag=end]
kill @e[type=area_effect_cloud,tag=powerup]
kill @e[type=armor_stand,tag=powerup]


scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 25 976 986 48 1019 air replace polished_andesite
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 48 976 986 58 1019 air replace polished_andesite
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 25 976 986 48 1019 air replace smooth_stone
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 48 976 986 58 1019 air replace smooth_stone
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 25 976 986 48 1019 air replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1016 48 976 986 58 1019 air replace oak_fence

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 21 972 1987 48 1010 air replace red_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 48 972 1987 58 1010 air replace red_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 21 972 1987 48 1010 air replace orange_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 48 972 1987 58 1010 air replace orange_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 21 972 1987 48 1010 air replace acacia_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2015 48 972 1987 58 1010 air replace acacia_fence

execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 31 984 2982 57 1023 air replace yellow_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 57 984 2982 67 1023 air replace yellow_terracotta
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 31 984 2982 57 1023 air replace yellow_concrete
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 57 984 2982 67 1023 air replace yellow_concrete
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 31 984 2982 57 1023 air replace dark_oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3010 57 984 2982 67 1023 air replace dark_oak_fence


fill 3000 34 1002 2998 81 1004 spruce_fence replace cobblestone_wall
fill 2004 23 990 2006 72 992 dark_oak_fence replace cobblestone_wall
fill 1000 25 998 1002 74 1000 birch_fence replace cobblestone_wall

fill 1014 24 998 1012 24 1000 air
fill 2014 20 990 2012 20 992 air
fill 3009 32 1002 3007 32 1004 air
