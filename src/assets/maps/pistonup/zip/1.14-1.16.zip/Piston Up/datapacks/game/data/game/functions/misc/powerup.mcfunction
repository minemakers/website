tag @s add this

execute as @e[type=armor_stand,tag=powerup,distance=..4] run data merge entity @s {CustomNameVisible:0,ArmorItems:[{},{},{},{id:"minecraft:coal_block",Count:1}]}
scoreboard players set @e[type=area_effect_cloud,tag=powerup,distance=..4,scores={powerup=..-1}] powerup 12

scoreboard players set !max powerup 0
execute as @a[gamemode=adventure,scores={turn=-10000..}] run scoreboard players operation @s powerup = @s points

scoreboard players operation !max powerup > @a turn
scoreboard players operation !max powerup *= multiply var

scoreboard players operation !max powerup += @a[tag=fisher,gamemode=adventure,scores={turn=0}] powerup
scoreboard players operation @a[gamemode=adventure,scores={turn=-10000..}] powerup -= !max powerup

tag @e[type=area_effect_cloud,tag=rand_powerup,sort=random,limit=1] add selected

execute as @s[scores={powerup=-25..}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random1] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup1
execute as @s[scores={powerup=-25..}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random2] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup2
execute as @s[scores={powerup=-25..}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random3] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup3

execute as @s[scores={powerup=-75..-26}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random1] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup2
execute as @s[scores={powerup=-75..-26}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random2] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup3
execute as @s[scores={powerup=-75..-26}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random3] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup4

execute as @s[scores={powerup=-100..-76}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random1] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup3
execute as @s[scores={powerup=-100..-76}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random2] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup4
execute as @s[scores={powerup=-100..-76}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random3] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup5

execute as @s[scores={powerup=-150..-101}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random1] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup4
execute as @s[scores={powerup=-150..-101}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random2] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup5
execute as @s[scores={powerup=-150..-101}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random3] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup6

execute as @s[scores={powerup=..-151}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random1] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup5
execute as @s[scores={powerup=..-151}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random2] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup6
execute as @s[scores={powerup=..-151}] as @e[type=area_effect_cloud,tag=selected,name=random] as @s[tag=random3] at @s run tag @a[tag=this,limit=1,sort=nearest] add powerup7


tag @e[type=area_effect_cloud,tag=rand_powerup] remove selected

team leave @s

title @a title [{"text":""}]
title @a times 5 50 20

execute as @s[tag=powerup1] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" stood on the ","color":"green","bold":"false"},{"text":"PistDown","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
execute as @s[tag=powerup1] run playsound minecraft:block.piston.contract master @a ~ ~ ~ 10000 0.6
execute as @s[tag=powerup1] run tp @a[x=1000.5,y=50,z=1000.5,tag=fisher,distance=..200,scores={turn=0}] 1001 25.6 999
execute as @s[tag=powerup1] run tp @a[x=2000.5,y=50,z=1000.5,tag=fisher,distance=..200,scores={turn=0}] 2005 23.6 991
execute as @s[tag=powerup1] run tp @a[x=3000.5,y=50,z=1000.5,tag=fisher,distance=..200,scores={turn=0}] 2999 34.6 1003
tag @s[tag=powerup1] remove powerup1

execute as @s[tag=powerup2] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" bumped on a ","color":"green","bold":"false"},{"text":"Nausea","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
execute as @s[tag=powerup2] run playsound minecraft:entity.player.breath master @a ~ ~ ~ 10000 0.7
execute as @s[tag=powerup2] run effect give @a[tag=fisher,scores={turn=0}] minecraft:nausea 14 0 true
tag @s[tag=powerup2] remove powerup2

execute as @s[tag=powerup3] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" installed the ","color":"green","bold":"false"},{"text":"Large fence","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var
execute as @s[tag=powerup3] run scoreboard players set @e[type=area_effect_cloud,name=random,tag=random3] powerup 200
execute as @s[tag=powerup3] run playsound minecraft:entity.wolf.growl master @a ~ ~ ~ 1000 1.6
execute as @s[tag=powerup3] as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1000 25 998 1002 74 1000 cobblestone_wall replace birch_fence
execute as @s[tag=powerup3] as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2004 23 990 2006 72 992 cobblestone_wall replace dark_oak_fence
execute as @s[tag=powerup3] as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3000 34 1002 2998 81 1004 cobblestone_wall replace spruce_fence
tag @s[tag=powerup3] remove powerup3

execute as @s[tag=powerup4] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" made the parkour easier!","color":"green","bold":"false"}]
execute as @s[tag=powerup4] run scoreboard players set @e[type=area_effect_cloud,name=random,tag=random4] powerup 10
execute as @s[tag=powerup4] run playsound minecraft:entity.generic.splash master @a ~ ~ ~ 1000 0.6
tag @s[tag=powerup4] remove powerup4

execute as @s[tag=powerup5] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" stumbled upon the ","color":"green","bold":"false"},{"text":"Invisibility","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
execute as @s[tag=powerup5] run playsound minecraft:entity.zombie_villager.cure master @a ~ ~ ~ 1000 1.7
effect give @s[tag=powerup5] minecraft:invisibility 7 0 true
tag @s[tag=powerup5] remove powerup5

execute as @s[tag=powerup6] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" found the ","color":"green","bold":"false"},{"text":"Invicibility","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
execute as @s[tag=powerup6] run playsound minecraft:music_disc.chirp master @a ~ ~ ~ 10000 2
execute as @s[tag=powerup6] run scoreboard players set @e[type=area_effect_cloud,name=random,tag=random6] powerup 141
effect give @s[tag=powerup6] minecraft:glowing 7 0 true
tag @s[tag=powerup6] remove powerup6


execute as @s[tag=powerup7] run title @a subtitle [{"selector":"@s","color":"dark_aqua","bold":"true"},{"text":" activated the ","color":"green","bold":"false"},{"text":"PistUp","color":"gold","bold":"true"},{"text":" powerup!","color":"green","bold":"false"}]
scoreboard players set @s[tag=powerup7] pistup 40
execute as @s[tag=powerup7] run playsound minecraft:entity.wolf.growl master @s ~ ~ ~ 1000 0.6
tag @s[tag=powerup7] remove powerup7

team join players @s

tag @s remove this
