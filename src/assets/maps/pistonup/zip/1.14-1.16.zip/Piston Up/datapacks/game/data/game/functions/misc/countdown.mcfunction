scoreboard players remove countdown var 1
title @a title [{"text":"Piston ","color":"dark_aqua","bold":"true"},{"text":"Up","color":"aqua"}]
title @a subtitle [{"text":"Game starts in ","color":"yellow"},{"score":{"name":"countdown","objective":"var"}}]
title @a times 0 80 20

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = countdown var
execute as @e[type=area_effect_cloud,tag=var,scores={var=..0}] at @s run function game:controller/start
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000
