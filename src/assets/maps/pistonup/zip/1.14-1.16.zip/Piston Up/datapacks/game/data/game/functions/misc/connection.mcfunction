title @s[scores={connection=1..}] title [{"text":"Welcome to","color":"gray"}]
title @s[scores={connection=1..}] subtitle [{"text":"Piston ","color":"dark_aqua","bold":"true"},{"text":"Up","color":"aqua"}]
playsound minecraft:block.piston.contract master @s[scores={connection=1..}] ~ ~ ~ 10000 1.2

spawnpoint @s -5 184 -4
effect clear @s
clear @s
team join players @s

scoreboard players operation @s var = status var
scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

tp @s[scores={var=..0}] -5 184.2 -4 90 -13
gamemode adventure @s[scores={var=..0}]

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run tp @a[scores={var=1..,connection=1..}] 986 35 1009 -125 20
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run tp @a[scores={var=1..,connection=1..}] 2025 37 1014 140 10
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run tp @a[scores={var=1..,connection=1..}] 2981 51 1015 -125 20
gamemode spectator @s[scores={var=1..}]

tag @s remove fisher
scoreboard players reset @s points
scoreboard players reset @s turn
scoreboard players reset @s connection
scoreboard players reset @s var
tag @s add initialized

xp add @s -1000 levels
