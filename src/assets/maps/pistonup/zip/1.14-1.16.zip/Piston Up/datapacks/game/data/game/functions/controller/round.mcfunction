scoreboard players reset * turn
execute as @a[gamemode=adventure] at @s run function game:misc/init_turn
scoreboard players remove @a[gamemode=adventure,scores={turn=1..}] turn 1



scoreboard players operation @e[type=area_effect_cloud,tag=var] var = round_max var
scoreboard players operation @e[type=area_effect_cloud,tag=var] var -= round var


scoreboard players add round var 1

tag @a remove fisher
tag @a[gamemode=adventure,scores={turn=0..}] add fisher

title @a title [{"text":"Round ","color":"aqua"},{"score":{"objective":"var","name":"round"},"color":"aqua"}]
playsound minecraft:block.piston.extend master @a ~ ~ ~ 10000 0.9

execute as @e[type=area_effect_cloud,tag=var,scores={var=..0}] at @s run function game:controller/stop
