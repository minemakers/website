team leave @a
title @a times 10 90 20

tellraw @a [{"text":"\n\n|====== ","color":"gray"},{"text":"Piston ","color":"dark_aqua","bold":"true"},{"text":"Up","color":"aqua","bold":"true"},{"text":" ======|\n"}]

scoreboard players set !test points -100000
scoreboard players operation !test points > @a[gamemode=adventure,scores={points=-100000..}] points
scoreboard players operation @a[gamemode=adventure] points -= !test points
tellraw @a [{"text":"▶ 1st","color":"yellow"},{"text":". ","color":"gray"},{"selector":"@a[gamemode=adventure,scores={points=0..}]"},{"text":": ","color":"gray"},{"score":{"objective":"points","name":"!test"},"color":"gray"},{"text":" points","color":"gray"}]
title @a title [{"selector":"@a[gamemode=adventure,scores={points=0..}]","color":"gold"}]
title @a subtitle [{"text":"won the game!","color":"yellow"}]

scoreboard players reset @a[scores={points=0..}] points
scoreboard players operation @a[gamemode=adventure,scores={points=-100000..}] points += !test points
scoreboard players set !test points -100000
scoreboard players operation !test points > @a[gamemode=adventure,scores={points=-100000..}] points
scoreboard players operation @a[gamemode=adventure,scores={points=-100000..}] points -= !test points
execute as @a[limit=1,gamemode=adventure,sort=nearest,scores={points=0..}] run tellraw @a [{"text":"▶ 2nd","color":"gold"},{"text":". ","color":"gray"},{"selector":"@a[gamemode=adventure,scores={points=0..}]"},{"text":": ","color":"gray"},{"score":{"objective":"points","name":"!test"},"color":"gray"},{"text":" points","color":"gray"}]

scoreboard players reset @a[gamemode=adventure,scores={points=0..}] points
scoreboard players operation @a[gamemode=adventure,scores={points=-100000..}] points += !test points
scoreboard players set !test points -100000
scoreboard players operation !test points > @a[gamemode=adventure,scores={points=-100000..}] points
scoreboard players operation @a[gamemode=adventure,scores={points=-100000..}] points -= !test points
execute as @a[limit=1,gamemode=adventure,sort=nearest,scores={points=0..}] run tellraw @a [{"text":"▶ 3rd","color":"red"},{"text":". ","color":"gray"},{"selector":"@a[gamemode=adventure,scores={points=0..}]"},{"text":": ","color":"gray"},{"score":{"objective":"points","name":"!test"},"color":"gray"},{"text":" points","color":"gray"}]

tellraw @a [{"text":"\n|===================|\n","color":"gray"}]

team join players @a
playsound minecraft:entity.wither.death master @a ~ ~ ~ 10000 2


scoreboard players set status var 0
function game:jump/reset
scoreboard players set @a connection 0
scoreboard players reset * turn
scoreboard players set round var 2
scoreboard players reset * points
