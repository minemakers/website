
execute as @s[type=player] run scoreboard players add @a[gamemode=adventure,scores={turn=..-1}] points 30
execute as @s[type=player] run scoreboard players add @a[gamemode=adventure,scores={turn=1..}] points 30

scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1


execute as @s[type=player] run scoreboard players operation @s points += timer var

tag @a remove fisher
tag @a[gamemode=adventure,scores={turn=0}] add fisher
#scoreboard players add @s[type=player] points 40

execute as @a[gamemode=adventure,tag=fisher,scores={turn=0}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,gamemode=adventure,sort=nearest,scores={turn=-10000..}] run scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1
tag @a remove finish

execute as @a[gamemode=adventure,tag=fisher,scores={turn=0}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,gamemode=adventure,sort=nearest,scores={turn=-10000..}] run scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1
tag @a remove finish

execute as @a[gamemode=adventure,tag=fisher,scores={turn=0}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,gamemode=adventure,sort=nearest,scores={turn=-10000..}] run scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1
tag @a remove finish

execute as @a[gamemode=adventure,tag=fisher,scores={turn=0}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,gamemode=adventure,sort=nearest,scores={turn=-10000..}] run scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1
tag @a remove finish

execute as @a[gamemode=adventure,tag=fisher,scores={turn=0}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,gamemode=adventure,sort=nearest,scores={turn=-10000..}] run scoreboard players remove @a[gamemode=adventure,scores={turn=-10000..}] turn 1
tag @a remove finish

stopsound @a master minecraft:record.chirp

effect clear @a minecraft:levitation

team leave @a
execute as @s[type=player] run tellraw @a [{"selector":"@s","color":"gold"},{"text":" has finished the parkour! ","color":"dark_aqua"},{"text":"(+","color":"gray"},{"score":{"name":"timer","objective":"var"},"color":"gray"},{"text":" points)","color":"gray"}]
execute as @s[type=area_effect_cloud] run tellraw @a [{"text":"Jumpers run out of time!","color":"dark_aqua"}]

team join players @a


execute as @a[gamemode=adventure,scores={turn=0..}] run tag @a[gamemode=adventure,scores={turn=-10000..}] add finish
execute as @a[tag=!finish,limit=1,sort=nearest,scores={turn=-10000..}] at @s run function game:controller/round
tag @a remove finish


scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run tp @a[gamemode=adventure] 1013 26.3 999 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run tp @a[gamemode=adventure] 2013 22.3 991 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run tp @a[gamemode=adventure] 3008 34.3 1003 5 -2

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 1001 25.5 999
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 2005 23.5 991
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 2999 34.5 1003
team leave @a
execute as @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] run tellraw @a [{"text":"▶ It's your turn to fish, ","color":"green"},{"selector":"@s","color":"red"},{"text":"!"}]
team join players @a

playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 100000 2

fill 3000 34 1002 2998 81 1004 spruce_fence replace cobblestone_wall
fill 2004 23 990 2006 72 992 dark_oak_fence replace cobblestone_wall
fill 1000 25 998 1002 74 1000 birch_fence replace cobblestone_wall

effect clear @a minecraft:nausea
effect clear @a minecraft:invisibility
effect clear @a minecraft:glowing

scoreboard players set @e[type=area_effect_cloud,name=random,scores={powerup=3..}] powerup 2
scoreboard players reset @a pistup

effect clear @a minecraft:levitation


scoreboard players set timer var 180

execute as @e[type=area_effect_cloud,tag=old_block] as @s[tag=marker] at @s run setblock ~ ~ ~ air 
tag @e[tag=old_block] add new_block
tag @e[tag=old_block] remove old_block
