scoreboard players set status var 1
scoreboard players set countdown var 6
effect give @a minecraft:resistance 1000000 255 true
effect give @a minecraft:invisibility 1000000 0 true
effect give @a minecraft:instant_health 1 100 true
effect give @a minecraft:weakness 1000000 100 true
effect give @a minecraft:levitation 1000000 255 true
title @a times 0 50 10


execute as @a at @s run function game:misc/rules
scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run tp @a 986 35 1009 -125 20
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run tp @a 2025 37 1014 140 10
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run tp @a 2981 51 1015 -125 20
