scoreboard players set @a[tag=!initialized] connection 1
execute as @a[scores={connection=0..}] at @s run function game:misc/connection

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = status var
execute as @e[type=area_effect_cloud,tag=var,scores={var=2..}] at @s run function game:game

scoreboard players remove second var 1
scoreboard players operation @e[type=area_effect_cloud,tag=var] var = second var
execute as @e[type=area_effect_cloud,tag=var,scores={var=..0}] at @s run function game:second


effect give @a minecraft:resistance 100000 255 true

execute as a439c59b-29d4-4390-9c99-2ea9589afb4c as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 41ed7f4a-e5dc-4c93-9893-4057077e553b as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as d9bcb348-cd32-4bb6-89db-8383b68ece05 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 05af30dc-4083-4fb7-9db8-d041d0369879 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as d70dabc4-f690-40d3-9ed1-970d0ab02818 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 082a19e0-9e3f-4ef0-a366-99bb1ed5de9c as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 5863f891-2c1a-4f27-9f7a-8a511e7eee79 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 05688f80-37b3-47a2-a44d-05491fc83520 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 296923b7-5800-4d8a-bc12-0e06002e68f9 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 417dfc9b-a30f-408f-9ba9-4a3c8cafb380 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as f2e15d7f-e23e-48d9-8621-0a2be9cb97d0 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as df7e8ab8-8e45-4da6-8b00-428f5787d18d as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as c285f8e6-2cd0-4d60-ba73-ceb0140e0626 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as d674d7df-9601-49d5-9165-d6581cffb137 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as ab86a9e2-0ec1-4812-b8a8-a173441807ec as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1
execute as 69a66db6-2bdd-4cbe-918e-f7c02ab424d9 as @s[tag=!invisible,gamemode=!spectator] at @s run particle minecraft:dust 255 0 0 1 ~ ~ ~ 0.2 0.2 0.2 0.1 1


execute as @a[gamemode=spectator] at @s as @s[y=0,dy=-50] run tp @s ~ 1 ~


#/summon minecraft:area_effect_cloud 0 100 0 {CustomName:"var",Duration:2147483647,Tags:["var"]}



kill @e[type=item,tag=!invulnerable]

scoreboard players reset @a[nbt={OnGround:1b}] nofall
scoreboard players add @a[nbt=!{OnGround:1b}] nofall 1
execute as @a[scores={nofall=9..},nbt=!{OnGround:1b}] at @s unless block ~.3 ~-1 ~.3 air unless block ~-.3 ~-1 ~-.3 air unless block ~-.3 ~-1 ~.3 air unless block ~.3 ~-1 ~-.3 air run effect give @s minecraft:slow_falling 1 0 true
execute as @a[scores={nofall=20..},nbt=!{OnGround:1b}] at @s unless block ~.3 ~-2 ~.3 air unless block ~-.3 ~-2 ~-.3 air unless block ~-.3 ~-2 ~.3 air unless block ~.3 ~-2 ~-.3 air run effect give @s minecraft:slow_falling 1 0 true
execute as @a[nbt={OnGround:1b}] run effect clear @s slow_falling