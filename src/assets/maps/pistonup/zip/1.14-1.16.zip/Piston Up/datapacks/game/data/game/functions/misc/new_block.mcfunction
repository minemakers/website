scoreboard players set new_block var 2

tag @e[type=area_effect_cloud,tag=new_block,limit=1,sort=random] add selected_block


scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=orange] at @s run setblock ~ ~ ~ smooth_stone 
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=purple] at @s run setblock ~ ~ ~ polished_andesite 

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=orange] at @s run setblock ~ ~ ~ orange_terracotta 
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=purple] at @s run setblock ~ ~ ~ red_terracotta 

execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=orange] at @s run setblock ~ ~ ~ yellow_concrete 
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] as @s[tag=purple] at @s run setblock ~ ~ ~ yellow_terracotta 


execute as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] at @s run playsound minecraft:entity.item.pickup master @a ~ ~ ~ 1 0
execute as @e[tag=selected_block,type=area_effect_cloud,limit=1,sort=nearest] at @s run particle minecraft:sweep_attack ~ ~ ~ 0 0 0 0 1 force @a
execute as @e[type=area_effect_cloud,tag=selected_block] run tag @s[tag=new_block] add old_block
execute as @e[type=area_effect_cloud,tag=selected_block] run tag @s[tag=new_block] remove new_block
tag @e[type=area_effect_cloud,tag=selected_block] remove selected_block
