fill 60 6 30 100 17 -24 air
fill 60 18 30 100 29 -24 air
fill 60 30 30 100 41 -24 air
fill 60 42 30 100 53 -24 air

execute as @e[type=area_effect_cloud,tag=end] at @s run function game:jump/reset


tag @e[type=area_effect_cloud,name=random,tag=selected] remove selected
tag @e[type=area_effect_cloud,name=random,tag=!selected,limit=1,sort=random] add selected

execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random1] run clone 9 6 -92 34 14 -77 62 6 -2 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random1] run setblock 70 14 -2 air 
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random2] run clone 11 6 -51 33 16 -34 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random3] run clone 11 6 -11 33 13 8 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random3] run setblock 67 13 -1 air 
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random4] run clone 11 6 29 33 15 47 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random5] run clone 11 6 69 34 16 88 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random6] run clone -29 6 -91 -7 16 -74 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random7] run clone -29 6 -51 -5 15 -34 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random8] run clone -29 6 -11 -7 13 4 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random9] run clone -29 6 29 -6 17 46 64 6 -1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random10] run clone -29 6 69 -7 13 83 64 6 -1 masked

summon minecraft:area_effect_cloud 65 12 0 {Tags:["layer2"]}
execute as @e[type=area_effect_cloud,tag=layer2] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer2] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer2] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer2] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer2] at @s if block ~ ~ ~ oak_fence run tp @s ~ ~1 ~

tag @e[type=area_effect_cloud,name=random,tag=selected] remove selected
tag @e[type=area_effect_cloud,name=random,tag=!selected,limit=1,sort=random] add selected

execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random1] as @e[type=area_effect_cloud,tag=layer2] at @s run clone 12 13 -110 34 24 -90 ~ ~-1 ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random2] as @e[type=area_effect_cloud,tag=layer2] at @s run clone 12 16 -70 32 23 -50 ~ ~ ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random3] as @e[type=area_effect_cloud,tag=layer2] at @s run clone 12 12 -30 32 22 -10 ~ ~-1 ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random4] as @e[type=area_effect_cloud,tag=layer2] at @s run clone 12 13 10 32 22 30 ~ ~-1 ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random4] as @e[type=area_effect_cloud,tag=layer2] at @s run fill ~ ~1 ~ ~ ~9 ~ air
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random5] as @e[type=area_effect_cloud,tag=layer2] at @s run clone 12 16 50 32 23 70 ~ ~ ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random6] as @e[type=area_effect_cloud,tag=layer2] at @s run clone -28 15 -111 -8 25 -90 ~ ~ ~-21 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random7] as @e[type=area_effect_cloud,tag=layer2] at @s run clone -28 15 -67 -8 24 -50 ~ ~ ~-17 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random8] as @e[type=area_effect_cloud,tag=layer2] at @s run clone -28 12 -30 -7 24 -10 ~ ~ ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random9] as @e[type=area_effect_cloud,tag=layer2] at @s run clone -28 17 10 -8 25 30 ~ ~ ~-20 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random9] as @e[type=area_effect_cloud,tag=layer2] at @s run fill ~ ~1 ~-1 ~ ~8 ~-1 air
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random10] as @e[type=area_effect_cloud,tag=layer2] at @s run clone -28 13 50 -7 21 70 ~ ~ ~-20 masked

summon minecraft:area_effect_cloud 85 18 0 {Tags:["layer3"]}
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ air run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=layer3] at @s if block ~ ~ ~ oak_fence run tp @s ~ ~1 ~

tag @e[type=area_effect_cloud,name=random,tag=selected] remove selected
tag @e[type=area_effect_cloud,name=random,tag=!selected,limit=1,sort=random] add selected

execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random1] as @e[type=area_effect_cloud,tag=layer3] at @s run clone 7 22 -91 35 34 -72 ~-25 ~-2 ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random2] as @e[type=area_effect_cloud,tag=layer3] at @s run clone 7 22 -51 34 29 -33 ~-25 ~-1 ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random3] as @e[type=area_effect_cloud,tag=layer3] at @s run clone 7 22 -11 33 31 10 ~-25 ~ ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random4] as @e[type=area_effect_cloud,tag=layer3] at @s run clone 7 19 29 32 26 48 ~-25 ~-3 ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random5] as @e[type=area_effect_cloud,tag=layer3] at @s run clone 7 22 69 34 33 87 ~-25 ~ ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random6] as @e[type=area_effect_cloud,tag=layer3] at @s run clone -33 24 -90 -8 36 -69 ~-25 ~ ~ masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random7] as @e[type=area_effect_cloud,tag=layer3] at @s run clone -33 24 -51 -6 36 -34 ~-25 ~ ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random8] as @e[type=area_effect_cloud,tag=layer3] at @s run clone -33 24 -11 -7 37 8 ~-25 ~ ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random9] as @e[type=area_effect_cloud,tag=layer3] at @s run clone -33 24 29 -8 31 47 ~-25 ~ ~-1 masked
execute as @e[type=area_effect_cloud,name=random,tag=selected] as @s[tag=random10] as @e[type=area_effect_cloud,tag=layer3] at @s run clone -33 18 69 -7 31 88 ~-25 ~-3 ~-1 masked

execute as @e[type=area_effect_cloud,tag=layer2] at @s run setblock ~ ~ ~ magenta_wool 
execute as @e[type=area_effect_cloud,tag=layer3] at @s run setblock ~ ~ ~ magenta_wool 


#setblock 85 7 -3 minecraft:fence
#setblock 85 8 -5 minecraft:fence
#setblock 85 8 -7 minecraft:fence
#setblock 83 8 -7 minecraft:fence
#setblock 83 8 -5 minecraft:fence

#execute @e[type=area_effect_cloud,name=random,tag=selected,c=1] ~ ~ ~ detect 85 7 -1 wool 2 setblock 85 8 -3 wool 1
#execute @e[type=area_effect_cloud,name=random,tag=selected,c=1] ~ ~ ~ detect 85 7 -1 wool 2 fill 85 9 -7 83 9 -5 wool 2

#execute @e[type=area_effect_cloud,name=random,tag=selected,c=1] ~ ~ ~ detect 85 7 -1 wool 1 setblock 85 8 -3 wool 2
#execute @e[type=area_effect_cloud,name=random,tag=selected,c=1] ~ ~ ~ detect 85 7 -1 wool 1 fill 85 9 -7 83 9 -5 wool 1

#setblock 84 10 -6 minecraft:bedrock
#setblock 84 11 -6 minecraft:redstone_wire



scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 6 30 100 17 -30 polished_andesite replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 18 30 100 29 -30 polished_andesite replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 30 30 100 41 -30 polished_andesite replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 42 30 100 53 -30 polished_andesite replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 6 30 100 17 -30 smooth_stone replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 18 30 100 29 -30 smooth_stone replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 30 30 100 41 -30 smooth_stone replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 60 42 30 100 53 -30 smooth_stone replace orange_wool

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 6 30 100 17 -30 red_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 18 30 100 29 -30 red_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 30 30 100 41 -30 red_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 42 30 100 53 -30 red_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 6 30 100 17 -30 orange_terracotta replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 18 30 100 29 -30 orange_terracotta replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 30 30 100 41 -30 orange_terracotta replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 42 30 100 53 -30 orange_terracotta replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 6 30 100 17 -30 acacia_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 18 30 100 29 -30 acacia_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 30 30 100 41 -30 acacia_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 60 42 30 100 53 -30 acacia_fence replace oak_fence

execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 6 30 100 17 -30 yellow_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 18 30 100 29 -30 yellow_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 30 30 100 41 -30 yellow_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 42 30 100 53 -30 yellow_terracotta replace magenta_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 6 30 100 17 -30 yellow_concrete replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 18 30 100 29 -30 yellow_concrete replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 30 30 100 41 -30 yellow_concrete replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 42 30 100 53 -30 yellow_concrete replace orange_wool
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 6 30 100 17 -30 dark_oak_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 18 30 100 29 -30 dark_oak_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 30 30 100 41 -30 dark_oak_fence replace oak_fence
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 60 42 30 100 53 -30 dark_oak_fence replace oak_fence

fill 60 6 30 100 17 -30 air replace bedrock
fill 60 18 30 100 29 -30 air replace bedrock
fill 60 30 30 100 41 -30 air replace bedrock
fill 60 42 30 100 53 -30 air replace bedrock

tag @e[type=item,nbt={Item:{id:"minecraft:redstone"}}] add marker
execute as @e[type=item,tag=marker] at @s run summon item_frame ~ ~ ~ {Tags:["marker"]}
kill @e[type=item,tag=marker]
execute as @e[type=item_frame,tag=marker] at @s run summon area_effect_cloud ~ ~-1.9375 ~ {CustomName:"\"marker\"",Tags:["powerup","marker"],Duration:2147483647}
execute as @e[type=area_effect_cloud,tag=powerup] at @s if block ~ ~-1 ~ lime_wool run data merge entity @s {Tags:["end","marker"]}
kill @e[type=item_frame,tag=marker]


tag @e[type=item,nbt={Item:{id:"minecraft:stone_button"}}] add marker
execute as @e[type=item,tag=marker] at @s run summon item_frame ~ ~ ~ {Tags:["marker"]}
kill @e[type=item,tag=marker]
execute as @e[type=item_frame,tag=marker] at @s run summon area_effect_cloud ~ ~-1.9375 ~ {CustomName:"\"marker\"",Tags:["new_block","marker","orange"],Duration:2147483647}
kill @e[type=item_frame,tag=marker]

tag @e[type=item,nbt={Item:{id:"minecraft:oak_button"}}] add marker
execute as @e[type=item,tag=marker] at @s run summon item_frame ~ ~ ~ {Tags:["marker"]}
kill @e[type=item,tag=marker]
execute as @e[type=item_frame,tag=marker] at @s run summon area_effect_cloud ~ ~-1.9375 ~ {CustomName:"\"marker\"",Tags:["new_block","marker","purple"],Duration:2147483647}
kill @e[type=item_frame,tag=marker]




execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @e[type=area_effect_cloud,tag=end] at @s positioned ~-1 ~-5 ~-1 run clone 51 1 -20 53 5 -18 ~ ~ ~
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @e[type=area_effect_cloud,tag=end] at @s positioned ~-1 ~-5 ~-1 run clone 51 1 -16 53 5 -14 ~ ~ ~
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @e[type=area_effect_cloud,tag=end] at @s positioned ~-1 ~-5 ~-1 run clone 51 1 -12 53 5 -10 ~ ~ ~


execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run clone 56 6 -19 90 28 20 984 24 980 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run clone 56 29 -19 90 45 20 984 47 980 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @e[type=area_effect_cloud,tag=marker] at @s run tp @s ~928 ~18 ~999

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run clone 56 6 -19 90 28 20 1984 20 972 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run clone 56 29 -19 90 45 20 1984 43 972 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @e[type=area_effect_cloud,tag=marker] at @s run tp @s ~1928 ~14 ~991

execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run clone 56 6 -19 90 28 20 2979 32 984 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run clone 56 29 -19 90 45 20 2979 55 984 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @e[type=area_effect_cloud,tag=marker] at @s run tp @s ~2923 ~26 ~1003



execute as @e[type=area_effect_cloud,tag=powerup] at @s run summon armor_stand ~ ~-1.2 ~ {DisabledSlots:2039583,CustomName:"{\"text\":\"PowerUp\",\"color\":\"dark_aqua\",\"bold\":true}",CustomNameVisible:0,NoGravity:1,NoBasePlate:1,Invisible:1,Invulnerable:1,ArmorItems:[{},{},{},{id:"minecraft:coal_block",Count:1}],Tags:["powerup"]}
scoreboard players set @e[type=area_effect_cloud,tag=powerup] powerup 6
