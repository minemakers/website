title @a subtitle [{"text":"The Game has just started!","color":"yellow"}]
title @a times 0 50 10
scoreboard players set status var 2
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 10000
effect clear @a
clear @a
effect give @a minecraft:weakness 1000000 100 true
effect give @a minecraft:resistance 1000000 255 true
effect give @a minecraft:jump_boost 2 255 true

scoreboard players set round var 0
scoreboard players set @a[gamemode=adventure] points 0

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run tp @a 1013 28 999 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run tp @a 2013 24 991 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run tp @a 3008 36 1003 5 -2

function game:jump/generate
function game:controller/round


tag @a remove fisher
tag @a[scores={turn=0..}] add fisher

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 1001 25.5 999
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 2005 23.5 991
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s run tp @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] 2999 34.5 1003

tellraw @a [{"text":"▶ It's your turn to fish, ","color":"dark_aqua"},{"selector":"@a[tag=fisher,limit=1,sort=nearest,scores={turn=0}]","color":"red"},{"text":"!"}]

playsound minecraft:entity.squid.ambient master @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] ~ ~ ~ 10000 1.4
playsound minecraft:entity.chicken.egg master @a[tag=!fisher,scores={turn=-10000..}] ~ ~ ~ 10000

scoreboard players set timer var 180
