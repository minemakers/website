tag @s add this

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = round_max var
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run scoreboard players set round_max var 3
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run scoreboard players set round_max var 5
execute as @e[type=area_effect_cloud,tag=var,scores={var=5}] run scoreboard players set round_max var 2


execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @e[type=area_effect_cloud,tag=display_round] run data merge entity @s {CustomName:"\"3 Rounds\""}
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @e[type=area_effect_cloud,tag=display_round] run data merge entity @s {CustomName:"\"5 Rounds\""}
execute as @e[type=area_effect_cloud,tag=var,scores={var=5}] as @e[type=area_effect_cloud,tag=display_round] run data merge entity @s {CustomName:"\"2 Rounds\""}

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s run playsound minecraft:entity.experience_orb.pickup master @a[tag=this] ~ ~ ~ 1000 0.95
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s run playsound minecraft:entity.experience_orb.pickup master @a[tag=this] ~ ~ ~ 1000 1
execute as @e[type=area_effect_cloud,tag=var,scores={var=5}] at @s run playsound minecraft:entity.experience_orb.pickup master @a[tag=this] ~ ~ ~ 1000 0.9

tag @s remove this
