scoreboard players add @a[scores={turn=1..}] turn 1
scoreboard players add @s turn 1
