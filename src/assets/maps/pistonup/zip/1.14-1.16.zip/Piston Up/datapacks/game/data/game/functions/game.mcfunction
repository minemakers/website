scoreboard players set @e[type=area_effect_cloud,tag=var] var 0
execute as @a[gamemode=adventure,scores={turn=-1000..}] run scoreboard players add @e[type=area_effect_cloud,tag=var] var 1
execute as @e[type=area_effect_cloud,tag=var,scores={var=..1}] at @s run function game:controller/stop


tag @a[x=2993.5,y=15,z=996.5,dx=12,dy=2,dz=0] add score_point
tag @a[x=2992.5,y=15,z=997.5,dx=14,dy=2,dz=2] add score_point
tag @a[x=2992.5,y=15,z=1000.5,dx=13,dy=2,dz=0] add score_point
tag @a[x=2994.5,y=15,z=1001.5,dx=11,dy=2,dz=0] add score_point
tag @a[x=2992.5,y=15,z=1006.5,dx=13,dy=2,dz=0] add score_point
tag @a[x=2994.5,y=15,z=1005.5,dx=11,dy=2,dz=0] add score_point
tag @a[x=2995.5,y=15,z=1002.5,dx=10,dy=2,dz=2] add score_point
tag @a[x=2992.5,y=15,z=1007.5,dx=4,dy=2,dz=3] add score_point
tag @a[x=2992.5,y=15,z=1007.5,dx=4,dy=2,dz=3] add score_point
tag @a[x=1994.5,y=8,z=981.5,dx=20,dy=2,dz=20] add score_point
execute as @a at @s if block ~ ~ ~ water run tag @s add score_point

tag @a[gamemode=adventure] remove onGround
tag @a[gamemode=adventure,nbt={OnGround:1b}] add onGround

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~-.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~-.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~-.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~.40 #game:arena1 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~-.40 #game:arena1 run tag @s remove onGround

execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~-.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~-.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~-.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~.40 #game:arena2 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~-.40 #game:arena2 run tag @s remove onGround

execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~-.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~-.40 ~-.5 ~.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~.40 ~-.5 ~-.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~-.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~-.40 ~-1 ~.40 #game:arena3 run tag @s remove onGround
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[gamemode=adventure] at @s if block ~.40 ~-1 ~-.40 #game:arena3 run tag @s remove onGround

scoreboard players reset @a[tag=!onGround] onground
scoreboard players add @a[tag=onGround] onground 1
tag @a[tag=onGround,scores={onground=..3}] remove onGround

execute as @e[type=area_effect_cloud,tag=end] at @s run tag @a[tag=onGround,distance=..5] remove onGround

tag @a[tag=score_point] add onGround




scoreboard players remove @e[type=area_effect_cloud,name=random,scores={powerup=1..}] powerup 1
execute as @e[type=area_effect_cloud,name=random,tag=random3,scores={powerup=1}] at @s as @e[type=area_effect_cloud,tag=var,scores={var=1}] run fill 1000 25 998 1002 74 1000 birch_fence replace cobblestone_wall
execute as @e[type=area_effect_cloud,name=random,tag=random3,scores={powerup=1}] at @s as @e[type=area_effect_cloud,tag=var,scores={var=2}] run fill 2004 23 990 2006 72 992 dark_oak_fence replace cobblestone_wall
execute as @e[type=area_effect_cloud,name=random,tag=random3,scores={powerup=1}] at @s as @e[type=area_effect_cloud,tag=var,scores={var=3}] run fill 3000 34 1002 2998 81 1004 spruce_fence replace cobblestone_wall



execute as @e[type=area_effect_cloud,name=random,tag=random4,scores={powerup=1..}] at @s run function game:misc/new_block
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=1,score_var=1] ~ ~ ~ particle dragonbreath 1001 8 999 3 0 3 0.01 50 force
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=1,score_var=1] ~ ~ ~ scoreboard players tag @a[x=996,y=7,z=994,dx=10,dy=1,dz=10] add onGround
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=2,score_var=2] ~ ~ ~ particle dragonbreath 2005 14 991 3 0 3 0.01 50 force
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=2,score_var=2] ~ ~ ~ scoreboard players tag @a[x=2001,y=13,z=987,dx=8,dy=1,dz=8] add onGround
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=3,score_var=3] ~ ~ ~ particle dragonbreath 2999 19 1003 2 0 2 0.01 30 force
#execute @e[type=area_effect_cloud,name=random,tag=random4,score_powerup_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=var,score_var_min=3,score_var=3] ~ ~ ~ scoreboard players tag @a[x=2995,y=19,z=999,dx=8,dy=1,dz=8] add onGround

execute as @e[type=area_effect_cloud,name=random,tag=random6,scores={powerup=1}] run stopsound @a master minecraft:music_disc.chirp

tag @a[tag=invisible] remove invisible
tag @a[nbt={ActiveEffects:[{Id:14b}]}] add invisible

tag @a[tag=invulnerable] remove invulnerable
tag @a[nbt={ActiveEffects:[{Id:24b}]}] add invulnerable
execute as @a[tag=invulnerable] at @s run particle minecraft:dust 255 0 0 1 ~ ~0.3 ~ 0.1 0.6 0.1 100 5
execute as @a[tag=invulnerable] at @s as @a[tag=!invulnerable,distance=..1] at @s run playsound minecraft:block.piston.contract master @a ~ ~ ~ 1 1.3
execute as @a[tag=invulnerable] at @s as @a[gamemode=adventure,tag=!invulnerable,distance=..1,y_rotation=-45..45] at @s run tp @s ~ ~ ~1
execute as @a[tag=invulnerable] at @s as @a[gamemode=adventure,tag=!invulnerable,distance=..1,y_rotation=45..135] at @s run tp @s ~-1 ~ ~
execute as @a[tag=invulnerable] at @s as @a[gamemode=adventure,tag=!invulnerable,distance=..1,y_rotation=135..225] at @s run tp @s ~ ~ ~-1
execute as @a[tag=invulnerable] at @s as @a[gamemode=adventure,tag=!invulnerable,distance=..1,y_rotation=225..315] at @s run tp @s ~1 ~ ~

execute as @a[tag=invulnerable] at @s run kill @e[type=fishing_bobber,distance=..2]



execute as @a[tag=score_point,gamemode=adventure] at @s run scoreboard players add @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] points 25

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[tag=score_point,gamemode=adventure] at @s run particle minecraft:rain ~ ~20 ~ 0.1 20 0.1 0.1 250 force
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[tag=score_point,gamemode=adventure] at @s run particle minecraft:lava ~ ~20 ~ 0.1 20 0.1 0.1 100 force
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[tag=score_point,gamemode=adventure] at @s run particle minecraft:poof ~ ~20 ~ 0.1 20 0.1 0.1 250 force

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @a[tag=score_point,gamemode=adventure] at @s run playsound minecraft:entity.generic.splash master @a ~ ~ ~ 10000
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @a[tag=score_point,gamemode=adventure] at @s run playsound minecraft:entity.generic.extinguish_fire master @a ~ ~ ~ 10000
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @a[tag=score_point,gamemode=adventure] at @s run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 10000 1.5

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run tp @a[gamemode=adventure,tag=onGround] 1013 26.3 999 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run tp @a[gamemode=adventure,tag=onGround] 2013 22.3 991 5 -2
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run tp @a[gamemode=adventure,tag=onGround] 3008 34.3 1003 5 -2


tag @a[tag=score_point] remove score_point


execute as @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] at @s run summon area_effect_cloud ~ 0 ~ {Tags:["test_tp_fisher"]}
tag @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] add retp_fisher
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s as @e[x=1001.5,y=0,z=999.5,type=area_effect_cloud,tag=test_tp_fisher,distance=..0.05] at @s run tag @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] remove retp_fisher
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s as @e[x=2005.5,y=0,z=991.5,type=area_effect_cloud,tag=test_tp_fisher,distance=..0.05] at @s run tag @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] remove retp_fisher
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s as @e[x=2999.5,y=0,z=1003.5,type=area_effect_cloud,tag=test_tp_fisher,distance=..0.05] at @s run tag @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] remove retp_fisher

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s as @a[tag=retp_fisher,limit=1,sort=nearest,scores={turn=0}] at @s run tp @s 1001.5 ~ 999.5
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] at @s as @a[tag=retp_fisher,limit=1,sort=nearest,scores={turn=0}] at @s run tp @s 2005.5 ~ 991.5
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] at @s as @a[tag=retp_fisher,limit=1,sort=nearest,scores={turn=0}] at @s run tp @s 2999.5 ~ 1003.5

kill @e[type=area_effect_cloud,tag=test_tp_fisher]

effect give @a[tag=fisher,limit=1,sort=nearest,scores={turn=0}] minecraft:jump_boost 1 255 true


effect clear @a[scores={turn=0}] minecraft:levitation

tag @a[tag=sneaking] remove sneaking
tag @a[tag=fisher,scores={sneak=1..}] add sneaking

effect give @a[tag=!sneaking,scores={turn=0}] minecraft:levitation 100000 5 true
effect give @a[tag=sneaking,scores={turn=0}] minecraft:levitation 10000 245 true

execute as @a[tag=sneaking,scores={turn=0}] at @s unless block ~ ~-1.5 ~ air run effect clear @s levitation
execute as @a[tag=sneaking,scores={turn=0}] at @s unless block ~ ~-1.5 ~ air run effect give @s minecraft:levitation 100000 5 true

scoreboard players reset @a[scores={sneak=1..}] sneak

execute as @e[type=area_effect_cloud,tag=end] at @s as @a[gamemode=adventure,distance=..2] at @s run function game:jump/finish

tag @a add giveRod
tag @a[tag=fisher,scores={turn=0},nbt={Inventory:[{id:"minecraft:fishing_rod",Slot:0b}]}] remove giveRod
clear @a[tag=giveRod] fishing_rod
replaceitem entity @a[tag=giveRod,scores={turn=0}] hotbar.0 fishing_rod{Damage:0s,Unbreakable:1b,HideFlags:1023,display:{Name:"{\"text\":\"Fishing Rod\",\"color\":\"gold\",\"italic\":false}"}} 1


execute as @e[type=area_effect_cloud,tag=powerup,scores={powerup=0}] at @s as @e[type=armor_stand,tag=powerup,distance=..2] run data merge entity @s {CustomNameVisible:1,ArmorItems:[{},{},{},{id:"minecraft:emerald_block",Count:1}]}
scoreboard players set @e[type=area_effect_cloud,tag=powerup,scores={powerup=0}] powerup -1
execute as @e[type=area_effect_cloud,tag=powerup,scores={powerup=-1}] at @s as @e[type=armor_stand,tag=powerup,distance=..2] at @s run particle minecraft:happy_villager ~ ~1.7 ~ 0.15 0.15 0.15 0.1 1
execute as @e[type=area_effect_cloud,tag=powerup,scores={powerup=-1}] at @s as @a[gamemode=adventure,distance=..1,scores={turn=-10000..}] at @s run function game:misc/powerup

scoreboard players remove @a[gamemode=adventure,scores={pistup=1..}] pistup 1

execute as @a[scores={pistup=36}] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 10000 0.3
execute as @a[scores={pistup=24}] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 10000 0.67
execute as @a[scores={pistup=12}] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 10000 0.9

execute as @a[scores={pistup=0}] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 10000 1.6
execute as @a[scores={pistup=0}] at @s run playsound minecraft:entity.generic.explode master @s ~ ~ ~ 1000 0.1
execute as @a[scores={pistup=0}] at @s run particle minecraft:poof ~ ~ ~ 0.3 0.3 0.3 0.1 50
effect give @a[scores={pistup=0}] minecraft:levitation 1 28 true
scoreboard players reset @a[scores={pistup=0}] pistup


title @a[scores={turn=1..}] actionbar [{"score":{"name":"timer","objective":"var"},"color":"white","italic":"true"},{"text":" seconds remaining"}]
title @a[scores={turn=..-1}] actionbar [{"score":{"name":"timer","objective":"var"},"color":"white","italic":"true"},{"text":" seconds remaining"}]

title @a[tag=fisher,scores={turn=0}] actionbar {"text":"Crouch to move down","color":"white","italic":"true"}



kill @e[x=1013.5,y=28,z=999.5,type=fishing_bobber,distance=..2]
kill @e[x=2013.5,y=24,z=991.5,type=fishing_bobber,distance=..2]
kill @e[x=3008.5,y=36,z=1003.5,type=fishing_bobber,distance=..2]
