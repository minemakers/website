scoreboard players set @e[type=area_effect_cloud,tag=var] var 0
execute as @a[gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=var] var 1
execute as @e[type=area_effect_cloud,tag=var,scores={var=..1}] run tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"}]
execute as @e[type=area_effect_cloud,tag=var,scores={var=..1}] at @s run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute as @e[type=area_effect_cloud,tag=var,scores={var=2..}] at @s run function game:controller/countdown
