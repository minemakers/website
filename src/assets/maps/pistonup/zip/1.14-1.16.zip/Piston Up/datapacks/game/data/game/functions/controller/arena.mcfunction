scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var
execute as @e[type=area_effect_cloud,tag=var,scores={var=4..}] run scoreboard players set arena var 1
execute as @e[type=area_effect_cloud,tag=var,scores={var=..0}] run scoreboard players set arena var 3
scoreboard players operation @e[type=area_effect_cloud,tag=var] var = arena var

fill -19 178 -34 -44 196 26 air

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] run clone 57 7 -83 80 24 -26 -42 178 -33 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] run clone 57 51 -83 80 68 -26 -42 178 -33 masked
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run clone 57 29 -83 80 46 -26 -42 178 -33 masked

execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] as @e[type=area_effect_cloud,tag=display_arena] run data merge entity @s {CustomName:"{\"text\":\"Coliseum\",\"color\":\"yellow\",\"bold\":true}"}
execute as @e[type=area_effect_cloud,tag=var,scores={var=3}] as @e[type=area_effect_cloud,tag=display_arena] run data merge entity @s {CustomName:"{\"text\":\"Piston Up Factory\",\"color\":\"yellow\",\"bold\":true}"}
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] as @e[type=area_effect_cloud,tag=display_arena] run data merge entity @s {CustomName:"{\"text\":\"39-X Launch Pad\",\"color\":\"yellow\",\"bold\":true}"}

kill @e[type=item,tag=!invulnerable]

playsound minecraft:block.stone_button.click_on master @s ~ ~ ~ 1000 1.2
