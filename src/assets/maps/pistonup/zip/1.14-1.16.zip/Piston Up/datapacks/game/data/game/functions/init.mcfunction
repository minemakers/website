scoreboard objectives add connection minecraft.custom:minecraft.leave_game

scoreboard objectives add var dummy
scoreboard objectives add random dummy
