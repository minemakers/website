scoreboard players set second var 20

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = countdown var
execute as @e[type=area_effect_cloud,tag=var,scores={var=1..6}] at @s run function game:misc/countdown

effect give @a minecraft:saturation 1000000 100 true

scoreboard players remove @e[type=area_effect_cloud,tag=powerup,scores={powerup=1..}] powerup 1

particle minecraft:angry_villager 11 186.7 2 0.4 0 0.4 0.1 1
execute as @e[name=Maxo6,type=armor_stand] at @s positioned ~ ~1.7 ~.7 run particle minecraft:note ~ ~ ~ .1 .1 .1 1 1 force
execute as @e[name=doll,type=armor_stand] at @s run particle minecraft:happy_villager ~ ~1.3 ~ 0.2 0.2 0.2 0.1 2
particle minecraft:portal 11 185 -10 0.3 0.3 0.3 0.1 10



scoreboard players operation @e[type=area_effect_cloud,tag=var] var = timer var
execute as @e[type=area_effect_cloud,tag=var,scores={var=1}] at @s run function game:jump/finish


scoreboard players operation @e[type=area_effect_cloud,tag=var] var = status var
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run scoreboard players remove timer var 1
execute as @e[type=area_effect_cloud,tag=var,scores={var=2}] run scoreboard players remove new_block var 1

scoreboard players operation @e[type=area_effect_cloud,tag=var] var = new_block var
execute as @e[type=area_effect_cloud,tag=var,scores={var=0}] at @s run function game:misc/new_block
#function game:misc/new_block
