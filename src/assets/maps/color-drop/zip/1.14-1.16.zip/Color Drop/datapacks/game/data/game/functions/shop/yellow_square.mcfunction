
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[scores={points=..89}] run tellraw @s {"text":"Sorry, you don't have enough points to buy the Big Yellow Square!","color":"red"}
execute as @s[scores={points=..89}] run playsound minecraft:entity.item.break master @s ~ ~ ~ 10000 1

execute as @s[scores={points=90..}] run tellraw @s {"text":"You have just bought Big Yellow Square!","color":"green"}
execute as @s[scores={points=90..}] run playsound minecraft:entity.witch.drink master @s ~ ~ ~ 10000 2
execute as @s[scores={points=90..},team=p1] run fill 1007 105 975 1010 103 975 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p2] run fill 990 105 975 993 103 975 minecraft:yellow_terracotta replace #game:stained_terracotta 
execute as @s[scores={points=90..},team=p3] run fill 975 105 993 975 103 990 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p4] run fill 975 105 1010 975 103 1007 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p5] run fill 993 105 1025 990 103 1025 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p6] run fill 1010 105 1025 1007 103 1025 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p7] run fill 1025 105 1007 1025 103 1010 minecraft:yellow_terracotta replace #game:stained_terracotta
execute as @s[scores={points=90..},team=p8] run fill 1025 105 990 1025 103 993 minecraft:yellow_terracotta replace #game:stained_terracotta 
execute as @s[scores={points=90..}] run scoreboard players remove @s points 90
