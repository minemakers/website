
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[nbt=!{Inventory:[{Slot:2b}]}] run function game:shop/lives
execute as @s[nbt=!{Inventory:[{Slot:3b}]}] run function game:shop/blindness
execute as @s[nbt=!{Inventory:[{Slot:4b}]}] run function game:shop/yellow_square
execute as @s[nbt=!{Inventory:[{Slot:5b}]}] run function game:shop/freeze
execute as @s[nbt=!{Inventory:[{Slot:6b}]}] run function game:shop/colored_square

execute as @s[nbt=!{Inventory:[{Slot:8b}]}] run tag @s add next_round
execute as @s[nbt=!{Inventory:[{Slot:8b}]}] run playsound minecraft:entity.villager.yes master @s ~ ~ ~ 100000
execute as @s[nbt=!{Inventory:[{Slot:8b}]}] run clear @s