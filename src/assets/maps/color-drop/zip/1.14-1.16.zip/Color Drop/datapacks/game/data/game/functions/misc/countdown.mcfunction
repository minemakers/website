
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players remove game_timer const 60

title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"game_timer","objective":"const"}},{"text":" seconds"}]
execute if score game_timer const = #1 const run title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"game_timer","objective":"const"}},{"text":" second"}]
title @a title [{"text":"Round ","color":"green","bold":"true"},{"score":{"name":"game_round","objective":"const"}}]

scoreboard players add game_timer const 60
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000
title @a times 0 40 10