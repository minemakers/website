
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players remove second const 1
execute if score second const <= null const run function game:second

execute if score game_timer const <= #-2 const if score game_timer const > #-5 const run function game:misc/countblock

execute as @a[scores={pickaxe=1..}] run function game:mine/generic


execute as @e[type=area_effect_cloud,tag=falling_block] at @s if blocks ~ ~1 ~ ~ ~2 ~ 0 0 0 all run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if blocks ~ ~1 ~ ~ ~2 ~ 0 0 0 all run tp @s ~ ~1 ~

#execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~1 ~ #game:stained_terracotta run tag @s add shift_cancel
#ADD DOUBLE AREA EFFECT CLOUD INSTANT POSITION IF CLONE / CHANGE CLONE DECALAGE TO CONSTANT WHEN NO FALLING SAND

execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:red_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:red_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:yellow_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:yellow_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:lime_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:lime_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:light_blue_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:light_blue_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:purple_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:purple_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:brown_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:brown_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ minecraft:black_terracotta run summon minecraft:falling_block ~ ~1 ~ {DropItem:1,BlockState:{Name:"minecraft:black_terracotta"},Time:1}
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~ ~ air if block ~ ~1 ~ #game:stained_terracotta run setblock ~ ~1 ~ air

execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~1 ~ #game:stained_terracotta run tp @s ~ ~1 ~
execute as @e[type=area_effect_cloud,tag=falling_block] at @s if block ~ ~1 ~ #game:stained_terracotta run tp @s ~ ~1 ~

execute as @e[type=area_effect_cloud,tag=falling_block] at @s run tp @s ~ ~.5 ~

execute positioned 900 108 900 run kill @e[type=area_effect_cloud,tag=falling_block,dx=200,dz=200,dy=100]

execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-9 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~-1 ~ ~ ~-1 ~6 ~ ~ ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-8 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~-2 ~ ~ ~-1 ~6 ~ ~-1 ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-7 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~-3 ~ ~ ~-1 ~6 ~ ~-2 ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-6 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~-4 ~ ~ ~-1 ~6 ~ ~-3 ~ ~ replace move

execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-2 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~1 ~ ~ ~1 ~6 ~ ~ ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-3 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~2 ~ ~ ~1 ~6 ~ ~ ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-4 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~3 ~ ~ ~1 ~6 ~ ~ ~ ~ replace move
execute at @e[tag=clone_ns] positioned ~-1 ~-3 ~-1 unless entity @e[dx=-11,dy=12,dz=2,type=!player] positioned ~-5 ~5 ~1 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~4 ~ ~ ~1 ~6 ~ ~ ~ ~ replace move


execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~9 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~1 ~ ~6 ~1 ~ ~ ~ replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~8 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~2 ~ ~6 ~1 ~ ~ ~ replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~7 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~3 ~ ~6 ~1 ~ ~ ~ replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~6 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~4 ~ ~6 ~1 ~ ~ ~ replace move

execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~2 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~-1 ~ ~6 ~-1 ~ ~ ~ replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~3 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~-2 ~ ~6 ~-1 ~ ~ ~-1 replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~4 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~-3 ~ ~6 ~-1 ~ ~ ~-2 replace move
execute at @e[tag=clone_we] positioned ~-1 ~-3 ~1 unless entity @e[dz=11,dy=12,dx=2,type=!player] positioned ~1 ~5 ~5 if blocks ~ ~ ~ ~ ~6 ~ 0 0 0 all run clone ~ ~ ~-4 ~ ~6 ~-1 ~ ~ ~-3 replace move

execute if score game_timer const matches 1..60 as @a[gamemode=adventure,nbt=!{Inventory:[{Slot:2b},{Slot:3b},{Slot:4b},{Slot:5b},{Slot:6b},{Slot:8b}]},tag=!next_round,nbt={Inventory:[{Slot:0b}]}] run function game:misc/shop
execute if score game_timer const matches 1..60 as @a[gamemode=adventure,nbt=!{Inventory:[{Slot:0b},{Slot:2b},{Slot:3b},{Slot:4b},{Slot:5b},{Slot:6b},{Slot:8b}]},tag=!next_round] run function game:misc/hotbar

execute as @a[tag=!give_points,scores={give_points=1..}] run function game:misc/give_points
scoreboard players reset @a[tag=!give_points,scores={give_points=1..}] give_points
tag @a[tag=give_points] remove give_points