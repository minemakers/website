
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute if entity @e[tag=board_generate,type=area_effect_cloud] run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] run setblock ~ ~ ~ minecraft:red_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] run setblock ~ ~ ~ minecraft:yellow_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] run setblock ~ ~ ~ minecraft:lime_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #2 const run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #2 const run setblock ~ ~ ~ minecraft:light_blue_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #4 const run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #4 const run setblock ~ ~ ~ minecraft:purple_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #6 const run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #6 const run setblock ~ ~ ~ minecraft:brown_terracotta

execute if entity @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #8 const run function game:board/random
execute at @e[tag=board_generate,type=area_effect_cloud] if score game_round const > #8 const run setblock ~ ~ ~ minecraft:black_terracotta

execute unless entity @e[tag=board_generate,type=area_effect_cloud] run function game:board/paste
execute if entity @e[tag=board_generate,type=area_effect_cloud] run function game:board/generate