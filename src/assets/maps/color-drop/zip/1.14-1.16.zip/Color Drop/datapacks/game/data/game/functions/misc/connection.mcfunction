
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

title @s[scores={connection=1..}] title [{"text":"Welcome to","color":"dark_green"}]
title @s[scores={connection=1..}] subtitle [{"text":"Color Drop","color":"gold","bold":"true"}]
playsound minecraft:entity.player.levelup master @s[scores={connection=1..}] ~ ~ ~ 10000
scoreboard players reset @s connection

execute if score game_status const = null const run tp @s 1000 102 1000 0 0
execute if score game_status const = null const run gamemode adventure @s

execute if score game_status const > null const run tp @s 1000 110 1000 0 35
execute if score game_status const > null const run gamemode spectator @s

spawnpoint @s 1000 101 1000
team join lobby @s
effect clear @s
clear @s

tag @s add initialized
tag @s remove next_round

effect give @a minecraft:saturation 1000000 100 true
