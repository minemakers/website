
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set game_status const 0
playsound minecraft:entity.enderdragon.ambient master @a ~ ~ ~ 10000 1.5

scoreboard players reset * lives
scoreboard players reset * points

scoreboard players reset game_round const
scoreboard players reset game_timer const

title @a times 0 100 10
title @a title {"text":"Draw","color":"aqua"}
title @a subtitle {"text":"","color":"aqua"}

execute as @a[gamemode=adventure,limit=1,nbt={ActiveEffects:[{Id:25b}]}] run title @a title {"selector":"@s","color":"aqua"}
execute as @a[gamemode=adventure,limit=1,nbt={ActiveEffects:[{Id:25b}]}] run title @a subtitle {"text":"won the game","color":"aqua"}

function game:board/standby

scoreboard players set @a connection 0
kill @e[type=area_effect_cloud,tag=block_fail]
