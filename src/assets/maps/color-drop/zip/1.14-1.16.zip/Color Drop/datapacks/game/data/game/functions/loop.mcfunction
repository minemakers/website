
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set @a[tag=!initialized] connection 1
execute as @a[scores={connection=0..}] run function game:misc/connection
execute as @a[scores={villager=0..}] run function game:misc/rules
execute if score game_status const > null const run function game:game

kill @e[type=item]