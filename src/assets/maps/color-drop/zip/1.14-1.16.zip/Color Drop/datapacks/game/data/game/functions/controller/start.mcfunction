
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

playsound minecraft:entity.sheep.shear master @a ~ ~ ~ 10000 1

scoreboard players set game_status const 1
scoreboard players set game_round const 1
scoreboard players set game_timer const 66
scoreboard players set second const 20

team join p1 @r[team=lobby,limit=1]
team join p2 @r[team=lobby,limit=1]
team join p3 @r[team=lobby,limit=1]
team join p4 @r[team=lobby,limit=1]
team join p5 @r[team=lobby,limit=1]
team join p6 @r[team=lobby,limit=1]
team join p7 @r[team=lobby,limit=1]
team join p8 @r[team=lobby,limit=1]

tp @a[limit=1,team=p1] 1009.0 103 979 180 0
tp @a[limit=1,team=p2] 992.0 103 979 180 0
tp @a[limit=1,team=p3] 979 103 992.0 90 0
tp @a[limit=1,team=p4] 979 103 1009.0 90 0
tp @a[limit=1,team=p5] 992.0 103 1021 0 0
tp @a[limit=1,team=p6] 1009.0 103 1021 0 0
tp @a[limit=1,team=p7] 1021 103 1009.0 -90 0
tp @a[limit=1,team=p8] 1021 103 992.0 -90 0

gamemode adventure @a[team=!lobby]
effect give @a[team=!lobby] minecraft:levitation 1000000 255 true
effect give @a[team=!lobby] haste 100000 5 true
scoreboard players set @a[team=!lobby] lives 20
scoreboard players set @a[team=!lobby] points 0

gamemode spectator @a[team=lobby]

tag @a remove next_round