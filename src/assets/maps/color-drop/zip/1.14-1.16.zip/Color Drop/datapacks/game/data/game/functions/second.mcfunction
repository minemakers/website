
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set second const 20
scoreboard players remove game_timer const 1

execute if score game_timer const matches 1.. unless entity @a[tag=!next_round,gamemode=adventure] run scoreboard players set game_timer const 0

execute if score game_timer const > #60 const run function game:misc/countdown
execute if score game_timer const = #60 const run function game:controller/start_round

execute if score game_timer const <= #60 const if score game_timer const > #1 const run title @a actionbar [{"score":{"objective":"const","name":"game_timer"},"italic":"true","color":"white"},{"text":" seconds remaining"}]
execute if score game_timer const = #1 const run title @a actionbar [{"score":{"objective":"const","name":"game_timer"},"italic":"true","color":"white"},{"text":" second remaining"}]
execute if score game_timer const = null const run title @a actionbar [{"text":"Ending round..."}]

execute if score game_timer const = null const run effect clear @a blindness
execute if score game_timer const = null const run clear @a

execute if score game_timer const = #-1 const run function game:controller/stop_round

execute if score game_timer const <= #-5 const run scoreboard players add game_round const 1
execute if score game_timer const <= #-5 const run tag @a remove next_round
execute if score game_timer const <= #-5 const run scoreboard players set game_timer const 66