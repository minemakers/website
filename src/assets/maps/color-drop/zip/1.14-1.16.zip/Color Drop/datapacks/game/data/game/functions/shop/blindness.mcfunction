
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[scores={points=..24}] run tellraw @s {"text":"Sorry, you don't have enough points to buy the Blindness effect!","color":"red"}
execute as @s[scores={points=..24}] run playsound minecraft:entity.item.break master @s ~ ~ ~ 10000 1

execute as @s[scores={points=25..}] run tellraw @s {"text":"You have just bought Blindness!","color":"green"}
execute as @s[scores={points=25..}] at @s run effect give @a[gamemode=adventure,distance=0.01..] blindness 8 100 true
execute as @s[scores={points=25..}] run playsound minecraft:entity.squid.hurt master @s ~ ~ ~ 10000 0.6
execute as @s[scores={points=25..}] run scoreboard players remove @s points 25