
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[scores={points=..74}] run tellraw @s {"text":"Sorry, you don't have enough points to buy the Big Colored Square!","color":"red"}
execute as @s[scores={points=..74}] run playsound minecraft:entity.item.break master @s ~ ~ ~ 10000 1

execute as @s[scores={points=75..}] run tellraw @s {"text":"You have just bought Big Colored Square!","color":"green"}
execute as @s[scores={points=75..}] run playsound minecraft:entity.player.burp master @s ~ ~ ~ 10000 
execute as @s[scores={points=75..}] at @s as @a[distance=0.01..,limit=1,sort=random] run function game:misc/colored_square
execute as @s[scores={points=75..}] run scoreboard players remove @s points 75