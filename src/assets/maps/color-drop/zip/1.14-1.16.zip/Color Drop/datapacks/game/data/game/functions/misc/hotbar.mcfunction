
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

clear @s
replaceitem entity @s[tag=!next_round] hotbar.0 minecraft:golden_pickaxe{ench:[{id:0,lvl:1}],HideFlags:1023,display:{Name:"{\"text\":\"Block Destroyer\",\"color\":\"gold\",\"italic\":\"false\"}",Lore:["§7Use this pickaxe to mine blocks"]},CanDestroy:["minecraft:red_terracotta","minecraft:yellow_terracotta","minecraft:lime_terracotta","minecraft:light_blue_terracotta","minecraft:purple_terracotta","minecraft:brown_terracotta","minecraft:black_terracotta"],Unbreakable:1}

replaceitem entity @s[tag=!next_round] hotbar.2 minecraft:gray_dye{display:{Name:"[{\"text\":\"Lives (50 points)\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Not enough points\",\"color\":\"gray\"}]",Lore:["§7Buy this to get 2 lives"]}}
replaceitem entity @s[tag=!next_round] hotbar.3 minecraft:gray_dye{display:{Name:"[{\"text\":\"Blindness (25 points)\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Not enough points\",\"color\":\"gray\"}]",Lore:["§7Buy this to blind the other players"]}}
replaceitem entity @s[tag=!next_round] hotbar.4 minecraft:gray_dye{display:{Name:"[{\"text\":\"Big Yellow Square (90 points)\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Not enough points\",\"color\":\"gray\"}]",Lore:["§7Buy this to color your board in yellow"]}}
replaceitem entity @s[tag=!next_round] hotbar.5 minecraft:gray_dye{display:{Name:"[{\"text\":\"Freeze (50 points)\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Not enough points\",\"color\":\"gray\"}]",Lore:["§7Buy this to freeze the other players"]}}
replaceitem entity @s[tag=!next_round] hotbar.6 minecraft:gray_dye{display:{Name:"[{\"text\":\"Big Colored Square (75 points)\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Not enough points\",\"color\":\"gray\"}]",Lore:["§7Buy this to color the board of another player"]}}

replaceitem entity @s[scores={points=50..},tag=!next_round] hotbar.2 minecraft:emerald{display:{Name:"[{\"text\":\"Lives (50 points)\",\"color\":\"green\",\"italic\":\"false\"},{\"text\":\" - Drop to buy\",\"color\":\"gray\"}]",Lore:["§7Buy this to get 2 lives"]}}
replaceitem entity @s[scores={points=25..},tag=!next_round] hotbar.3 minecraft:charcoal{display:{Name:"[{\"text\":\"Blindness (25 points)\",\"color\":\"dark_gray\",\"italic\":\"false\"},{\"text\":\" - Drop to buy\",\"color\":\"gray\"}]",Lore:["§7Buy this to blind the other players"]}}
replaceitem entity @s[scores={points=90..},tag=!next_round] hotbar.4 minecraft:dandelion{display:{Name:"[{\"text\":\"Big Yellow Square (90 points)\",\"color\":\"yellow\",\"italic\":\"false\"},{\"text\":\" - Drop to buy\",\"color\":\"gray\"}]",Lore:["§7Buy this to color your board in yellow"]}}
replaceitem entity @s[scores={points=50..},tag=!next_round] hotbar.5 minecraft:ice{display:{Name:"[{\"text\":\"Freeze (50 points)\",\"color\":\"aqua\",\"italic\":\"false\"},{\"text\":\" - Drop to buy\",\"color\":\"gray\"}]",Lore:["§7Buy this to freeze the other players"]}}
replaceitem entity @s[scores={points=75..},tag=!next_round] hotbar.6 minecraft:magma_block{display:{Name:"[{\"text\":\"Big Colored Square (75 points)\",\"color\":\"light_purple\",\"italic\":\"false\"},{\"text\":\" - Drop to buy\",\"color\":\"gray\"}]",Lore:["§7Buy this to color the board of another player"]}}

replaceitem entity @s[tag=!next_round] hotbar.8 minecraft:barrier{display:{Name:"[{\"text\":\"End the round\",\"color\":\"red\",\"italic\":\"false\"},{\"text\":\" - Drop to use\",\"color\":\"gray\"}]",Lore:["§7Use this to end the round"]}}