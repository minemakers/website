
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[scores={points=..49}] run tellraw @s {"text":"Sorry, you don't have enough points to buy Lives!","color":"red"}
execute as @s[scores={points=..49}] run playsound minecraft:entity.item.break master @s ~ ~ ~ 10000 1

execute as @s[scores={points=50..}] run tellraw @s {"text":"You have just bought 2 lives!","color":"green"}
execute as @s[scores={points=50..}] run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 10000 1
execute as @s[scores={points=50..}] run scoreboard players add @s lives 2
execute as @s[scores={points=50..}] run scoreboard players remove @s points 50