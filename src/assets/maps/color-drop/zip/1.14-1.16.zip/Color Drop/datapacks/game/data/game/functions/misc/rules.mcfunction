
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

tellraw @s [{"text":"\nThe objective is to be the last player alive.","color":"green"},{"text":"\nYou can break any blocks of the same color that are in groups of two or more. Each block left at the end of a round will cost you 1 life.","color":"gray"},{"text":"\nDestroy as many blocks as possible to earn maximum points, then use them in the shop to help you win the game!","color":"gold"},{"text":"\n\nGood luck and have fun! ^^\n","color":"aqua"}]
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 10000
scoreboard players reset @s villager