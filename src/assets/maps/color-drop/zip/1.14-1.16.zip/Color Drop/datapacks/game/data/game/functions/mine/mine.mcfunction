
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

setblock ~ ~ ~ air
setblock ~-1000 ~ ~-1000 air
particle minecraft:falling_dust minecraft:obsidian ~ ~ ~ 0.3 0.3 0.3 1 30
playsound minecraft:block.stone.break master @a ~ ~ ~

scoreboard players add @a[sort=nearest,limit=1,gamemode=adventure] give_points 1
tag @a[sort=nearest,limit=1,gamemode=adventure] add give_points

summon minecraft:area_effect_cloud ~ 100 ~ {Tags:["falling_block"],Duration:50}

execute align xz run kill @e[type=area_effect_cloud,dx=0,dz=0,dy=15,tag=falling_block]
execute as @e[type=area_effect_cloud,tag=falling_block,distance=..9] at @s run tp @s ~ 100 ~