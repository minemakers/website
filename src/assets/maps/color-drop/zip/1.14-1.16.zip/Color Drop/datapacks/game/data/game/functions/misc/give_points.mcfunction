
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set @s[scores={give_points=1..5}] const 2
scoreboard players set @s[scores={give_points=6..10}] const 3
scoreboard players set @s[scores={give_points=11..15}] const 4
scoreboard players set @s[scores={give_points=16..20}] const 5
scoreboard players set @s[scores={give_points=21..}] const 6
scoreboard players operation @s give_points *= @s const

title @s title [{"text":""}]
title @s times 0 30 5

title @s[scores={const=2}] subtitle [{"text":"+ ","color":"yellow","bold":"true"},{"score":{"name":"@s","objective":"give_points"}},{"text":" points"}]
title @s[scores={const=3}] subtitle [{"text":"+ ","color":"green","bold":"true"},{"score":{"name":"@s","objective":"give_points"}},{"text":" points (x1.5)"}]
title @s[scores={const=4}] subtitle [{"text":"+ ","color":"dark_green","bold":"true"},{"score":{"name":"@s","objective":"give_points"}},{"text":" points (x2)"}]
title @s[scores={const=5}] subtitle [{"text":"+ ","color":"dark_purple","bold":"true"},{"score":{"name":"@s","objective":"give_points"}},{"text":" points (x2.5)"}]
title @s[scores={const=6}] subtitle [{"text":"+ ","color":"dark_red","bold":"true"},{"score":{"name":"@s","objective":"give_points"}},{"text":" points (x3)"}]

scoreboard players operation @s points += @s give_points
scoreboard players reset @s give_points
scoreboard players reset @s const

function game:misc/hotbar