
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[team=p1] run tag @e[type=area_effect_cloud,tag=a1] add squareNS
execute as @s[team=p2] run tag @e[type=area_effect_cloud,tag=a2] add squareNS
execute as @s[team=p5] run tag @e[type=area_effect_cloud,tag=a5] add squareNS
execute as @s[team=p6] run tag @e[type=area_effect_cloud,tag=a6] add squareNS
execute as @s[team=p3] run tag @e[type=area_effect_cloud,tag=a3] add squareWE
execute as @s[team=p4] run tag @e[type=area_effect_cloud,tag=a4] add squareWE
execute as @s[team=p7] run tag @e[type=area_effect_cloud,tag=a7] add squareWE
execute as @s[team=p8] run tag @e[type=area_effect_cloud,tag=a8] add squareWE
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-5 ~4 ~ run fill ~ ~ ~ ~-3 ~2 ~ minecraft:black_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-5 ~4 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-7 ~4 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-6 ~5 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-8 ~5 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-5 ~6 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareNS] positioned ~-7 ~6 ~ run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~4 ~5 run fill ~ ~ ~ ~ ~2 ~3 minecraft:black_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~4 ~5 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~4 ~7 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~5 ~6 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~5 ~8 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~6 ~5 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta
execute at @e[type=area_effect_cloud,tag=squareWE] positioned ~ ~6 ~7 run fill ~ ~ ~ ~ ~ ~ minecraft:brown_terracotta replace #game:stained_terracotta

tag @e[tag=squareNS] remove squareNS
tag @e[tag=squareWE] remove squareWE