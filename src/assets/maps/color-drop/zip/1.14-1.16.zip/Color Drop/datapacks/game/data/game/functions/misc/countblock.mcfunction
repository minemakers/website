
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

tag @e[limit=1,sort=random,x=1004,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=1004,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=1004,y=101,z=975,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=987,y=101,z=975,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=975,y=101,z=987,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=975,y=101,z=1004,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=987,y=101,z=1014,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=1..}] lives 1

tag @e[limit=1,sort=random,x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @e[x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] run scoreboard players remove @a[x=1014,y=101,z=987,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=1..}] lives 1


execute if entity @a[x=1014,y=101,z=987,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=..0}] run tag @e[x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=1004,y=101,z=975,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=..0}] run tag @e[x=1004,y=101,z=975,dx=9,dy=6,dz=12,tag=block_fail,type=area_effect_cloud] add destroy
execute if entity @a[x=987,y=101,z=975,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=..0}] run tag @e[x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=975,y=101,z=987,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=..0}] run tag @e[x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=975,y=101,z=1004,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=..0}] run tag @e[x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=987,y=101,z=1014,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=..0}] run tag @e[x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,gamemode=adventure,scores={lives=..0}] run tag @e[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,tag=block_fail] add destroy
execute if entity @a[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,gamemode=adventure,scores={lives=..0}] run tag @e[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,tag=block_fail] add destroy


execute at @e[type=area_effect_cloud,tag=block_fail,tag=destroy] run setblock ~ ~ ~ air destroy
execute at @e[tag=block_fail,type=area_effect_cloud,tag=destroy] run playsound minecraft:entity.chicken.egg master @a ~ ~ ~
scoreboard players set game_timer const -5
execute if entity @e[type=area_effect_cloud,tag=block_fail] run scoreboard players set game_timer const -3
kill @e[tag=block_fail,type=area_effect_cloud,tag=destroy]


execute as @a[scores={lives=..0},gamemode=adventure] run tellraw @a [{"text":"Sorry ","color":"yellow"},{"selector":"@s","color":"red"},{"text":", you are eliminated!"}]
execute as @a[scores={lives=..0},gamemode=adventure] run playsound minecraft:entity.wither.death master @a 1000 100 1000 100000 2
scoreboard players set @a[scores={lives=..0}] connection 0
scoreboard players reset @a[scores={lives=..0}] lives
title @a times 0 100 10

scoreboard players set players const 0
execute as @a[gamemode=adventure] run scoreboard players add players const 1
execute if score players const matches ..1 run function game:controller/stop