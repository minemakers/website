
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set @s pickaxe 0

execute at @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/red",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/yellow",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/green",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/blue",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/purple",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/brown",auto:1} replace 
execute at @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] run setblock ~-1000 ~ ~-1000 command_block{Command:"function game:mine/black",auto:1} replace 


execute at @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] run setblock ~ ~ ~ minecraft:red_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] run setblock ~ ~ ~ minecraft:yellow_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] run setblock ~ ~ ~ minecraft:lime_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] run setblock ~ ~ ~ minecraft:light_blue_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] run setblock ~ ~ ~ minecraft:purple_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] run setblock ~ ~ ~ minecraft:brown_terracotta
execute at @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] run setblock ~ ~ ~ minecraft:black_terracotta


execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~1 ~ ~ minecraft:red_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~ ~1 ~ minecraft:red_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~ ~ ~1 minecraft:red_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:red_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:red_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:red_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~1 ~ ~ minecraft:yellow_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~ ~1 ~ minecraft:yellow_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~ ~ ~1 minecraft:yellow_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:yellow_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:yellow_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:yellow_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~1 ~ ~ minecraft:lime_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~ ~1 ~ minecraft:lime_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~ ~ ~1 minecraft:lime_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:lime_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:lime_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:lime_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~1 ~ ~ minecraft:light_blue_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~ ~1 ~ minecraft:light_blue_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~ ~ ~1 minecraft:light_blue_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:light_blue_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:light_blue_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:light_blue_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~1 ~ ~ minecraft:purple_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~ ~1 ~ minecraft:purple_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~ ~ ~1 minecraft:purple_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:purple_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:purple_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:purple_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~1 ~ ~ minecraft:brown_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~ ~1 ~ minecraft:brown_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~ ~ ~1 minecraft:brown_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:brown_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:brown_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:brown_terracotta run kill @s

execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~1 ~ ~ minecraft:black_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~ ~1 ~ minecraft:black_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~ ~ ~1 minecraft:black_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~-1 ~ ~ minecraft:black_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~ ~-1 ~ minecraft:black_terracotta run kill @s
execute as @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] at @s if block ~ ~ ~-1 minecraft:black_terracotta run kill @s


execute at @e[type=item,nbt={Item:{id:"minecraft:red_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:yellow_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:lime_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:light_blue_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:purple_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:brown_terracotta"}}] run setblock ~-1000 ~ ~-1000 air
execute at @e[type=item,nbt={Item:{id:"minecraft:black_terracotta"}}] run setblock ~-1000 ~ ~-1000 air