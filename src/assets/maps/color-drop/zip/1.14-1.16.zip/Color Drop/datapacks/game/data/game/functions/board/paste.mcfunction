
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

#NORTH
execute if entity @a[team=p2] run clone 1004 101 975 1013 107 975 987 101 975 replace

#WEST
execute if entity @a[team=p3] run clone 1004 101 975 1004 107 975 975 101 996 replace
execute if entity @a[team=p3] run clone 1005 101 975 1005 107 975 975 101 995 replace
execute if entity @a[team=p3] run clone 1006 101 975 1006 107 975 975 101 994 replace
execute if entity @a[team=p3] run clone 1007 101 975 1007 107 975 975 101 993 replace
execute if entity @a[team=p3] run clone 1008 101 975 1008 107 975 975 101 992 replace
execute if entity @a[team=p3] run clone 1009 101 975 1009 107 975 975 101 991 replace
execute if entity @a[team=p3] run clone 1010 101 975 1010 107 975 975 101 990 replace
execute if entity @a[team=p3] run clone 1011 101 975 1011 107 975 975 101 989 replace
execute if entity @a[team=p3] run clone 1012 101 975 1012 107 975 975 101 988 replace
execute if entity @a[team=p3] run clone 1013 101 975 1013 107 975 975 101 987 replace

execute if entity @a[team=p4] run clone 975 101 996 975 107 987 975 101 1004 replace


#SOUTH
execute if entity @a[team=p5] run clone 1004 101 975 1004 107 975 996 101 1025 replace
execute if entity @a[team=p5] run clone 1005 101 975 1005 107 975 995 101 1025 replace
execute if entity @a[team=p5] run clone 1006 101 975 1006 107 975 994 101 1025 replace
execute if entity @a[team=p5] run clone 1007 101 975 1007 107 975 993 101 1025 replace
execute if entity @a[team=p5] run clone 1008 101 975 1008 107 975 992 101 1025 replace
execute if entity @a[team=p5] run clone 1009 101 975 1009 107 975 991 101 1025 replace
execute if entity @a[team=p5] run clone 1010 101 975 1010 107 975 990 101 1025 replace
execute if entity @a[team=p5] run clone 1011 101 975 1011 107 975 989 101 1025 replace
execute if entity @a[team=p5] run clone 1012 101 975 1012 107 975 988 101 1025 replace
execute if entity @a[team=p5] run clone 1013 101 975 1013 107 975 987 101 1025 replace

execute if entity @a[team=p6] run clone 987 107 1025 996 101 1025 1004 101 1025 replace


#EAST

execute if entity @a[team=p8] run clone 1004 101 975 1004 107 975 1025 101 987 replace
execute if entity @a[team=p8] run clone 1005 101 975 1005 107 975 1025 101 988 replace
execute if entity @a[team=p8] run clone 1006 101 975 1006 107 975 1025 101 989 replace
execute if entity @a[team=p8] run clone 1007 101 975 1007 107 975 1025 101 990 replace
execute if entity @a[team=p8] run clone 1008 101 975 1008 107 975 1025 101 991 replace
execute if entity @a[team=p8] run clone 1009 101 975 1009 107 975 1025 101 992 replace
execute if entity @a[team=p8] run clone 1010 101 975 1010 107 975 1025 101 993 replace
execute if entity @a[team=p8] run clone 1011 101 975 1011 107 975 1025 101 994 replace
execute if entity @a[team=p8] run clone 1012 101 975 1012 107 975 1025 101 995 replace
execute if entity @a[team=p8] run clone 1013 101 975 1013 107 975 1025 101 996 replace

execute if entity @a[team=p7] run clone 1025 101 987 1025 107 996 1025 101 1004 replace