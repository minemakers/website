
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute if block ~1001 ~ ~1000 minecraft:black_terracotta run setblock ~1 ~ ~ command_block{Command:"function game:mine/black",auto:1} replace 
execute if block ~1000 ~ ~1001 minecraft:black_terracotta run setblock ~ ~ ~1 command_block{Command:"function game:mine/black",auto:1} replace 
execute if block ~999 ~ ~1000 minecraft:black_terracotta run setblock ~-1 ~ ~ command_block{Command:"function game:mine/black",auto:1} replace 
execute if block ~1000 ~ ~999 minecraft:black_terracotta run setblock ~ ~ ~-1 command_block{Command:"function game:mine/black",auto:1} replace 
execute if block ~1000 ~1 ~1000 minecraft:black_terracotta run setblock ~ ~1 ~ command_block{Command:"function game:mine/black",auto:1} replace 
execute if block ~1000 ~-1 ~1000 minecraft:black_terracotta run setblock ~ ~-1 ~ command_block{Command:"function game:mine/black",auto:1} replace

execute positioned ~1000 ~ ~1000 run function game:mine/mine