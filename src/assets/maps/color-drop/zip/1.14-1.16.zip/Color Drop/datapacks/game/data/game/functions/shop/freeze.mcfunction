
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute as @s[scores={points=..49}] run tellraw @s {"text":"Sorry, you don't have enough points to buy the Freeze effect!","color":"red"}
execute as @s[scores={points=..49}] run playsound minecraft:entity.item.break master @s ~ ~ ~ 10000 1

execute as @s[scores={points=50..}] run tellraw @s {"text":"You have just bought Freeze!","color":"green"}
execute as @s[scores={points=50..}] at @s run effect give @a[gamemode=adventure,distance=0.01..] mining_fatigue 5 100 true
execute as @s[scores={points=50..}] run playsound minecraft:block.glass.break master @s ~ ~ ~ 10000 0.5
execute as @s[scores={points=50..}] run scoreboard players remove @s points 50