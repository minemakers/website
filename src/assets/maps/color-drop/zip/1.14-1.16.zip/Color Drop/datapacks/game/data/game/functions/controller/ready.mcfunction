
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set players const 0
execute as @a[gamemode=adventure] run scoreboard players add players const 1

execute if score players const matches ..1 run tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"}]
execute if score players const matches ..1 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute if score players const matches 2.. run function game:controller/start