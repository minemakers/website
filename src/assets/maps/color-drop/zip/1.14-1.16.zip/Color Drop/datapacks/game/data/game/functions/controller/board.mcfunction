
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute if score game_status const = null const run function game:board/standby

execute if score game_status const > null const run fill 1013 100 967 1004 100 961 barrier
execute if score game_status const > null const run summon minecraft:area_effect_cloud 1004 101 967 {Tags:["board_generate"]}
execute if score game_status const > null const run function game:board/generate