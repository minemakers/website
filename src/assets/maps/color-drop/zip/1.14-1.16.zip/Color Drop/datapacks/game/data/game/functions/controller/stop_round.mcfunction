
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

execute if entity @a[team=p1] run fill 1013 107 975 1004 101 975 air destroy
execute if entity @a[team=p2] run fill 987 107 975 996 101 975 air destroy
execute if entity @a[team=p3] run fill 975 101 996 975 107 987 air destroy
execute if entity @a[team=p4] run fill 975 107 1004 975 101 1013 air destroy
execute if entity @a[team=p5] run fill 996 101 1025 987 107 1025 air destroy
execute if entity @a[team=p6] run fill 1013 101 1025 1004 107 1025 air destroy
execute if entity @a[team=p7] run fill 1025 101 1004 1025 107 1013 air destroy
execute if entity @a[team=p8] run fill 1025 101 987 1025 107 996 air destroy

execute at @e[type=item] run summon minecraft:area_effect_cloud ~ ~ ~ {Tags:["block_fail"],Duration:10000}
execute at @e[type=item] run setblock ~ ~ ~ bedrock
kill @e[type=item]

tag @a[gamemode=adventure] add next_round
clear @a