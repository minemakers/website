
#Color Drop - Copyright (c) MineMakers Team (by Maxo6)

tp @e[tag=board_generate,type=area_effect_cloud] 1009 101 963
spreadplayers 1009 963 0 5 false @e[tag=board_generate,type=area_effect_cloud]
execute as @e[tag=board_generate,type=area_effect_cloud] at @s if block ~ ~-1 ~ air run kill @s
execute at @e[tag=board_generate,type=area_effect_cloud] run setblock ~ ~-1 ~ air

execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=967,dz=0,dx=100,dy=10] at @s run tp @s ~ ~ ~8
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=966,dz=0,dx=100,dy=10] at @s run tp @s ~ ~1 ~9
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=965,dz=0,dx=100,dy=10] at @s run tp @s ~ ~2 ~10
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=964,dz=0,dx=100,dy=10] at @s run tp @s ~ ~3 ~11
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=963,dz=0,dx=100,dy=10] at @s run tp @s ~ ~4 ~12
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=962,dz=0,dx=100,dy=10] at @s run tp @s ~ ~5 ~13
execute as @e[tag=board_generate,type=area_effect_cloud,x=1000,y=100,z=961,dz=0,dx=100,dy=10] at @s run tp @s ~ ~6 ~14