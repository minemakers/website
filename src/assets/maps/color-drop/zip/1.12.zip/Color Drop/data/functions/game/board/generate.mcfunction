function game:board/newblock
execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 14
function game:board/newblock
execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 4
function game:board/newblock
execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 5

scoreboard players test !board const 2 5
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/newblock
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 3

scoreboard players test !board const 3 5
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/newblock
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 10

scoreboard players test !board const 4 5
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/newblock
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 12

scoreboard players test !board const 5 10000
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/newblock
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 15


scoreboard players test !boardGenerate const 1 69
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/generate
scoreboard players test !boardGenerate const 70 100
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/paste
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players reset !boardGenerate const