spreadplayers 1009 963 0 5 false @e[name=generateBoard,type=area_effect_cloud]
execute @e[type=area_effect_cloud,name=success,score_const=0] ~ ~ ~ kill @e[name=generateBoard,type=area_effect_cloud]
execute @e[name=generateBoard,type=area_effect_cloud] ~ ~ ~ setblock ~ ~-1 ~ air
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=967,dz=0,dx=100,dy=10] ~ ~ ~8
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=966,dz=0,dx=100,dy=10] ~ ~1 ~9
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=965,dz=0,dx=100,dy=10] ~ ~2 ~10
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=964,dz=0,dx=100,dy=10] ~ ~3 ~11
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=963,dz=0,dx=100,dy=10] ~ ~4 ~12
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=962,dz=0,dx=100,dy=10] ~ ~5 ~13
tp @e[name=generateBoard,type=area_effect_cloud,x=1000,y=100,z=961,dz=0,dx=100,dy=10] ~ ~6 ~14
scoreboard players set @e[type=area_effect_cloud,name=success] const 1
scoreboard players add !boardGenerate const 1