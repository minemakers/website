fill 1004 107 975 1013 101 975 minecraft:stained_hardened_clay 15
fill 1005 106 975 1012 102 975 minecraft:stained_hardened_clay 7
fill 1006 105 975 1011 103 975 minecraft:stained_hardened_clay 15
fill 1005 104 975 1012 104 975 minecraft:stained_hardened_clay 15
fill 1007 104 975 1010 104 975 minecraft:stained_hardened_clay 7
function game:board/paste