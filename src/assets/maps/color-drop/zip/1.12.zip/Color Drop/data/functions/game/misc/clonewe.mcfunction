execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~10 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 clone ~ 101 ~ ~ 107 ~ ~ 101 ~-1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~10 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 tp @e[type=!player,dy=-20,dx=0,dz=0] ~ ~ ~-1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~10 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~9 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 clone ~ 101 ~1 ~ 107 ~ ~ 101 ~-1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~9 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 tp @e[type=!player,dy=-20,dx=0,dz=1] ~ ~ ~-1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~9 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~8 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 clone ~ 101 ~2 ~ 107 ~ ~ 101 ~-1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~8 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 tp @e[type=!player,dy=-20,dx=0,dz=2] ~ ~ ~-1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~8 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~7 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 clone ~ 101 ~3 ~ 107 ~ ~ 101 ~-1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~7 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~1 tp @e[type=!player,dy=-20,dx=0,dz=3] ~ ~ ~-1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~7 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]



execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~3 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 clone ~ 101 ~ ~ 107 ~ ~ 101 ~1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~3 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 tp @e[type=!player,dy=-20,dx=0,dz=0] ~ ~ ~1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~3 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~4 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 clone ~ 101 ~-1 ~ 107 ~ ~ 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~4 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 tp @e[type=!player,dy=-20,dx=0,dz=-1] ~ ~ ~1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~4 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~5 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 clone ~ 101 ~-2 ~ 107 ~ ~ 101 ~-1 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~5 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 tp @e[type=!player,dy=-20,dx=0,dz=-2] ~ ~ ~1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~5 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~6 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 clone ~ 101 ~-3 ~ 107 ~ ~ 101 ~-2 replace move
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~6 execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~-1 tp @e[type=!player,dy=-20,dx=0,dz=-3] ~ ~ ~1
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~6 kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

