function game:looplobby

execute @a[score_usePickaxe_min=1] ~ ~ ~ function game:misc/colorblock

execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~1 ~ air 0 execute @s ~ ~ ~ detect ~ ~2 ~ air 0 tp @s ~ ~1 ~
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~1 ~ air 0 execute @s ~ ~ ~ detect ~ ~2 ~ air 0 tp @s ~ ~1 ~

execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay * scoreboard players tag @s add noClone
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 15 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:15}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 15 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 12 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:12}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 12 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 10 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:10}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 10 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 3 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:3}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 3 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 5 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:5}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 5 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 4 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:4}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 4 setblock ~ ~ ~ air 0
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 14 summon minecraft:falling_block ~ ~ ~ {DropItem:0,Block:"minecraft:stained_hardened_clay",Time:1,Data:14}
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~ ~ air 0 execute @s ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 14 setblock ~ ~ ~ air 0

scoreboard players tag @a[tag=givingPoints] remove givingPoints
execute @e[type=area_effect_cloud,name=breakBlock] ~ ~ ~ scoreboard players add @a[c=1,m=2] givePoints 1
execute @e[type=area_effect_cloud,name=breakBlock] ~ ~ ~ scoreboard players tag @a[c=1,m=2] add givingPoints
execute @a[score_givePoints_min=1,tag=!givingPoints] ~ ~ ~ function game:misc/givepoints

execute @e[type=area_effect_cloud,name=breakBlock] ~ 100 ~ tp @e[type=area_effect_cloud,name=fallBlock,r=9] ~ 99 ~

execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay * tp @s ~ ~1 ~
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay * tp @s ~ ~1 ~

tp @e[type=area_effect_cloud,name=fallBlock] ~ ~.5 ~

execute @e[type=area_effect_cloud,name=cloneNS] ~ 109 ~ execute @e[dy=2,dx=-13,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~ function game:misc/clonens
execute @e[type=area_effect_cloud,name=cloneWE] ~ 109 ~ execute @e[dy=2,dz=13,dx=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~ ~ ~ function game:misc/clonewe
execute @e[type=area_effect_cloud,name=fallBlock] ~ ~ ~ kill @s[y=109,dy=3]


scoreboard players set @a[m=2,tag=giveHotbar] guiHotbar 0
scoreboard players add @a[m=2] guiHotbar 1 {Inventory:[{Slot:0b}]}
scoreboard players add @a[m=2] guiHotbar 2 {Inventory:[{Slot:2b}]}
scoreboard players add @a[m=2] guiHotbar 3 {Inventory:[{Slot:3b}]}
scoreboard players add @a[m=2] guiHotbar 4 {Inventory:[{Slot:4b}]}
scoreboard players add @a[m=2] guiHotbar 5 {Inventory:[{Slot:5b}]}
scoreboard players add @a[m=2] guiHotbar 6 {Inventory:[{Slot:6b}]}
scoreboard players add @a[m=2] guiHotbar 7 {Inventory:[{Slot:8b}]}
execute @a[m=2,score_guiHotbar=27,tag=giveHotbar] ~ ~ ~ function game:misc/shop

kill @e[type=item,tag=!block]

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameTimer const -4 -3
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/countblock

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
scoreboard players operation !forceTurn const = @e[type=area_effect_cloud,name=success] const
execute @e[type=area_effect_cloud,name=success,score_const=1] ~ ~ ~ function game:controller/stop

execute @a[tag=nextRound,m=2] ~ ~ ~ scoreboard players remove !forceTurn const 1
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameRound const 1 59
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !forceTurn const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !gameTimer const 1