scoreboard players tag @e[type=Item,c=1,r=7] add block {Item:{id:"minecraft:stained_hardened_clay"}}
scoreboard players tag @e[type=Item,tag=block] add blockRed {Item:{id:"minecraft:stained_hardened_clay",Damage:14s}}
scoreboard players tag @e[type=Item,tag=block] add blockYellow {Item:{id:"minecraft:stained_hardened_clay",Damage:4s}}
scoreboard players tag @e[type=Item,tag=block] add blockGreen {Item:{id:"minecraft:stained_hardened_clay",Damage:5s}}
scoreboard players tag @e[type=Item,tag=block] add blockBlue {Item:{id:"minecraft:stained_hardened_clay",Damage:3s}}
scoreboard players tag @e[type=Item,tag=block] add blockPurple {Item:{id:"minecraft:stained_hardened_clay",Damage:10s}}
scoreboard players tag @e[type=Item,tag=block] add blockBrown {Item:{id:"minecraft:stained_hardened_clay",Damage:12s}}
scoreboard players tag @e[type=Item,tag=block] add blockBlack {Item:{id:"minecraft:stained_hardened_clay",Damage:15s}}
scoreboard players reset @s usePickaxe

execute @e[type=item,tag=blockRed] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakred",auto:1}
execute @e[type=item,tag=blockYellow] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakyellow",auto:1}
execute @e[type=item,tag=blockGreen] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakgreen",auto:1}
execute @e[type=item,tag=blockBlue] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakblue",auto:1}
execute @e[type=item,tag=blockPurple] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakpurple",auto:1}
execute @e[type=item,tag=blockBrown] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakbrown",auto:1}
execute @e[type=item,tag=blockBlack] ~-1000 ~ ~-1000 setblock ~ ~ ~ command_block 0 replace {Command:"function game:misc/breakblack",auto:1}

execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockRed] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 14 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockYellow] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 4 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockGreen] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 5 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockBlue] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 3 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockPurple] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 10 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBrown] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 12 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~1 ~ ~ stained_hardened_clay 15 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~ ~1 ~ stained_hardened_clay 15 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~ ~ ~1 stained_hardened_clay 15 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~-1 ~ ~ stained_hardened_clay 15 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~ ~-1 ~ stained_hardened_clay 15 kill @s
execute @e[type=item,tag=blockBlack] ~ ~ ~ detect ~ ~ ~-1 stained_hardened_clay 15 kill @s

execute @e[type=item,tag=blockRed] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 14
execute @e[type=item,tag=blockRed] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockYellow] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 4
execute @e[type=item,tag=blockYellow] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockGreen] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 5
execute @e[type=item,tag=blockGreen] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockBlue] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 3
execute @e[type=item,tag=blockBlue] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockPurple] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 10
execute @e[type=item,tag=blockPurple] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockBrown] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 12
execute @e[type=item,tag=blockBrown] ~ ~ ~ setblock ~-1000 ~ ~-1000 air

execute @e[type=item,tag=blockBlack] ~ ~ ~ setblock ~ ~ ~ stained_hardened_clay 15
execute @e[type=item,tag=blockBlack] ~ ~ ~ setblock ~-1000 ~ ~-1000 air


kill @e[type=Item,tag=block]