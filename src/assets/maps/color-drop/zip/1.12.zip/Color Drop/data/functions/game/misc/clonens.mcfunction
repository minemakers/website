execute @e[type=area_effect_cloud,name=cloneNS] ~-10 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ clone ~ 101 ~ ~ 107 ~ ~1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-10 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ tp @e[type=!player,dy=-20,dx=0,dz=0] ~1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-10 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-9 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ clone ~-1 101 ~ ~ 107 ~ ~ 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-9 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ tp @e[type=!player,dy=-20,dx=-1,dz=0] ~1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-9 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-8 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ clone ~-2 101 ~ ~ 107 ~ ~-1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-8 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ tp @e[type=!player,dy=-20,dx=-2,dz=0] ~1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-8 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-7 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ clone ~-3 101 ~ ~ 107 ~ ~-2 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-7 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~-1 ~ ~ tp @e[type=!player,dy=-20,dx=-3,dz=0] ~1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-7 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]



execute @e[type=area_effect_cloud,name=cloneNS] ~-3 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ clone ~ 101 ~ ~ 107 ~ ~-1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-3 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ tp @e[type=!player,dy=-20,dx=0,dz=0] ~-1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-3 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-4 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ clone ~1 101 ~ ~ 107 ~ ~-1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-4 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ tp @e[type=!player,dy=-20,dx=1,dz=0] ~-1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-4 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-5 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ clone ~2 101 ~ ~ 107 ~ ~-1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-5 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ tp @e[type=!player,dy=-20,dx=2,dz=0] ~-1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-5 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

execute @e[type=area_effect_cloud,name=cloneNS] ~-6 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ clone ~3 101 ~ ~ 107 ~ ~-1 101 ~ replace move
execute @e[type=area_effect_cloud,name=cloneNS] ~-6 109 ~ execute @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock] ~1 ~ ~ tp @e[type=!player,dy=-20,dx=3,dz=0] ~-1 ~ ~
execute @e[type=area_effect_cloud,name=cloneNS] ~-6 109 ~ kill @e[dy=2,dx=0,dz=0,tag=!noClone,type=area_effect_cloud,name=fallBlock]

