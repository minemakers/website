gamerule gameLoopFunction game:looplobby
scoreboard players set !gameStatus const 0
playsound minecraft:entity.enderdragon.ambient master @a ~ ~ ~ 10000 1.5

scoreboard players reset * statPoints
scoreboard players reset * statLife

scoreboard players reset !gameRound const
scoreboard players reset !gameTimer const

title @a times 0 100 10
title @a title {"text":"Draw","color":"aqua"}
title @a subtitle {"text":"","color":"aqua"}
execute @a[m=2,c=1] ~ ~ ~ title @a title {"selector":"@s","color":"aqua"}
execute @a[m=2,c=1] ~ ~ ~ title @a subtitle {"text":"won the game","color":"aqua"}

kill @e[type=area_effect_cloud,name=failPoint]
scoreboard players set !board const 0
function game:controller/board
scoreboard players set @a connection 0