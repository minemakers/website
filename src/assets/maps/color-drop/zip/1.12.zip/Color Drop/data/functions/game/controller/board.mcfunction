execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !board const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/waiting
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !board const 1 10
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ fill 1013 100 967 1004 100 961 barrier
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ summon minecraft:area_effect_cloud 1004 101 967 {CustomName:"generateBoard"}
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/generate
