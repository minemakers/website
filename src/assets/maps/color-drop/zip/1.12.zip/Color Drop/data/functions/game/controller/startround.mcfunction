scoreboard players tag @a[m=2] add giveHotbar
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 10000
title @a subtitle [{"text":"The round has just started!","color":"yellow"}]
title @a times 0 40 10

tp @a[c=1,team=p1] 1009.0 103 979 180 0
tp @a[c=1,team=p2] 992.0 103 979 180 0
tp @a[c=1,team=p3] 979 103 992.0 90 0
tp @a[c=1,team=p4] 979 103 1009.0 90 0
tp @a[c=1,team=p5] 992.0 103 1021 0 0
tp @a[c=1,team=p6] 1009.0 103 1021 0 0
tp @a[c=1,team=p7] 1021 103 1009.0 -90 0
tp @a[c=1,team=p8] 1021 103 992.0 -90 0

function game:controller/board