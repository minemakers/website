scoreboard players add !gameRound const 1
scoreboard players operation !board const = !gameRound const
scoreboard players add !board const 1
scoreboard players operation !board const /= !2 const

effect @a blindness 0
clear @a
scoreboard players tag * remove giveHotbar
scoreboard players tag * remove nextRound