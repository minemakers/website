scoreboard players set @s[score_guiHotbar_min=26,score_guiHotbar=26,score_statPoints=49] guiHotbar -1
scoreboard players set @s[score_guiHotbar_min=25,score_guiHotbar=25,score_statPoints=24] guiHotbar -1
scoreboard players set @s[score_guiHotbar_min=24,score_guiHotbar=24,score_statPoints=89] guiHotbar -1
scoreboard players set @s[score_guiHotbar_min=23,score_guiHotbar=23,score_statPoints=49] guiHotbar -1
scoreboard players set @s[score_guiHotbar_min=22,score_guiHotbar=22,score_statPoints=74] guiHotbar -1

tellraw @s[score_guiHotbar_min=-1,score_guiHotbar=-1] {"text":"Sorry, you don't have enough points!","color":"red"}
playsound minecraft:entity.item.break master @s[score_guiHotbar_min=-1,score_guiHotbar=-1] ~ ~ ~ 10000 1

tellraw @s[score_guiHotbar_min=26,score_guiHotbar=26] {"text":"You have just bought 2 lives!","color":"green"}
playsound minecraft:entity.player.levelup master @s[score_guiHotbar_min=26,score_guiHotbar=26] ~ ~ ~ 10000 1
scoreboard players add @s[score_guiHotbar_min=26,score_guiHotbar=26] statLife 2
scoreboard players remove @s[score_guiHotbar_min=26,score_guiHotbar=26] statPoints 50

tellraw @s[score_guiHotbar_min=25,score_guiHotbar=25] {"text":"You have just bought Blindness!","color":"green"}
execute @s[score_guiHotbar_min=25,score_guiHotbar=25] ~ ~ ~ effect @a[m=2,rm=0] blindness 8 100 true
execute @s[score_guiHotbar_min=25,score_guiHotbar=25] ~ ~ ~ playsound minecraft:entity.squid.hurt master @s ~ ~ ~ 10000 0.6
scoreboard players remove @s[score_guiHotbar_min=25,score_guiHotbar=25] statPoints 25

tellraw @s[score_guiHotbar_min=24,score_guiHotbar=24] {"text":"You have just bought Big Yellow Square!","color":"green"}
playsound minecraft:entity.witch.drink master @s[score_guiHotbar_min=24,score_guiHotbar=24] ~ ~ ~ 10000 2
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p1] ~ ~ ~ fill 1007 105 975 1010 103 975 minecraft:stained_hardened_clay 4 replace stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p2] ~ ~ ~ fill 990 105 975 993 103 975 stained_hardened_clay 4 replace stained_hardened_clay 
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p3] ~ ~ ~ fill 975 105 993 975 103 990 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p4] ~ ~ ~ fill 975 105 1010 975 103 1007 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p5] ~ ~ ~ fill 993 105 1025 990 103 1025 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p6] ~ ~ ~ fill 1010 105 1025 1007 103 1025 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p7] ~ ~ ~ fill 1025 105 1007 1025 103 1010 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay
execute @s[score_guiHotbar_min=24,score_guiHotbar=24,team=p8] ~ ~ ~ fill 1025 105 990 1025 103 993 minecraft:stained_hardened_clay 4 replace minecraft:stained_hardened_clay 
scoreboard players remove @s[score_guiHotbar_min=24,score_guiHotbar=24] statPoints 90

tellraw @s[score_guiHotbar_min=23,score_guiHotbar=23] {"text":"You have just bought Freeze!","color":"green"}
execute @s[score_guiHotbar_min=23,score_guiHotbar=23] ~ ~ ~ effect @a[m=2,rm=0] mining_fatigue 5 100 true
execute @s[score_guiHotbar_min=23,score_guiHotbar=23] ~ ~ ~ playsound minecraft:block.glass.break master @s ~ ~ ~ 10000 0.5
scoreboard players remove @s[score_guiHotbar_min=23,score_guiHotbar=23] statPoints 50

tellraw @s[score_guiHotbar_min=22,score_guiHotbar=22] {"text":"You have just bought Big Colored Square!","color":"green"}
playsound minecraft:entity.player.burp master @s[score_guiHotbar_min=22,score_guiHotbar=22] ~ ~ ~ 10000 
execute @s[score_guiHotbar_min=22,score_guiHotbar=22] ~ ~ ~ execute @r[rm=0,type=player,m=2,c=1] ~ ~ ~ function game:misc/square
scoreboard players remove @s[score_guiHotbar_min=22,score_guiHotbar=22] statPoints 75

scoreboard players tag @s[score_guiHotbar_min=21,score_guiHotbar=21] remove giveHotbar
scoreboard players tag @s[score_guiHotbar_min=21,score_guiHotbar=21] add nextRound
playsound minecraft:entity.villager.yes master @s[score_guiHotbar_min=21,score_guiHotbar=21] ~ ~ ~ 100000
clear @s[score_guiHotbar_min=21,score_guiHotbar=21]

execute @s[score_guiHotbar_min=22] ~ ~ ~ function game:misc/hotbar
execute @s[score_guiHotbar=20] ~ ~ ~ function game:misc/hotbar