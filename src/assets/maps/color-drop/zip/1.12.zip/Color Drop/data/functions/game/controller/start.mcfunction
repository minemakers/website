gamerule gameLoopFunction game:loopgame
scoreboard players set !gameStatus const 1
playsound minecraft:entity.sheep.shear master @a ~ ~ ~ 10000 1
scoreboard players set !gameRound const 1
scoreboard players set !board const 1
scoreboard players set !gameTimer const 66
scoreboard players set !countSecond const -2

scoreboard teams join p1 @r[team=lobby,c=1]
scoreboard teams join p2 @r[team=lobby,c=1]
scoreboard teams join p3 @r[team=lobby,c=1]
scoreboard teams join p4 @r[team=lobby,c=1]
scoreboard teams join p5 @r[team=lobby,c=1]
scoreboard teams join p6 @r[team=lobby,c=1]
scoreboard teams join p7 @r[team=lobby,c=1]
scoreboard teams join p8 @r[team=lobby,c=1]

gamemode 3 @a[team=lobby]

tp @a[c=1,team=p1] 1009.0 103 979 180 0
tp @a[c=1,team=p2] 992.0 103 979 180 0
tp @a[c=1,team=p3] 979 103 992.0 90 0
tp @a[c=1,team=p4] 979 103 1009.0 90 0
tp @a[c=1,team=p5] 992.0 103 1021 0 0
tp @a[c=1,team=p6] 1009.0 103 1021 0 0
tp @a[c=1,team=p7] 1021 103 1009.0 -90 0
tp @a[c=1,team=p8] 1021 103 992.0 -90 0

effect @a[m=2] minecraft:levitation 1000000 255 true
effect @a[m=2] haste 100000 5 true
scoreboard players set @a[m=2] statLife 20
scoreboard players set @a[m=2] statPoints 0