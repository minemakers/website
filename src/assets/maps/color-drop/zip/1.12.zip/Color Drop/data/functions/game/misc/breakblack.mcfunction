summon minecraft:area_effect_cloud ~1000 ~ ~1000 {CustomName:"breakBlock",Tags:["newBreak","blockBlack"],Duration:2}
execute @e[tag=blockBlack] ~1 ~ ~ detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
execute @e[tag=blockBlack] ~ ~1 ~ detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
execute @e[tag=blockBlack] ~ ~ ~1 detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
execute @e[tag=blockBlack] ~-1 ~ ~ detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
execute @e[tag=blockBlack] ~ ~-1 ~ detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
execute @e[tag=blockBlack] ~ ~ ~-1 detect ~ ~ ~ stained_hardened_clay 15 setblock ~-1000 ~ ~-1000 command_block 0 replace {Command:"function game:misc/breakblack",auto:1}
setblock ~1000 ~ ~1000 air 0
setblock ~ ~ ~ air 0
particle reddust ~1000 ~ ~1000 0.3 0.3 0.3 1 50 force @a
playsound minecraft:block.stone.break master @a ~1000 ~ ~1000
execute @e[tag=newBreak,c=1] ~ 99 ~ kill @e[type=area_effect_cloud,dx=0,dz=0,dy=15,name=fallBlock]
scoreboard players tag @e[tag=newBreak,c=1] remove newBreak
summon minecraft:area_effect_cloud ~1000 100 ~1000 {CustomName:"fallBlock",Duration:100}