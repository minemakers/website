title @s[score_connection_min=1] title [{"text":"Welcome to","color":"green"}]
title @s[score_connection_min=1] subtitle [{"text":"Color Drop","color":"yellow"}]
playsound minecraft:entity.player.levelup master @s[score_connection_min=1] ~ ~ ~ 10000
stats entity @s set SuccessCount @s connection
spawnpoint @s 1000 101 1000
effect @s clear
clear @s
scoreboard players tag @s remove giveHotbar
scoreboard players tag @s add joined
scoreboard teams join lobby @s
scoreboard players test !gameStatus const 0 0
tp @s[score_connection_min=1] 1000 102 1000 0 0
gamemode 2 @s[score_connection_min=1]
scoreboard players test !gameStatus const 1 2
tp @s[score_connection_min=1] 1000 110 1000 0 35
gamemode 3 @s[score_connection_min=1]
stats entity @s clear SuccessCount
scoreboard players reset @s connection