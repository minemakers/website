execute @s[team=p1] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a1] add squareNS
execute @s[team=p2] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a2] add squareNS
execute @s[team=p5] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a5] add squareNS
execute @s[team=p6] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a6] add squareNS
execute @s[team=p3] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a3] add squareWE
execute @s[team=p4] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a4] add squareWE
execute @s[team=p7] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a7] add squareWE
execute @s[team=p8] ~ ~ ~ scoreboard players tag @e[type=area_effect_cloud,tag=a8] add squareWE
execute @e[type=area_effect_cloud,tag=squareNS] ~-5 ~4 ~ fill ~ ~ ~ ~-3 ~2 ~ stained_hardened_clay 15 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-5 ~4 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-7 ~4 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-6 ~5 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-8 ~5 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-5 ~6 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareNS] ~-7 ~6 ~ fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~4 ~5 fill ~ ~ ~ ~ ~2 ~3 stained_hardened_clay 15 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~4 ~5 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~4 ~7 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~5 ~6 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~5 ~8 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~6 ~5 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay
execute @e[type=area_effect_cloud,tag=squareWE] ~ ~6 ~7 fill ~ ~ ~ ~ ~ ~ stained_hardened_clay 12 replace stained_hardened_clay

scoreboard players tag @e[tag=squareNS] remove squareNS
scoreboard players tag @e[tag=squareWE] remove squareWE