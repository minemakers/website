clear @s
replaceitem entity @s slot.hotbar.0 minecraft:golden_pickaxe 1 0 {ench:[{id:0,lvl:1}],HideFlags:1023,display:{Name:"§6Block Destroyer",Lore:["§7Use this pickaxe to mine blocks"]},CanDestroy:["stained_hardened_clay"],Unbreakable:1}

replaceitem entity @s slot.hotbar.2 minecraft:dye 1 8 {display:{Name:"§c2 Lives (50 points)§7 - Not enough points",Lore:["§7Buy this to get 2 lives"]}}
replaceitem entity @s slot.hotbar.3 minecraft:dye 1 8 {display:{Name:"§cBlindness (25 points)§7 - Not enough points",Lore:["§7Buy this to blind the other players"]}}
replaceitem entity @s slot.hotbar.4 minecraft:dye 1 8 {display:{Name:"§cBig Yellow Square (90 points)§7 - Not enough points",Lore:["§7Buy this to color your board in yellow"]}}
replaceitem entity @s slot.hotbar.5 minecraft:dye 1 8 {display:{Name:"§cFreeze (50 points)§7 - Not enough points",Lore:["§7Buy this to freeze the other players"]}}
replaceitem entity @s slot.hotbar.6 minecraft:dye 1 8 {display:{Name:"§cBig Colored Square (75 points)§7 - Not enough points",Lore:["§7Buy this to color the board of another player"]}}

replaceitem entity @s[score_statPoints_min=50] slot.hotbar.2 emerald 1 0 {display:{Name:"§a2 Lives (50 points)§7 - Drop to buy",Lore:["§7Buy this to get 2 lives"]}}
replaceitem entity @s[score_statPoints_min=25] slot.hotbar.3 coal 1 1 {display:{Name:"§7Blindness (25 points)§7 - Drop to buy",Lore:["§7Buy this to blind the other players"]}}
replaceitem entity @s[score_statPoints_min=90] slot.hotbar.4 minecraft:dye 1 11 {display:{Name:"§eBig Yellow Square (90 points)§7 - Drop to buy",Lore:["§7Buy this to color your board in yellow"]}}
replaceitem entity @s[score_statPoints_min=50] slot.hotbar.5 ice 1 0 {display:{Name:"§bFreeze (50 points)§7 - Drop to buy",Lore:["§7Buy this to freeze the other players"]}}
replaceitem entity @s[score_statPoints_min=75] slot.hotbar.6 minecraft:magma 1 0 {display:{Name:"§dBig Colored Square (75 points)§7 - Drop to buy",Lore:["§7Buy this to color the board of another player"]}}

replaceitem entity @s slot.hotbar.8 barrier 1 0 {display:{Name:"§4End the round §7- Drop to use",Lore:["§7Use this to end the round"]}}
