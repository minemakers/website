scoreboard players set @a[tag=!joined] connection 1
execute @a[score_connection_min=0] ~ ~ ~ function game:players/connection

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countSecond const -1 -1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !countSecond const -21
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:loopsecond
scoreboard players add !countSecond const 1

execute @a[score_openVillager_min=1] ~ ~ ~ function game:misc/rules