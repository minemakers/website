scoreboard players remove !gameTimer const 60
title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"!gameTimer","objective":"const"}},{"text":" seconds"}]
scoreboard players test !gameTimer 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"!gameTimer","objective":"const"}},{"text":" second"}]
title @a title [{"text":"Round ","color":"green","bold":"true"},{"score":{"name":"!gameRound","objective":"const"}}]
scoreboard players add !gameTimer const 60
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000
title @a times 0 40 10