scoreboard players tag @r[x=1004,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=1004,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=1004,y=101,z=975,dx=9,dy=6,dz=12,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=987,y=101,z=975,dx=9,dy=6,dz=12,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=975,y=101,z=987,dx=12,dy=6,dz=9,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=975,y=101,z=1004,dx=12,dy=6,dz=9,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=987,y=101,z=1014,dx=9,dy=6,dz=12,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,m=2,score_statLife_min=1] statLife 1
scoreboard players tag @r[x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @r[x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] ~ ~ ~ scoreboard players remove @a[x=1014,y=101,z=987,dx=12,dy=6,dz=9,m=2,score_statLife_min=1] statLife 1

execute @e[type=area_effect_cloud,name=failPoint,tag=destroy] ~ ~ ~ setblock ~ ~ ~ air 0 destroy
execute @e[name=failPoint,type=area_effect_cloud,tag=destroy] ~ ~ ~ playsound minecraft:entity.chicken.egg master @a ~ ~ ~
scoreboard players set !gameTimer const -9
execute @e[type=area_effect_cloud,name=failPoint,tag=destroy] ~ ~ ~ scoreboard players set !gameTimer const -3
kill @e[name=failPoint,type=area_effect_cloud,tag=destroy]

execute @a[x=1014,y=101,z=987,dx=12,dy=6,dz=9,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=1014,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=1004,y=101,z=975,dx=9,dy=6,dz=12,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=1004,y=101,z=975,dx=9,dy=6,dz=12,name=failPoint,type=area_effect_cloud] add destroy
execute @a[x=987,y=101,z=975,dx=9,dy=6,dz=12,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=987,y=101,z=975,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=975,y=101,z=987,dx=12,dy=6,dz=9,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=975,y=101,z=987,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=975,y=101,z=1004,dx=12,dy=6,dz=9,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=975,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=987,y=101,z=1014,dx=9,dy=6,dz=12,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=987,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=1004,y=101,z=1014,dx=9,dy=6,dz=12,type=area_effect_cloud,name=failPoint] add destroy
execute @a[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,m=2,score_statLife=0] ~ ~ ~ scoreboard players tag @e[x=1014,y=101,z=1004,dx=12,dy=6,dz=9,type=area_effect_cloud,name=failPoint] add destroy

execute @a[score_statLife=0,m=2] ~ ~ ~ tellraw @a [{"text":"Sorry ","color":"yellow"},{"selector":"@s","color":"red"},{"text":", you are eliminated!"}]
execute @a[score_statLife=0,m=2] ~ ~ ~ playsound minecraft:entity.wither.death master @a ~ ~ ~ 100000 2
scoreboard teams join lobby @a[score_statLife=0,m=2]
gamemode 3 @a[score_statLife=0,m=2]
scoreboard players reset @a[score_statLife=0] statLife
title @a times 0 100 10