execute @p[team=p1] ~ ~ ~ fill 1013 107 975 1004 101 975 air 0 destroy
execute @p[team=p2] ~ ~ ~ fill 987 107 975 996 101 975 air 0 destroy
execute @p[team=p3] ~ ~ ~ fill 975 101 996 975 107 987 air 0 destroy
execute @p[team=p4] ~ ~ ~ fill 975 107 1004 975 101 1013 air 0 destroy
execute @p[team=p5] ~ ~ ~ fill 996 101 1025 987 107 1025 air 0 destroy
execute @p[team=p6] ~ ~ ~ fill 1013 101 1025 1004 107 1025 air 0 destroy
execute @p[team=p7] ~ ~ ~ fill 1025 101 1004 1025 107 1013 air 0 destroy
execute @p[team=p8] ~ ~ ~ fill 1025 101 987 1025 107 996 air 0 destroy


scoreboard players tag @e[type=Item] add block {Item:{id:"minecraft:stained_hardened_clay"}}
execute @e[type=item,tag=block] ~ ~ ~ summon minecraft:area_effect_cloud ~ ~ ~ {CustomName:"failPoint",Duration:10000}
execute @e[type=item,tag=block] ~ ~ ~ setblock ~ ~ ~ bedrock
kill @e[type=item,tag=block]