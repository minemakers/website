effect @a minecraft:saturation 1000000 100 true

scoreboard players test !gameTimer const -1000 1000
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players remove !gameTimer const 1

scoreboard players test !gameTimer const 2 60
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ title @a actionbar [{"score":{"objective":"const","name":"!gameTimer"},"italic":"true","color":"white"},{"text":" seconds remaining"}]
scoreboard players test !gameTimer const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ title @a actionbar [{"score":{"objective":"const","name":"!gameTimer"},"italic":"true","color":"white"},{"text":" second remaining"}]

scoreboard players test !gameTimer const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:controller/endround

scoreboard players test !gameTimer const -2 -2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:board/countinit

scoreboard players test !gameTimer const -10 -10
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !gameTimer const 66

scoreboard players test !gameTimer const 61 65
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:misc/countdown

scoreboard players test !gameTimer const 60 60
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:controller/startround