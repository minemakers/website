scoreboard players set @s[score_givePoints_min=1,score_givePoints=5] const 2
scoreboard players set @s[score_givePoints_min=6,score_givePoints=10] const 3
scoreboard players set @s[score_givePoints_min=11,score_givePoints=15] const 4
scoreboard players set @s[score_givePoints_min=16,score_givePoints=20] const 5
scoreboard players set @s[score_givePoints_min=21] const 6
scoreboard players operation @s givePoints *= @s const

title @s title [{"text":""}]
title @s times 0 30 5

title @s[score_const_min=2,score_const=2] subtitle [{"text":"+ ","color":"yellow","bold":"true"},{"score":{"name":"@s","objective":"givePoints"}},{"text":" points"}]
title @s[score_const_min=3,score_const=3] subtitle [{"text":"+ ","color":"green","bold":"true"},{"score":{"name":"@s","objective":"givePoints"}},{"text":" points (x1.5)"}]
title @s[score_const_min=4,score_const=4] subtitle [{"text":"+ ","color":"dark_green","bold":"true"},{"score":{"name":"@s","objective":"givePoints"}},{"text":" points (x2)"}]
title @s[score_const_min=5,score_const=5] subtitle [{"text":"+ ","color":"dark_purple","bold":"true"},{"score":{"name":"@s","objective":"givePoints"}},{"text":" points (x2.5)"}]
title @s[score_const_min=6,score_const=6] subtitle [{"text":"+ ","color":"dark_red","bold":"true"},{"score":{"name":"@s","objective":"givePoints"}},{"text":" points (x3)"}]

scoreboard players operation @s statPoints += @s givePoints
scoreboard players reset @s givePoints
scoreboard players reset @s const

function game:misc/hotbar