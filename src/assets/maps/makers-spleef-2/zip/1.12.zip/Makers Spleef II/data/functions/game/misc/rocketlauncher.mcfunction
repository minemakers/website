effect @s minecraft:levitation 1 30 true
particle explode ~ ~ ~ 1 1 1 0.3 100
fill ~1 ~-3 ~1 ~-1 ~-1 ~-1 air 0 replace stained_hardened_clay
fill ~1 ~-3 ~1 ~-1 ~-1 ~-1 air 0 replace hardened_clay
playsound minecraft:entity.generic.explode master @a
scoreboard players reset @s useFirework
kill @e[type=FireworksRocketEntity]