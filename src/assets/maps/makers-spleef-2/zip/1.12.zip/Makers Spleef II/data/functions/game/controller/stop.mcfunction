gamerule gameLoopFunction game:looplobby
scoreboard players set !gameStatus const 0
playsound minecraft:entity.enderdragon.ambient master @a ~ ~ ~ 10000 1.5
title @a times 0 100 10
title @a subtitle [{"text":""}]
title @a title [{"text":"Draw","color":"red"}]

scoreboard players set !timer const 0

scoreboard teams option team color gold
execute @a[m=2,c=1] ~ ~ ~ title @a title [{"text":"The Winner is","color":"red"}]
execute @a[m=2,c=1] ~ ~ ~ title @a subtitle [{"selector":"@p[x=1000,y=100,z=1000,r=100,m=2]"}]
execute @a[m=2,c=1] ~ ~ ~ tellraw @a [{"selector":"@p[x=1000,y=100,z=1000,r=100,m=2]"},{"text":" won the game!","color":"yellow"}]
scoreboard teams option team friendlyfire false
scoreboard teams option team color gray

scoreboard players add @a[m=2,c=1] winGame 1
advancement grant @a[m=2,c=1] only game:win1
advancement grant @a[m=2,tag=invisible,c=1] only game:invisible
scoreboard players tag @a[m=2,c=1] add freeze {ActiveEffects:[{Id:2b}]}
advancement grant @a[tag=freeze] only game:freeze
scoreboard players tag @a[tag=freeze] remove freeze
advancement grant @a[m=2,c=1,score_winGame_min=5,score_winGame=5] only game:win2
advancement grant @a[m=2,c=1,score_winGame_min=15,score_winGame=15] only game:win3
advancement grant @a[m=2,c=1,score_winGame_min=30,score_winGame=30] only game:win4

execute @a ~ ~ ~ stats entity @s set SuccessCount @s const
scoreboard players set @a const 0

execute @a ~ ~ ~ advancement test @s game:pickaxe3
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:zombie
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:mine3
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win4
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:pickaxe4

execute @a ~ ~ ~ advancement test @s game:pickaxe2
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:players
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:mine2
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win3
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:pickaxe3

execute @a ~ ~ ~ advancement test @s game:pickaxe1
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:arena
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:mode
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win2
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:pickaxe2

execute @a ~ ~ ~ advancement test @s game:root
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win1
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:pickaxe1

scoreboard players reset * testingMode
scoreboard players reset * rightClick
scoreboard players reset * useFirework
scoreboard players reset * useClay
scoreboard players reset @a const
kill @e[type=xp_orb]
kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=creeper]
kill @e[type=chicken]
execute @a[c=1] ~ ~ ~ function game:controller/arena
scoreboard players set @a connection 0