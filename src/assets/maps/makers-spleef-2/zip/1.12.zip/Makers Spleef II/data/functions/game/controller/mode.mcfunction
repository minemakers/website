stats entity @s set SuccessCount @s const
scoreboard players set @s const 0
scoreboard players test !gameMode const 8 100
execute @s[score_const_min=1] ~ ~ ~ scoreboard players set !gameMode const 0
scoreboard players test !gameMode const 0 0
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§f§lClassic",Item:{id:"minecraft:skull",Damage:3s,tag:{SkullOwner:{Id:"bc461525-6511-4417-92d7-f2ff0ab15b89",Properties:{textures:[{}]}}}}}
scoreboard players test !gameMode const 1 1
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§7§lArrow",Item:{id:"minecraft:skull",Damage:0s,tag:{}}}
scoreboard players test !gameMode const 2 2
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§b§lBunny",Item:{id:"minecraft:skull",Damage:3s,tag:{SkullOwner:{Id:"f2544255-6511-442d-92d7-f2ff09755b89",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmU1MGFmNTA0MzhhZmZjNjVjZTNiN2E4NWI4ZTgyY2ZiYzNjYWIxOTdjMjVkNGE2MTQyMzBhMmQxZTA2MDVkIn19fQ=="}]}}}}}
scoreboard players test !gameMode const 3 3
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§a§lCreeper",Item:{id:"minecraft:skull",Damage:4s,tag:{}}}
scoreboard players test !gameMode const 4 4
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§2§lZombie",Item:{id:"minecraft:skull",Damage:2s,tag:{}}}
scoreboard players test !gameMode const 5 5
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§6§lItems",Item:{id:"minecraft:skull",Damage:3s,tag:{SkullOwner:{Id:"0a9e8efb-9191-4c81-80f5-e27ca5433156",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODIyZDhlNzUxYzhmMmZkNGM4OTQyYzQ0YmRiMmY1Y2E0ZDhhZThlNTc1ZWQzZWIzNGMxOGE4NmU5M2IifX19"}]}}}}}
scoreboard players test !gameMode const 6 6
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§e§lEvents",Item:{id:"minecraft:skull",Damage:3s,tag:{SkullOwner:{Id:"eb405652-f501-44b3-86f7-9fa2eebd5303",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNWNmYWRhZWM3NzZlZWRlNDlhNDMzZTA5OTdmZTA0NDJmNzY1OTk4OTI0MTliYWFiODNkMjhlOGJhN2YxZjMifX19"}]}}}}}
scoreboard players test !gameMode const 7 7
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentMode] {CustomName:"§5§lInsane",Item:{id:"minecraft:skull",Damage:1s,tag:{}}}
stats entity @s clear SuccessCount
scoreboard players reset @s const