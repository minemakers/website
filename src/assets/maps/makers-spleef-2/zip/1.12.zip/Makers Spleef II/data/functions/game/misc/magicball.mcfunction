particle flame ~ ~ ~ 0 0 0 0.1 5 force @a
scoreboard players add @s useFirework 1
execute @s[score_useFirework_min=2] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-2 ~-1 air 0 replace stained_hardened_clay
execute @s[score_useFirework_min=2] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-2 ~-1 air 0 replace hardened_clay