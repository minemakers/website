execute @s ~ ~ ~ scoreboard players tag @a[rm=0,c=1] add damage {HurtTime:9s}
execute @a[tag=damage] ~ ~ ~ playsound minecraft:entity.illusion_illager.prepare_mirror master @a ~ ~ ~ 1 0.2
execute @a[tag=damage] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-3 ~-1 air 0 replace stained_hardened_clay
execute @a[tag=damage] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-3 ~-1 air 0 replace hardened_clay
tp @a[tag=damage] ~ ~-1 ~
scoreboard players tag @a[tag=damage] remove damage
scoreboard players reset @s breakAxe