tellraw @s[tag=!respawn] [{"text":"You now have a second life!","color":"green"}]
playsound minecraft:entity.player.levelup master @s[tag=!respawn] ~ ~ ~ 10000
tellraw @s[tag=respawn] [{"text":"Sorry, you already have a second life!","color":"red"}]
advancement grant @s[tag=respawn] only game:lives
playsound minecraft:entity.item.break master @s[tag=respawn] ~ ~ ~ 10000
scoreboard players tag @s add respawn
scoreboard players tag @s remove secondLife
clear @s emerald