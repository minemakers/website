execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 3 3
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ function game:events/creeper
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 4 4
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2,c=1] ~ ~ ~ function game:events/zombie
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 5 5
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ function game:events/item
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 6 6
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2,c=1] ~ ~ ~ function game:events/event
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 7 7
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ function game:events/item
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[m=2,c=1] ~ ~ ~ function game:events/event
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @r[m=2] ~ ~ ~ summon Zombie ~ ~30 ~ {Attributes:[{Name:"generic.maxHealth",Base:1000},{Name:"generic.movementSpeed",Base:0.35}],HandItems:[{id:iron_shovel,Count:1b,tag:{ench:[{id:19,lvl:3}]}}],ArmorItems:[{},{},{},{id:tnt,Count:1b,Damage:0s,tag:{Unbreakable:1}}],IsBaby:1,Tags:["explode"],Invulnerable:1}