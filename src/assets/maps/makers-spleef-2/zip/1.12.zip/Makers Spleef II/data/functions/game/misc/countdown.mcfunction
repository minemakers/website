scoreboard players remove !countDown const 1
title @a title [{"text":"Makers Spleef","color":"green"}]
title @a subtitle [{"text":"Game starts in ","color":"yellow"},{"score":{"name":"!countDown","objective":"const"}}]
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countDown const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:controller/start
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000