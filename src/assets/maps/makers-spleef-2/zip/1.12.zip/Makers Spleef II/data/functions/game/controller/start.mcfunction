gamerule gameLoopFunction game:loopgame
title @a subtitle [{"text":"The Game has just started! ","color":"yellow"}]
title @a times 0 50 10
scoreboard players set !gameStatus const 2
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 10000 
effect @a clear
clear @a
effect @a minecraft:weakness 1000000 100 true
effect @a minecraft:resistance 1000000 255 true
effect @a minecraft:jump_boost 2 255 true
scoreboard teams option team friendlyfire true
scoreboard players tag @a remove respawn
replaceitem entity @a[m=2] slot.hotbar.0 minecraft:wooden_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§6Wooden Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"]}
replaceitem entity @a[score_cosPickaxe_min=2,score_cosPickaxe=2,m=2] slot.hotbar.0 minecraft:stone_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§7Stone Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"]}
replaceitem entity @a[score_cosPickaxe_min=4,score_cosPickaxe=4,m=2] slot.hotbar.0 minecraft:golden_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§eGolden Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"]}
replaceitem entity @a[score_cosPickaxe_min=3,score_cosPickaxe=3,m=2] slot.hotbar.0 minecraft:iron_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§fIron Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"]}
replaceitem entity @a[score_cosPickaxe_min=5,score_cosPickaxe=5,m=2] slot.hotbar.0 minecraft:diamond_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§bDiamond Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"]}
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ replaceitem entity @a[m=2] slot.hotbar.0 bow 1 0 {ench:[{id:49,lvl:3},{id:51,lvl:1}],Unbreakable:1,HideFlags:1023,display:{Name:"§6Magic Bow"},tool:true}
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ effect @a[m=2] speed 1000000 3 true
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 7 7
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ effect @a[m=2] speed 1000000 2 true
advancement grant @a[m=2] only game:root
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode0
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode1
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode2
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 3 3
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode3
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 4 4
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode4
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 5 5
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode5
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 6 6
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode6
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 7 7
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add mode7
execute @a[tag=mode0] ~ ~ ~ execute @s[tag=mode1] ~ ~ ~ execute @s[tag=mode2] ~ ~ ~ execute @s[tag=mode3] ~ ~ ~ execute @s[tag=mode4] ~ ~ ~ execute @s[tag=mode5] ~ ~ ~ execute @s[tag=mode6] ~ ~ ~ execute @s[tag=mode7] ~ ~ ~ advancement grant @s only game:mode
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameArena const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena0
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameArena const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena1
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameArena const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena2
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameArena const 3 3
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena3
execute @a[tag=arena0] ~ ~ ~ execute @s[tag=arena1] ~ ~ ~ execute @s[tag=arena2] ~ ~ ~ execute @s[tag=arena3] ~ ~ ~ advancement grant @s only game:arena

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const_min=5] ~ ~ ~ advancement grant @a[m=2] only game:players