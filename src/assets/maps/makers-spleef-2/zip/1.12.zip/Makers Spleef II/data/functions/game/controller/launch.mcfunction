execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const=1] ~ ~ ~ tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"},{"text":"\n ► Click here to enter in Testing Mode","color":"gray","hoverEvent":{"action":"show_text","value":"click!"},"clickEvent":{"action":"run_command","value":"/trigger testingMode set 34789134"}}]
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const=1] ~ ~ ~ playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const_min=2] ~ ~ ~ function game:controller/prestart