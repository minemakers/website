execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countDown const 1 6
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:misc/countdown
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameStatus const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !gameMode const 3 7
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players remove !countEvent const 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !countEvent const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !countEvent const 7
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:controller/event

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameStatus const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !gameMode const 4 4
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players add !timer const 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !timer const 300 300
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ advancement grant @a[m=2] only game:zombie


effect @a minecraft:saturation 1 255 true
clear @a arrow
replaceitem entity @a[m=2] slot.inventory.0 minecraft:arrow
entitydata @e[type=Arrow] {life:1198}
xp -100L @a
execute @e[name=stick,type=armor_stand] ~ ~ ~ particle reddust ~ ~0.8 ~0.3 0 0 0.2 1 10