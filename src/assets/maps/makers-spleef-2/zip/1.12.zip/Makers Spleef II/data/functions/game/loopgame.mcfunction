function game:looplobby

#	stop game
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @a[score_testingMode_min=34789135,score_testingMode=34789135,m=2] ~ ~ ~ scoreboard players add @e[type=area_effect_cloud,name=success] const 1
execute @e[type=area_effect_cloud,name=success,score_const=1] ~ ~ ~ function game:controller/stop

#	elimination
scoreboard players tag @a add invulnerable {ActiveEffects:[{Id:26b}]}
execute @a[m=2,tag=!invulnerable] ~ ~ ~ detect ~ ~-0.2 ~ wool -1 function game:players/eliminate
execute @a[m=2,tag=!invulnerable] ~ ~ ~ detect ~ ~-0.5 ~ air 0 execute @s ~ ~ ~ detect ~ ~-0.2 ~.3 wool -1 function game:players/eliminate
execute @a[m=2,tag=!invulnerable] ~ ~ ~ detect ~ ~-0.5 ~ air 0 execute @s ~ ~ ~ detect ~.3 ~-0.2 ~ wool -1 function game:players/eliminate
execute @a[m=2,tag=!invulnerable] ~ ~ ~ detect ~ ~-0.5 ~ air 0 execute @s ~ ~ ~ detect ~ ~-0.2 ~-.3 wool -1 function game:players/eliminate
execute @a[m=2,tag=!invulnerable] ~ ~ ~ detect ~ ~-0.5 ~ air 0 execute @s ~ ~ ~ detect ~-.3 ~-0.2 ~ wool -1 function game:players/eliminate
execute @a[x=850,y=60,z=850,dx=300,dy=27,dz=300,m=2] ~ ~ ~ function game:players/eliminate
scoreboard players tag @a[tag=invulnerable] remove invulnerable

#	Items Effects/CustomName
scoreboard players tag @a add secondLife {Inventory:[{id:"minecraft:emerald"}]}
execute @a[tag=secondLife] ~ ~ ~ function game:misc/secondlife
execute @a[score_useFirework_min=1] ~ ~ ~ function game:misc/rocketlauncher
execute @e[x=1000,y=100,z=1000,r=200,type=xp_orb] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air 0 replace stained_hardened_clay
execute @e[x=1000,y=100,z=1000,r=200,type=xp_orb] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air 0 replace hardened_clay
execute @e[type=item,tag=bonus] ~ ~ ~ detect ~ ~-.2 ~ wool -1 spreadplayers 1000 1000 0 23 false @s
execute @e[type=item,tag=bonus] ~ ~ ~ detect ~ ~-.2 ~ wool -1 spreadplayers 1000 1000 0 23 false @s
execute @e[type=item,tag=bonus] ~ ~ ~ detect ~ ~-.2 ~ wool -1 spreadplayers 1000 1000 0 23 false @s
execute @e[type=item,tag=bonus] ~ ~ ~ detect ~ ~-.2 ~ wool -1 kill @s
execute @e[x=1000,y=100,z=1000,r=200,type=Snowball] ~ ~ ~ function game:misc/magicball
execute @a[score_rightClick_min=1] ~ ~ ~ function game:misc/spreadplayers
execute @e[type=Arrow] ~ ~ ~ particle reddust ~ ~ ~ 0.15 0.15 0.15 1 5 force
execute @e[type=Arrow] ~ ~.7 ~ fill ~1 ~2 ~1 ~-1 ~-2 ~-1 air 0 replace stained_hardened_clay
execute @e[type=Arrow] ~ ~.7 ~ fill ~1 ~2 ~1 ~-1 ~-2 ~-1 air 0 replace hardened_clay

clear @a minecraft:glass_bottle
execute @e[type=chicken,tag=taupe] ~ ~ ~ fill ~2 ~2 ~2 ~-2 ~-2 ~-2 air 0 replace stained_hardened_clay
execute @e[type=chicken,tag=taupe] ~ ~ ~ fill ~2 ~2 ~2 ~-2 ~-2 ~-2 air 0 replace hardened_clay

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameMode const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ effect @a[m=2] jump_boost 1000000 5 true

scoreboard players add @e[type=area_effect_cloud,name=item] const 1
scoreboard players set @e[type=area_effect_cloud,name=item,score_const_min=-77] const -99
execute @e[type=area_effect_cloud,name=item,score_const_min=-99,score_const=-99] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eB§6onus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-97,score_const=-97] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6B§eo§6nus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-95,score_const=-95] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bo§en§6us",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-93,score_const=-93] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bon§eu§6s",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-91,score_const=-91] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bonu§es",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-89,score_const=-89] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bon§eus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-87,score_const=-87] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bo§enus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-85,score_const=-85] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6B§eonus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-83,score_const=-83] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBonu§6s",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-81,score_const=-81] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBon§6us",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-79,score_const=-79] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBo§6nus",CustomNameVisible:1}

scoreboard players tag @a[m=2] add outArena
execute @a[tag=outArena] ~ ~ ~ detect ~ 100 ~ wool -1 scoreboard players tag @s remove outArena
execute @a[tag=outArena] ~ ~ ~ fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air 0 replace stained_hardened_clay 0

effect @a[score_sneak_min=1,m=2] glowing 1 0 true
scoreboard players reset @a[score_sneak_min=1] sneak

execute @a[x=850,y=118,z=850,dx=300,dy=20,dz=300,m=2,score_useClay_min=1] ~ ~ ~ fill ~7 120 ~7 ~-7 121 ~-7 air 0 replace stained_hardened_clay 0
scoreboard players reset @a[score_useClay_min=1] useClay

execute @a[x=850,y=118,z=850,dx=300,dy=20,dz=300,m=2,score_useWeb_min=1] ~ ~ ~ fill ~7 120 ~7 ~-7 121 ~-7 air 0 replace web 0
scoreboard players reset @a[score_useWeb_min=1] useWeb

execute @e[type=chicken,tag=taupe] ~ ~ ~ teleport @e[name=head_mole,type=armor_stand,c=1] ~ ~-1.4 ~
scoreboard players tag @e[name=head_mole,type=armor_stand] add kill
execute @e[type=chicken,tag=taupe] ~ ~ ~ scoreboard players tag @e[name=head_mole,type=armor_stand,c=1] remove kill
kill @e[name=head_mole,type=armor_stand,tag=kill]

execute @a[score_breakAxe_min=1] ~ ~ ~ function game:misc/smasher

execute @a[score_mineBlock_min=500,score_mineBlock=550] ~ ~ ~ advancement grant @s only game:mine1
execute @a[score_mineBlock_min=2000,score_mineBlock=2050] ~ ~ ~ advancement grant @s only game:mine2
execute @a[score_mineBlock_min=10000,score_mineBlock=10050] ~ ~ ~ advancement grant @s only game:mine3

scoreboard players tag @a add givePickaxe
scoreboard players tag @a remove givePickaxe {Inventory:[{tag:{tool:true}}]}
replaceitem entity @a[m=2,tag=givePickaxe] slot.hotbar.0 minecraft:wooden_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§6Wooden Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"],tool:true}
replaceitem entity @a[score_cosPickaxe_min=2,score_cosPickaxe=2,m=2,tag=givePickaxe] slot.hotbar.0 minecraft:stone_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§7Stone Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"],tool:true}
replaceitem entity @a[score_cosPickaxe_min=4,score_cosPickaxe=4,m=2,tag=givePickaxe] slot.hotbar.0 minecraft:golden_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§eGolden Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"],tool:true}
replaceitem entity @a[score_cosPickaxe_min=3,score_cosPickaxe=3,m=2,tag=givePickaxe] slot.hotbar.0 minecraft:iron_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§fIron Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"],tool:true}
replaceitem entity @a[score_cosPickaxe_min=5,score_cosPickaxe=5,m=2,tag=givePickaxe] slot.hotbar.0 minecraft:diamond_pickaxe 1 0 {ench:[{id:32,lvl:100}],display:{Name:"§bDiamond Pickaxe"},Unbreakable:1,HideFlags:2047,AttributeModifiers:[{AttributeName:"generic.attackSpeed",Name:"generic.attackSpeed",Amount:0,Operation:0,UUIDMost:1,UUIDLeast:1}],CanDestroy:["stained_hardened_clay","hardened_clay"],tool:true}
