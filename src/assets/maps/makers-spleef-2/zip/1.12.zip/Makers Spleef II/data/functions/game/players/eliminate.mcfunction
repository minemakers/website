tellraw @s[x=850,y=60,z=850,dx=300,dy=27,dz=300,tag=respawn] [{"text":"Your second life can't save you here...","color":"red"}]
scoreboard players tag @s[x=850,y=60,z=850,dx=300,dy=27,dz=300] remove respawn
tellraw @s[tag=respawn] [{"text":"You no longer have a second life!","color":"red"}]
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const=2] ~ ~ ~ execute @a[x=850,y=60,z=850,dx=300,dy=27,dz=300,m=2] ~ ~ ~ advancement grant @a[m=2,rm=0] only game:out
playsound minecraft:entity.item.break master @s[tag=respawn] ~ ~ ~ 10000
effect @s[tag=respawn] minecraft:levitation 1 30 true
tp @s[tag=respawn] ~ ~4 ~
execute @s[tag=!respawn] ~ ~ ~ tellraw @a [{"text":"Sorry ","color":"red"},{"selector":"@s"},{"text":", you are eliminated!"}]
execute @s[tag=!respawn] ~ ~ ~ playsound minecraft:entity.wither.death master @a ~ ~ ~ 10000 2
gamemode 3 @s[tag=!respawn]
scoreboard players tag @s remove respawn