stats entity @s set SuccessCount @s random
execute @s ~ ~ ~ function game:events/random

summon area_effect_cloud ~ ~ ~ {CustomName:"summonItem"}
spreadplayers 1000 1000 0 23 false @e[type=area_effect_cloud,name=summonItem]

scoreboard players set @s random 0
scoreboard players test result! random 0 10
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"stained_hardened_clay",Count:16b,tag:{display:{Name:"§7Block"},HideFlags:2047,CanPlaceOn:["minecraft:wool","stained_hardened_clay","hardened_clay"]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 11 18
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"web",Count:3b,tag:{CanPlaceOn:["stained_hardened_clay","wool","hardened_clay"],display:{Name:"§7Cobweb"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 19 29
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"ender_pearl",Count:2b,tag:{display:{Name:"§7Ender Pearl"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 30 34
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"carrot_on_a_stick",Count:1b,tag:{display:{Name:"§7Spreadplayers"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 38 45
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"fireworks",Count:1b,tag:{display:{Name:"§7Rocket"},HideFlags:2047,CanPlaceOn:["minecraft:stained_hardened_clay","minecraft:wool","hardened_clay"]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 46 56
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"potion",Count:1b,tag:{display:{Name:"§7Potion of Invisibility"},HideFlags:2047,CustomPotionColor:14935011,CustomPotionEffects:[{Id:14,Amplifier:0,Duration:400}]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 57 62
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"wooden_sword",Damage:59s,Count:1b,tag:{display:{Name:"§7Pusher"},HideFlags:2047,ench:[{id:16,lvl:1000},{id:19,lvl:6}]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 63 68
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"bow",Damage:384s,Count:1b,tag:{display:{Name:"§7Bow"},HideFlags:2047,ench:[{id:49,lvl:3},{id:51,lvl:1}]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 69 79
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"experience_bottle",Count:1b,tag:{display:{Name:"§7Clay Solvant"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 80 87
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"snowball",Count:1b,tag:{display:{Name:"§7Magic Ball"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 88 90
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"emerald",Count:1b,tag:{display:{Name:"§7Bonus Life"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 91 96
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"potion",Count:1b,tag:{display:{Name:"§7Potion of Invincibility"},HideFlags:2047,CustomPotionColor:285462,CustomPotionEffects:[{Id:26,Amplifier:0,Duration:200}]}},Tags:["bonus","invulnerable"]}
scoreboard players test result! random 97 100
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Item:{id:"golden_axe",Count:1b,Damage:32s,tag:{ench:[{id:16,lvl:10}],display:{Name:"§7Smasher"},HideFlags:2047}},Tags:["bonus","invulnerable"]}
scoreboard players reset @s random
kill @e[type=area_effect_cloud,name=summonItem]