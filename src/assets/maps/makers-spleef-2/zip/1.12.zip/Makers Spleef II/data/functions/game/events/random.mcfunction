stats entity @s set SuccessCount @s random
scoreboard players set @s random 0
scoreboard players operation seed! random *= a! random
scoreboard players operation seed! random += c! random
scoreboard players test seed! random -2147483648 -1
execute @s[score_random_min=1] ~ ~ ~ scoreboard players operation seed! random *= inv! random
scoreboard players operation result! random = seed! random
scoreboard players operation result! random /= b! random
scoreboard players operation result! random %= m! random