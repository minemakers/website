spreadplayers 1000 1000 0 23 false @a[m=2]
tp @a[m=2] ~ ~5 ~
effect @a[m=2] minecraft:levitation 1 30 true
clear @s minecraft:carrot_on_a_stick 0 1
playsound minecraft:entity.endermen.teleport master @a ~ ~ ~ 100000
scoreboard players reset @s rightClick