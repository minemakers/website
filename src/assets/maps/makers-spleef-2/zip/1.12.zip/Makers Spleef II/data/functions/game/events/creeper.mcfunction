execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air 0 replace stained_hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air 0 replace hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ particle explode ~ ~ ~ 1 1 1 0.3 100
execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ playsound minecraft:entity.generic.explode master @a ~ ~ ~ 100000 1
kill @e[x=1000,y=100,z=1000,r=70,type=Creeper]
playsound minecraft:entity.creeper.primed master @a ~ ~ ~ 10000 0.6
execute @a[m=2] ~ ~ ~ summon minecraft:creeper ~ ~30 ~ {Invulnerable:1,Tags:["creeper"],Fuse:10000,Attributes:[{Name:"generic.movementSpeed",Base:0.4}]}