title @s[score_connection_min=1] title [{"text":"Welcome to","color":"green"}]
title @s[score_connection_min=1] subtitle [{"text":"Makers Spleef","color":"gold"}]
playsound minecraft:entity.player.levelup master @s[score_connection_min=1] ~ ~ ~ 10000
stats entity @s set SuccessCount @s connection
spawnpoint @s 1000 141 940
effect @s clear
clear @s
scoreboard players tag @s[tag=resurrected] remove resurrected
scoreboard teams join team @s
scoreboard players test !gameStatus const 0 0
tp @s[score_connection_min=1] 1000 141 940 0 35
gamemode 2 @s[score_connection_min=1]
scoreboard players test !gameStatus const 1 2
tp @s[score_connection_min=1] 1000 125 965 0 30
gamemode 3 @s[score_connection_min=1]
stats entity @s clear SuccessCount
scoreboard players reset @s connection