scoreboard players set @a[x=0,y=100,z=0,r=50,tag=!admin] connection 1
execute @a[score_connection_min=0] ~ ~ ~ function game:players/connection

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countSecond const -1 -1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !countSecond const -21
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:loopsecond
scoreboard players add !countSecond const 1

scoreboard players enable @a testingMode
execute @a[m=2] ~ ~ ~ scoreboard players reset @a[rm=0] testingMode
execute @a[score_testingMode_min=34789134,score_testingMode=34789134] ~ ~ ~ function game:controller/prestart
scoreboard players add @a[score_testingMode_min=34789134,score_testingMode=34789134] testingMode 1

kill @e[type=item,tag=!invulnerable]
replaceitem entity @a[x=986,y=140,z=922,dx=28,dy=100,dz=28,m=2] slot.weapon minecraft:air

#cosmetics
scoreboard players tag @a[tag=invisible] remove invisible
scoreboard players tag @a[tag=hat] remove hat
scoreboard players tag @a add invisible {ActiveEffects:[{Id:14b}]}
scoreboard players tag @a add hat {Inventory:[{Slot:103b}]}
execute @a[tag=invisible] ~ ~ ~ replaceitem entity @s[tag=hat] slot.armor.head air
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=1,score_cosHat_min=1] skull
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=1,score_cosHat_min=1] slot.armor.head skull 1 5 {display:{Name:"§aDragon Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=2,score_cosHat_min=2] hay_block
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=2,score_cosHat_min=2] slot.armor.head hay_block 1 0 {display:{Name:"§cHay Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=3,score_cosHat_min=3] dispenser
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=3,score_cosHat_min=3] slot.armor.head dispenser 1 0 {display:{Name:"§7Dispenser Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=4,score_cosHat_min=4] command_block
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=4,score_cosHat_min=4] slot.armor.head command_block 1 0 {display:{Name:"§9Command Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=5,score_cosHat_min=5] lit_pumpkin
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=5,score_cosHat_min=5] slot.armor.head lit_pumpkin 1 0 {display:{Name:"§eHalloween Hat"}}
execute @e[score_cosParticle_min=1,score_cosParticle=1,tag=!invisible] ~ ~ ~ particle happyVillager ~ ~0.3 ~ 0.3 0.6 0.3 1 1
execute @e[score_cosParticle_min=2,score_cosParticle=2,tag=!invisible] ~ ~ ~ particle mobSpell ~ ~2.3 ~ 0.3 0.3 0.3 1 1
execute @e[score_cosParticle_min=3,score_cosParticle=3,tag=!invisible] ~ ~ ~ particle dragonbreath ~ ~0.4 ~ 0.2 0.2 0.2 0.001 1
execute @e[score_cosParticle_min=4,score_cosParticle=4,tag=!invisible] ~ ~ ~ particle note ~ ~2.5 ~ 0.3 0.3 0.3 1 1
execute @e[score_cosParticle_min=5,score_cosParticle=5,tag=!invisible] ~ ~ ~ particle endRod ~ ~ ~ 0.3 0.3 0.3 0.05 1
particle blockcrack 995 142 946 0.2 0.2 0.2 0.1 3 normal @a 166
execute @a[score_jump_min=5000,score_jump=5000] ~ ~ ~ advancement grant @s only game:jump

clear @a minecraft:bow 365 1
clear @a minecraft:wooden_sword 57 1
