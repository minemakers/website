scoreboard players set !gameStatus const 1
scoreboard players set !countDown const 6
effect @a minecraft:resistance 1000000 255 true
effect @a minecraft:invisibility 1000000 0 true
effect @a minecraft:instant_health 1 100 true
effect @a minecraft:weakness 1000000 100 true
title @a times 0 50 10
scoreboard players tag @a[tag=resurrected] remove resurrected

spreadplayers 1002 997 0 20 false @a[m=2]
tp @a[m=2] ~ 136 ~
effect @a levitation 1000000 255 true
execute @a[c=1] ~ ~ ~ function game:controller/arena

kill @e[type=xp_orb]
kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=creeper]
kill @e[type=chicken]

tellraw @a [{"text":"Rules: ","color":"gold"},{"text":"With your tools, dig under your opponents to make them fall on the wool. If you touch the wool, you die. You have to be the last player alive!","color":"gray"}]