stats entity @s set SuccessCount @s const
scoreboard players set @s const 0
scoreboard players test !gameArena const 4 100
execute @s[score_const_min=1] ~ ~ ~ scoreboard players set !gameArena const 0

fill 957 100 957 1042 103 1042 air 0 replace minecraft:stained_hardened_clay
fill 957 104 957 1042 107 1042 air 0 replace minecraft:stained_hardened_clay
fill 957 108 957 1042 111 1042 air 0 replace minecraft:stained_hardened_clay
fill 957 112 957 1042 115 1042 air 0 replace minecraft:stained_hardened_clay
fill 957 116 957 1042 119 1042 air 0 replace minecraft:stained_hardened_clay
fill 957 120 957 1042 123 1042 air 0 replace minecraft:stained_hardened_clay


scoreboard players test !gameArena const 0 0
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentArena] {CustomName:"§2§lJungle",Item:{id:"minecraft:leaves"}}
scoreboard players test !gameArena const 0 0
execute @s[score_const_min=1] ~ ~ ~ clone -23 38 -18 51 39 52 966 101 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 40 -18 51 41 52 966 103 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 42 -18 51 43 52 966 105 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 44 -18 51 45 52 966 107 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 46 -18 51 47 52 966 109 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 48 -18 51 49 52 966 111 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 50 -18 51 52 52 966 113 966

scoreboard players test !gameArena const 1 1
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentArena] {CustomName:"§6§lBeach",Item:{id:"minecraft:sand"}}
scoreboard players test !gameArena const 1 1
execute @s[score_const_min=1] ~ ~ ~ clone -23 0 -18 51 1 52 964 101 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 2 -18 51 3 52 964 103 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 4 -18 51 5 52 964 105 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 6 -18 51 7 52 964 107 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 8 -18 51 9 52 964 109 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 10 -18 51 11 52 964 111 964
execute @s[score_const_min=1] ~ ~ ~ clone -23 12 -18 51 14 52 964 113 964

scoreboard players test !gameArena const 2 2
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentArena] {CustomName:"§3§lAntarctic",Item:{id:"minecraft:ice"}}
scoreboard players test !gameArena const 2 2
execute @s[score_const_min=1] ~ ~ ~ clone -23 58 -18 51 59 52 966 101 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 60 -18 51 61 52 966 103 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 62 -18 51 63 52 966 105 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 64 -18 51 65 52 966 107 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 66 -18 51 67 52 966 109 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 68 -18 51 69 52 966 111 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 70 -18 51 72 52 966 113 966

scoreboard players test !gameArena const 3 3
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=currentArena] {CustomName:"§4§lVolcano",Item:{id:"minecraft:magma"}}
scoreboard players test !gameArena const 3 3
execute @s[score_const_min=1] ~ ~ ~ clone -23 19 -18 51 20 52 960 101 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 21 -18 51 22 52 960 103 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 23 -18 51 24 52 960 105 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 25 -18 51 26 52 960 107 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 27 -18 51 28 52 960 109 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 29 -18 51 30 52 960 111 966
execute @s[score_const_min=1] ~ ~ ~ clone -23 30 -18 51 32 52 960 113 966


stats entity @s clear SuccessCount
scoreboard players reset @s const