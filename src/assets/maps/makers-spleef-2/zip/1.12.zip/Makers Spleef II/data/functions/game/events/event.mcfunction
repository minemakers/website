stats entity @s set SuccessCount @s random
execute @s ~ ~ ~ function game:events/random
scoreboard players set @s random 0

execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air 0 replace hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,type=Zombie,tag=explode] ~ ~ ~ fill ~-2 ~-2 ~-2 ~2 ~2 ~2 air 0 replace hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,type=Creeper] ~ ~ ~ fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air 0 replace stained_hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,type=Zombie,tag=explode] ~ ~ ~ fill ~-2 ~-2 ~-2 ~2 ~2 ~2 air 0 replace stained_hardened_clay
execute @e[x=1000,y=100,z=1000,r=70,tag=explode] ~ ~ ~ particle explode ~ ~ ~ 1 1 1 0.3 100
execute @e[x=1000,y=100,z=1000,r=70,tag=explode] ~ ~ ~ playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 1
kill @e[x=1000,y=100,z=1000,r=70,type=Creeper]
kill @e[x=1000,y=100,z=1000,r=70,type=Zombie,tag=explode]

scoreboard players test result! random 0 4
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Freeze!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:block.glass.break master @a ~ ~ ~ 100000 1
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:jump_boost 6 250 true
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:slowness 6 250 true
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ particle snowshovel ~ ~0.5 ~ 0.5 1 0.5 0.05 300

scoreboard players test result! random 5 9
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Mole!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.horse.eat master @a ~ ~ ~ 10000 1.2
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:chicken ~ ~5 ~ {ActiveEffects:[{Id:14b,Amplifier:1,Duration:10000,ShowParticles:false},{Id:6b,Amplifier:4,Duration:1,ShowParticles:false}],Silent:1,Attributes:[{Name:"generic.maxHealth",Base:20},{Name:"generic.movementSpeed",Base:0.4}],Fire:1000s,Tags:["taupe"]}
execute @e[type=chicken,tag=taupe] ~ ~ ~ summon minecraft:armor_stand ~ ~ ~ {CustomName:"head_mole",Invisible:1,ArmorItems:[{},{},{},{id:skull,Count:1b,Damage:3s,tag:{display:{Name:"Beaver"},SkullOwner:{Id:"b2ec560d-b1a8-452c-b9db-03e1bcad9aeb",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMWM1ZTZjNWI5ZGY5ZTI3ZWU1NjdiNjU1ZDBlZThhNWFjOGUxMWUxZjQ1YWJjY2U0NjI2NWNjMjFhNzk5YWMifX19"}]}}}}],NoGravity:1,Marker:1}

scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Color Splash!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.generic.splash master @a ~ ~ ~ 10000 1
execute @s[score_random_min=1] ~ ~ ~ execute @a[c=2] ~ ~ ~ summon area_effect_cloud ~ ~ ~ {Tags:["splash"]}
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 15 replace stained_hardened_clay
scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 14 replace stained_hardened_clay
scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 5 replace stained_hardened_clay
scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 4 replace stained_hardened_clay
scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 3 replace stained_hardened_clay
scoreboard players test result! random 10 14
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @e[type=area_effect_cloud,tag=splash]
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,tag=splash] ~ ~ ~ fill ~3 ~3 ~3 ~-3 ~-3 ~-3 stained_hardened_clay 0 replace stained_hardened_clay

scoreboard players test result! random 15 16
execute @s[score_random_min=1] ~ ~ ~ advancement grant @a[m=3,tag=resurrected] only game:resurrected2
scoreboard players test result! random 15 16
execute @s[score_random_min=1] ~ ~ ~ scoreboard players tag @a[m=3] add resurrected
execute @s[score_random_min=1] ~ ~ ~ advancement grant @a[m=3] only game:resurrected1
scoreboard players test result! random 15 16
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Heroes never die!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.evocation_illager.prepare_wololo master @a ~ ~ ~ 10000 1.5
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=3] minecraft:levitation 3 10 true
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1002 997 0 20 false @a[m=3]
execute @s[score_random_min=1] ~ ~ ~ tp @a[m=3] ~ ~5 ~
execute @s[score_random_min=1] ~ ~ ~ gamemode 2 @a[m=3]

scoreboard players test result! random 17 19
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Zombie Rain!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.zombie.ambient master @a ~ ~ ~ 10000 0.7
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:zombie ~ ~15 ~ {Invulnerable:1,ArmorItems:[{},{},{},{id:diamond_helmet,Count:1b,tag:{ench:[{id:0,lvl:1}],Unbreakable:1}}],HandItems:[{id:stick,Count:1b,tag:{ench:[{id:19,lvl:4}]}}],Tags:["zombie"],Attributes:[{Name:"generic.movementSpeed",Base:0.4}]}

scoreboard players test result! random 20 26
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Swap!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.endermen.teleport master @a ~ ~ ~ 10000 1
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon area_effect_cloud ~ ~ ~ {NoGravity:1,CustomName:"swap"}
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ tp @s @r[type=area_effect_cloud,name=swap]
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ particle portal ~ ~ ~ 0.5 0.5 0.5 0.4 100 force @a

scoreboard players test result! random 27 29
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Woooosh!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.player.burp master @a ~ ~ ~ 10000 0.1
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:levitation 6 0 true

scoreboard players test result! random 31 33
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Acid Rain!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:weather.rain master @a ~ ~ ~ 100000 0.1
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:xp_bottle ~ ~30 ~
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:xp_bottle ~5 ~20 ~-3
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:xp_bottle ~-4 ~34 ~9

scoreboard players test result! random 34 38
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Heroes are real!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 10000 2
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:speed 15 3 true
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:jump_boost 15 3 true
execute @s[score_random_min=1] ~ ~ ~ effect @a[m=2] minecraft:glowing 15 3 true

scoreboard players test result! random 39 44
execute @s[score_random_min=1] ~ ~ ~ tellraw @a [{"text":"Event: ","color":"green"},{"text":"Boom!","color":"gray"}]
execute @s[score_random_min=1] ~ ~ ~ playsound minecraft:entity.creeper.primed master @a ~ ~ ~ 10000 0.6
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:creeper ~ ~30 ~ {Invulnerable:1,Tags:["explode"],Fuse:10000,Attributes:[{Name:"generic.movementSpeed",Base:0.4}]}
execute @s[score_random_min=1] ~ ~ ~ execute @a[m=2] ~ ~ ~ summon minecraft:creeper ~ ~30 ~ {Invulnerable:1,Tags:["explode"],Fuse:10000,Attributes:[{Name:"generic.movementSpeed",Base:0.4}]}