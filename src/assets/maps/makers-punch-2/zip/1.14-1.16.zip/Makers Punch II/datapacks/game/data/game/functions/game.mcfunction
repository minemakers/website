execute if score players var matches ..1 run function game:controller/stop

execute as @a[x=800,y=40,z=800,dx=2400,dy=25,dz=400,gamemode=adventure] run function game:misc/eliminate
execute as @a[x=800,y=170,z=800,dx=2400,dy=100,dz=200,gamemode=adventure] at @s if block ~ ~-0.1 ~ barrier run function game:misc/eliminate


execute as @a[gamemode=adventure] store success score @s var run clear @s #game:tools{tool:true} 0
replaceitem entity @a[gamemode=adventure,scores={var=0}] hotbar.0 minecraft:stick{Enchantments:[{id:"minecraft:knockback",lvl:10},{id:"minecraft:sharpness",lvl:10}],display:{Name:"{\"text\":\"Stick\",\"color\":\"yellow\",\"italic\":\"false\"}"},Unbreakable:1,HideFlags:2047,tool:true}
replaceitem entity @a[scores={stick=1,var=0},gamemode=adventure] hotbar.0 minecraft:bone{Enchantments:[{id:"minecraft:knockback",lvl:10},{id:"minecraft:sharpness",lvl:10}],display:{Name:"{\"text\":\"Bone\",\"color\":\"gray\",\"italic\":\"false\"}"},Unbreakable:1,HideFlags:2047,tool:true}
replaceitem entity @a[scores={stick=2,var=0},gamemode=adventure] hotbar.0 minecraft:blaze_rod{Enchantments:[{id:"minecraft:knockback",lvl:10},{id:"minecraft:sharpness",lvl:10}],display:{Name:"{\"text\":\"Blaze Rod\",\"color\":\"red\",\"italic\":\"false\"}"},Unbreakable:1,HideFlags:2047,tool:true}
scoreboard players reset @a var

execute as @a[gamemode=adventure] store success score @s var run clear @s minecraft:bow{tool:true} 0
replaceitem entity @a[gamemode=adventure,scores={var=0}] hotbar.1 bow{Enchantments:[{id:"minecraft:punch",lvl:4},{id:"minecraft:infinity",lvl:1}],Unbreakable:1,HideFlags:1023,display:{Name:"{\"text\":\"Bow\",\"color\":\"green\",\"italic\":\"false\"}"},tool:true}
scoreboard players reset @a var

execute if score bunny var matches 1 run effect give @a[gamemode=adventure] minecraft:speed 1000000 2 true
execute if score bunny var matches 1 run effect give @a[gamemode=adventure] minecraft:jump_boost 1000000 4 true

effect give @a[gamemode=adventure,scores={sneak=1..}] glowing 1 0 true
scoreboard players reset @a[scores={sneak=1..}] sneak


execute if score bonus var matches -1 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"\",\"color\":\"gold\",\"italic\":false},{\"text\":\"B\",\"color\":\"yellow\"},{\"text\":\"onus\"}]",CustomNameVisible:1}
execute if score bonus var matches -3 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"B\",\"color\":\"gold\",\"italic\":false},{\"text\":\"o\",\"color\":\"yellow\"},{\"text\":\"nus\"}]",CustomNameVisible:1}
execute if score bonus var matches -5 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"Bo\",\"color\":\"gold\",\"italic\":false},{\"text\":\"n\",\"color\":\"yellow\"},{\"text\":\"us\"}]",CustomNameVisible:1}
execute if score bonus var matches -7 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"Bon\",\"color\":\"gold\",\"italic\":false},{\"text\":\"u\",\"color\":\"yellow\"},{\"text\":\"s\"}]",CustomNameVisible:1}
execute if score bonus var matches -9 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"Bonu\",\"color\":\"gold\",\"italic\":false},{\"text\":\"s\",\"color\":\"yellow\"},{\"text\":\"\"}]",CustomNameVisible:1}
execute if score bonus var matches -11 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"Bon\",\"color\":\"gold\",\"italic\":false},{\"text\":\"us\",\"color\":\"yellow\"},{\"text\":\"\"}]",CustomNameVisible:1}
execute if score bonus var matches -13 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"Bo\",\"color\":\"gold\",\"italic\":false},{\"text\":\"nus\",\"color\":\"yellow\"},{\"text\":\"\"}]",CustomNameVisible:1}
execute if score bonus var matches -15 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"B\",\"color\":\"gold\",\"italic\":false},{\"text\":\"onus\",\"color\":\"yellow\"},{\"text\":\"\"}]",CustomNameVisible:1}
execute if score bonus var matches -17 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"\",\"color\":\"gold\",\"italic\":false},{\"text\":\"Bonu\",\"color\":\"yellow\"},{\"text\":\"s\"}]",CustomNameVisible:1}
execute if score bonus var matches -19 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"\",\"color\":\"gold\",\"italic\":false},{\"text\":\"Bon\",\"color\":\"yellow\"},{\"text\":\"us\"}]",CustomNameVisible:1}
execute if score bonus var matches -21 as @e[type=item,tag=bonus] run data merge entity @s {CustomName:"[{\"text\":\"\",\"color\":\"gold\",\"italic\":false},{\"text\":\"Bo\",\"color\":\"yellow\"},{\"text\":\"nus\"}]",CustomNameVisible:1}

scoreboard players remove bonus var 1
execute if score bonus var matches -24 run scoreboard players set bonus var -1

particle witch 1015 102.0 986 .2 0 .2 0 3 force
particle witch 1001 102.0 987 .2 0 .2 0 3 force
particle witch 985 102.0 990 .2 0 .2 0 3 force
particle witch 991 102.0 1001 .2 0 .2 0 3 force
particle witch 988 102.0 1016 .2 0 .2 0 3 force
particle witch 1012 119.0 1015 .2 0 .2 0 3 force
particle witch 3013 99.0 1012 .2 0 .2 0 3 force
particle witch 3013 96.0 1001 .2 0 .2 0 3 force
particle witch 3027 103.0 984 .2 0 .2 0 3 force
particle witch 3004 103.0 975 .2 0 .2 0 3 force
particle witch 2991 97.0 982 .2 0 .2 0 3 force
particle witch 2975 103.0 986 .2 0 .2 0 3 force
particle witch 2992 96.0 1015 .2 0 .2 0 3 force


execute at @e[type=snowball] positioned ~ ~30 ~ run kill @e[type=area_effect_cloud,tag=snowball,distance=..3,limit=1,sort=nearest]
execute at @e[type=area_effect_cloud,tag=snowball] positioned ~ ~-30 ~ run particle item_snowball ~ ~ ~ 1.5 1 1.5 0.05 200 force
execute at @e[type=area_effect_cloud,tag=snowball] positioned ~ ~-30 ~ run effect give @a[distance=..5,gamemode=adventure] minecraft:slowness 15 5 true
execute at @e[type=snowball] positioned ~ ~30 ~ run summon area_effect_cloud ~ ~ ~ {Tags:["snowball"],Duration:2}

execute as @a[scores={gravity=1..}] run function game:misc/gravity

execute as @a[nbt={Inventory:[{Slot:100b,id:"minecraft:golden_boots",Count:1b}]}] run function game:misc/rocket

execute as @a[nbt={Inventory:[{id:"minecraft:emerald"}]}] run function game:misc/life

execute as @a[scores={damage=0..},tag=smasher] at @s run function game:misc/smasher
tag @a[tag=smasher] remove smasher
tag @a[nbt={SelectedItem:{id:"minecraft:golden_axe"}}] add smasher
execute as @a[gamemode=adventure] at @s if block ~ ~ ~ #game:placable run tp @p ~ ~-0.2 ~

execute at @e[type=firework_rocket] run effect give @a[distance=..3,gamemode=adventure] levitation 1 30 true
execute at @e[type=firework_rocket] run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 2
execute at @e[type=firework_rocket] run particle explosion_emitter ~ ~ ~ 0.7 0.3 0.7 0.1 1 force
kill @e[type=firework_rocket] 

clear @a minecraft:glass_bottle
clear @a minecraft:elytra{Damage:431}

execute as @a[gamemode=adventure] at @s if block ~ ~-1.5 ~ minecraft:slime_block run scoreboard players add @s[tag=!flower] flower 1
tag @a[tag=flower] remove flower
execute as @a[gamemode=adventure] at @s if block ~ ~-1.5 ~ minecraft:slime_block run tag @s add flower
execute at @a[tag=flower] run playsound minecraft:block.slime.break master @a ~ ~ ~ 1 0.5
execute as @a[tag=flower] run effect give @s levitation 1 35 true 
advancement grant @a[scores={flower=25}] only game:flower

execute at @e[type=item,tag=bonus] run particle dust 255 255 255 1 ~ ~ ~ 0.1 0.1 0.1 1 1 force @a