effect give @a[gamemode=adventure] minecraft:levitation 15 2 true
playsound minecraft:entity.player.breath master @a ~ ~ ~ 10000 1
replaceitem entity @s[nbt={Inventory:[{Slot:-106b,id:"minecraft:carrot_on_a_stick"}]}] weapon.offhand air
replaceitem entity @s[nbt=!{Inventory:[{Slot:-106b,id:"minecraft:carrot_on_a_stick"}]}] weapon air
scoreboard players reset @s gravity