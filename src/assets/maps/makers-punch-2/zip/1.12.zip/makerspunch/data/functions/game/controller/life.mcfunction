stats entity @s set SuccessCount @s const
scoreboard players set @s const 0
scoreboard players test !life const 4 4
execute @s[score_const_min=1] ~ ~ ~ scoreboard players set !life const 0
scoreboard players test !life const 0 0
execute @s[score_const_min=1] ~ ~ ~ blockdata 6 151 6 {Text2:"{\"text\":\"1 life\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.note.xylophone master @s ~ ~ ~ 1 .8
scoreboard players test !life const 1 1
execute @s[score_const_min=1] ~ ~ ~ blockdata 6 151 6 {Text2:"{\"text\":\"3 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.note.xylophone master @s ~ ~ ~ 1 .85
scoreboard players test !life const 2 2
execute @s[score_const_min=1] ~ ~ ~ blockdata 6 151 6 {Text2:"{\"text\":\"5 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.note.xylophone master @s ~ ~ ~ 1 .9
scoreboard players test !life const 3 3
execute @s[score_const_min=1] ~ ~ ~ blockdata 6 151 6 {Text2:"{\"text\":\"9 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.note.xylophone master @s ~ ~ ~ 1 .95

stats entity @s clear SuccessCount
scoreboard players reset @s const