execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countDown const 1 6
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:misc/countdown
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !gameStatus const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !item const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players remove !countItem const 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players test !countItem const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !countItem const 6
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ execute @a[c=1] ~ ~ ~ function game:misc/item

xp -100L @a
clear @a arrow
replaceitem entity @a[m=2] slot.inventory.0 minecraft:arrow
entitydata @e[type=Arrow] {life:1198}
effect @a minecraft:saturation 100000 100 true