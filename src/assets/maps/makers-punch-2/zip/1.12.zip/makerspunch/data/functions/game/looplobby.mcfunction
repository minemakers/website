
scoreboard players set @a[x=-50,y=100,z=-50,r=25,tag=!admin] connection 1
execute @a[score_connection_min=0] ~ ~ ~ function game:players/connection

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !countSecond const -1 -1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set !countSecond const -21
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ function game:loopsecond
scoreboard players add !countSecond const 1

kill @e[type=item,tag=!invulnerable]
replaceitem entity @a[x=0,y=100,z=0,r=100,m=2] slot.weapon minecraft:air

#cosmetics
scoreboard players tag @a[tag=invisible] remove invisible
scoreboard players tag @a[tag=hat] remove hat
scoreboard players tag @a add invisible {ActiveEffects:[{Id:14b}]}
scoreboard players tag @a add hat {Inventory:[{Slot:103b}]}
execute @a[tag=invisible] ~ ~ ~ replaceitem entity @s[tag=hat] slot.armor.head air
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=1,score_cosHat_min=1] chain_command_block
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=1,score_cosHat_min=1] slot.armor.head chain_command_block 1 0 {display:{Name:"§bChain Command Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=2,score_cosHat_min=2] observer
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=2,score_cosHat_min=2] slot.armor.head observer 1 0 {display:{Name:"§dObserver Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=3,score_cosHat_min=3] tnt
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=3,score_cosHat_min=3] slot.armor.head tnt 1 0 {display:{Name:"§cExplosive Hat"}}
execute @a[tag=!invisible] ~ ~ ~ clear @s[tag=!hat,score_cosHat=4,score_cosHat_min=4] sign
execute @a[tag=!invisible] ~ ~ ~ replaceitem entity @s[tag=!hat,score_cosHat=4,score_cosHat_min=4] slot.armor.head sign 1 0 {display:{Name:"§eBert's Sign"}}

execute @e[score_cosParticle_min=1,score_cosParticle=1,tag=!invisible] ~ ~.2 ~ particle explode ~ ~ ~ 0.2 0.3 0.2 0.01 1 force @a
execute @e[score_cosParticle_min=2,score_cosParticle=2,tag=!invisible] ~ ~ ~ particle snowballpoof ~ ~0.7 ~ 0.3 0.3 0.3 0.001 2 force @a
execute @e[score_cosParticle_min=3,score_cosParticle=3,tag=!invisible] ~ ~ ~ particle mobSpell ~ ~0.2 ~ 0.3 0.3 0.3 1 1 force @a
execute @e[score_cosParticle_min=4,score_cosParticle=4,tag=!invisible] ~ ~1 ~ particle totem ~ ~ ~ 0.2 0.2 0.2 0.1 1

advancement grant @a[score_useBow=200,score_useBow_min=200] only game:arrow
advancement grant @a[score_jump=500,score_jump_min=500] only game:jump

particle blockcrack 9 152 5 0.2 0.2 0.2 0.1 3 force @a 166
effect @a minecraft:resistance 1000000 255 true