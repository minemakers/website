stats entity @s set SuccessCount @s const
scoreboard players set @s const 0

scoreboard players remove @s currentLife 1
effect @s clear
effect @s jump_boost 1 255 true
execute @s[score_currentLife_min=1] ~ ~ ~ playsound minecraft:entity.zombie.death master @a ~ ~ ~ 100000 1

scoreboard players test !arena const 0 0
execute @s[score_const_min=1] ~ ~ ~ spreadplayers 1000 1000 0 50 false @s[score_currentLife_min=1]

scoreboard players test !arena const 1 1
execute @s[score_const_min=1] ~ ~ ~ spreadplayers 2000 1000 0 50 false @s[score_currentLife_min=1]

scoreboard players test !arena const 2 2
execute @s[score_const_min=1] ~ ~ ~ spreadplayers 3000 1000 0 50 false @s[score_currentLife_min=1]

gamemode 3 @s[score_currentLife=0]
execute @s[score_currentLife=0] ~ ~ ~ tellraw @a {"text":"Sorry ","color":"red","extra":[{"selector":"@p","color":"yellow"},{"text":", you are eliminated!","color":"red"}]}
execute @s[score_currentLife=0] ~ ~ ~ playsound minecraft:entity.wither.death master @a ~ ~ ~ 100000 1

scoreboard players set @s[score_currentLife=0] connection 0

scoreboard players reset @s[score_currentLife=0] currentLife

stats entity @s clear SuccessCount
scoreboard players reset @s const