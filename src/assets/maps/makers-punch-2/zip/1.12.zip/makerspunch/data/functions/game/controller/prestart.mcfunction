scoreboard players set !gameStatus const 1
scoreboard players set !countDown const 6
effect @a minecraft:resistance 1000000 255 true
effect @a minecraft:invisibility 1000000 0 true
effect @a minecraft:instant_health 1 100 true
effect @a minecraft:weakness 1000000 100 true
title @a times 0 50 10
scoreboard players tag @a[tag=resurrected] remove resurrected


execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ spreadplayers 1000 1000 0 50 false @a[m=2]

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ spreadplayers 2000 1000 0 50 false @a[m=2]

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ spreadplayers 3000 1000 0 50 false @a[m=2]

tp @a[m=2] ~ 136 ~
effect @a levitation 1000000 255 true

kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=skeleton]

tellraw @a [{"text":"Rules: ","color":"gold"},{"text":"You have to punch your enemies out of the arena with either your stick or your bow.","color":"gray"}]