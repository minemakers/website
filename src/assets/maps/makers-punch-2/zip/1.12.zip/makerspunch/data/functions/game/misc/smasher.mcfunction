execute @s ~ ~ ~ scoreboard players tag @a[rm=0,c=1] add damage {HurtTime:9s}
execute @a[tag=damage] ~ ~ ~ playsound minecraft:entity.generic.big_fall master @a ~ ~ ~ 1 0.1
tp @a[tag=damage] ~ ~-3.3 ~
scoreboard players tag @a[tag=damage] remove damage
advancement grant @s only game:hammer
scoreboard players reset @s breakAxe