title @s[score_connection_min=1] title [{"text":"Welcome to","color":"green"}]
title @s[score_connection_min=1] subtitle [{"text":"Makers Punch","color":"gold"}]
playsound minecraft:entity.player.levelup master @s[score_connection_min=1] ~ ~ ~ 10000
gamemode 3 @s[score_connection_min=1]
stats entity @s set SuccessCount @s connection
spawnpoint @s 5 151 12
effect @s clear
clear @s
scoreboard players tag @s[tag=resurrected] remove resurrected
scoreboard teams join player @s
scoreboard players test !gameStatus const 0 0
tp @s[score_connection_min=1] 5 151 12 -180 0
gamemode 2 @s[score_connection_min=1]

scoreboard players test !gameStatus const 1 2
execute @s[score_connection_min=1] ~ ~ ~ scoreboard players test !arena const 0 0
tp @s[score_connection_min=1] 1000 123 1033 -180 30

scoreboard players test !gameStatus const 1 2
execute @s[score_connection_min=1] ~ ~ ~ scoreboard players test !arena const 1 1
tp @s[score_connection_min=1] 2000 123 1033 -180 30

scoreboard players test !gameStatus const 1 2
execute @s[score_connection_min=1] ~ ~ ~ scoreboard players test !arena const 2 2
tp @s[score_connection_min=1] 3000 123 1041 -180 30


stats entity @s clear SuccessCount
scoreboard players reset @s connection
scoreboard players reset @s currentLife