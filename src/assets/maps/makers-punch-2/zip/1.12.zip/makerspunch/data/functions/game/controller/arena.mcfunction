stats entity @s set SuccessCount @s const
scoreboard players set @s const 0
scoreboard players test !arena const 3 3
execute @s[score_const_min=1] ~ ~ ~ scoreboard players set !arena const 0
scoreboard players test !arena const 0 0
execute @s[score_const_min=1] ~ ~ ~ blockdata 4 151 6 {Text2:"{\"text\":\"Classic\",\"color\":\"dark_green\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=arena] {Item:{id:"minecraft:grass"}}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.grass.place master @s ~ ~ ~ 10 1.5

scoreboard players test !arena const 1 1
execute @s[score_const_min=1] ~ ~ ~ blockdata 4 151 6 {Text2:"{\"text\":\"Nether\",\"color\":\"dark_red\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=arena] {Item:{id:"minecraft:netherrack"}}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 10 2

scoreboard players test !arena const 2 2
execute @s[score_const_min=1] ~ ~ ~ blockdata 4 151 6 {Text2:"{\"text\":\"Ice\",\"color\":\"dark_aqua\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=arena] {Item:{id:"minecraft:ice"}}
execute @s[score_const_min=1] ~ ~ ~ playsound minecraft:block.glass.break master @s ~ ~ ~ 10 1

stats entity @s clear SuccessCount
scoreboard players reset @s const