stats entity @s set SuccessCount @s const
scoreboard players set @s const 0
scoreboard players test !item const 2 2
execute @s[score_const_min=1] ~ ~ ~ scoreboard players set !item const 0
scoreboard players test !item const 0 0
execute @s[score_const_min=1] ~ ~ ~ blockdata 3 151 6 {Text2:"{\"text\":\"Disabled\",\"color\":\"dark_red\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=itemController] {Item:{id:"minecraft:barrier"}}
scoreboard players test !item const 1 1
execute @s[score_const_min=1] ~ ~ ~ blockdata 3 151 6 {Text2:"{\"text\":\"Enabled\",\"color\":\"dark_green\",\"bold\":\"true\"}"}
execute @s[score_const_min=1] ~ ~ ~ entitydata @e[type=item,tag=itemController] {Item:{id:"minecraft:golden_axe"}}
playsound minecraft:block.stone_button.click_on master @s ~ ~ ~ 1 1.5
stats entity @s clear SuccessCount
scoreboard players reset @s const