function game:looplobby

#	stop game
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ testfor @a[m=2]
execute @e[type=area_effect_cloud,name=success,score_const=1] ~ ~ ~ function game:controller/stop

#	elimination
execute @a[x=800,y=40,z=800,dx=2400,dy=25,dz=400,m=2] ~ ~ ~ function game:players/eliminate
execute @a[x=800,y=170,z=800,dx=2400,dy=100,dz=200,m=2] ~ ~ ~ detect ~ ~-0.1 ~ barrier 0 function game:players/eliminate

#	Items Effects/CustomName
scoreboard players add @e[type=area_effect_cloud,name=item] const 1
scoreboard players set @e[type=area_effect_cloud,name=item,score_const_min=-77] const -99
execute @e[type=area_effect_cloud,name=item,score_const_min=-99,score_const=-99] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eB§6onus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-97,score_const=-97] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6B§eo§6nus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-95,score_const=-95] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bo§en§6us",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-93,score_const=-93] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bon§eu§6s",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-91,score_const=-91] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bonu§es",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-89,score_const=-89] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bon§eus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-87,score_const=-87] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6Bo§enus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-85,score_const=-85] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§6B§eonus",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-83,score_const=-83] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBonu§6s",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-81,score_const=-81] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBon§6us",CustomNameVisible:1}
execute @e[type=area_effect_cloud,name=item,score_const_min=-79,score_const=-79] ~ ~ ~ entitydata @e[type=item,tag=bonus] {CustomName:"§eBo§6nus",CustomNameVisible:1}
execute @e[type=Item,tag=!invulnerable] ~ ~ ~ particle reddust ~ ~ ~ 0.1 0.1 0.1 1 1 force @a

execute @e[type=Snowball] ~ ~30 ~ kill @e[type=armor_stand,name=snow,r=3,c=1]
execute @e[name=snow,type=armor_stand] ~ ~-30 ~ particle snowshovel ~ ~ ~ 1.5 1 1.5 0.05 200 force
execute @e[name=snow,type=armor_stand] ~ ~-30 ~ effect @a[r=5] minecraft:slowness 15 5 true
kill @e[type=armor_stand,name=snow]
execute @e[type=Snowball] ~ ~30 ~ summon armor_stand ~ ~ ~ {CustomName:"snow",Invisible:1,Marker:1,NoGravity:1,Small:1}

scoreboard players tag @a add life {Inventory:[{id:"minecraft:emerald"}]}
execute @a[tag=life] ~ ~ ~ function game:misc/life

execute @a[score_rightClick_min=1] ~ ~ ~ function game:misc/gravity

execute @a[score_breakAxe_min=1] ~ ~ ~ function game:misc/smasher
execute @a[m=2] ~ ~ ~ detect ~ ~ ~ minecraft:stained_hardened_clay -1 tp @p ~ ~-0.2 ~
execute @a[m=2] ~ ~ ~ detect ~ ~ ~ minecraft:ice -1 tp @p ~ ~-0.2 ~
execute @a[m=2] ~ ~ ~ detect ~ ~ ~ minecraft:packed_ice -1 tp @p ~ ~-0.2 ~
execute @a[m=2] ~ ~ ~ detect ~ ~ ~ minecraft:concrete -1 tp @p ~ ~-0.2 ~
execute @a[m=2] ~ ~ ~ detect ~ ~ ~ minecraft:snow -1 tp @p ~ ~-0.2 ~

scoreboard players tag @a add bootsRocket {Inventory:[{Slot:100b,id:"minecraft:golden_boots",Count:1b,Damage:0s}]}
execute @a[tag=bootsRocket] ~ ~ ~ function game:misc/rocket

execute @e[type=fireworks_rocket] ~ ~ ~ effect @a[r=3] levitation 1 30 true
execute @e[type=fireworks_rocket] ~ ~ ~ playsound minecraft:entity.generic.explode master @a ~ ~ ~ 1 2
execute @e[type=fireworks_rocket] ~ ~ ~ particle explode ~ ~ ~ 0.7 0.3 0.7 0.1 100 force
kill @e[type=fireworks_rocket] 

clear @a minecraft:glass_bottle
clear @a minecraft:elytra 431

particle witchMagic 1015 102.0 986 .2 0 .2 0 3 force
particle witchMagic 1001 102.0 987 .2 0 .2 0 3 force
particle witchMagic 985 102.0 990 .2 0 .2 0 3 force
particle witchMagic 991 102.0 1001 .2 0 .2 0 3 force
particle witchMagic 988 102.0 1016 .2 0 .2 0 3 force
particle witchMagic 1012 119.0 1015 .2 0 .2 0 3 force
particle witchMagic 3013 99.0 1012 .2 0 .2 0 3 force
particle witchMagic 3013 96.0 1001 .2 0 .2 0 3 force
particle witchMagic 3027 103.0 984 .2 0 .2 0 3 force
particle witchMagic 3004 103.0 975 .2 0 .2 0 3 force
particle witchMagic 2991 97.0 982 .2 0 .2 0 3 force
particle witchMagic 2975 103.0 986 .2 0 .2 0 3 force
particle witchMagic 2992 96.0 1015 .2 0 .2 0 3 force

execute @a[m=2] ~ ~ ~ detect ~ ~-1.5 ~ minecraft:slime 0 scoreboard players add @s[tag=!flower] useFlower 1
advancement grant @a[score_useFlower=25,score_useFlower_min=25] only game:flower
scoreboard players tag @a[tag=flower] remove flower
execute @a[m=2] ~ ~ ~ detect ~ ~-1.5 ~ minecraft:slime 0 scoreboard players tag @s add flower
execute @a[tag=flower] ~ ~ ~ playsound minecraft:block.slime.break master @a ~ ~ ~ 1 0.5
effect @a[tag=flower] levitation 1 35 true 



effect @a[score_sneak_min=1,m=2] glowing 1 0 true
scoreboard players reset @a[score_sneak_min=1] sneak

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !bunny const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ effect @a[m=2] minecraft:speed 1000000 2 true
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ effect @a[m=2] minecraft:jump_boost 1000000 5 true

#REGIVE IF DROP
scoreboard players tag @a[m=2] add giveStick
scoreboard players tag @a[m=2] remove giveStick {Inventory:[{tag:{stick:true}}]}
clear @a[tag=giveStick] stick 0 64 {stick:true}
clear @a[tag=giveStick] bone 0 64 {stick:true}
clear @a[tag=giveStick] blaze_rod 0 64 {stick:true}
replaceitem entity @a[m=2,score_cosStick_min=1,score_cosStick=1,tag=giveStick] slot.hotbar.0 bone 1 0 {ench:[{id:19,lvl:9},{id:16,lvl:10}],Unbreakable:1,HideFlags:1023,display:{Name:"§fBone"},stick:true}
replaceitem entity @a[m=2,score_cosStick_min=2,score_cosStick=2,tag=giveStick] slot.hotbar.0 blaze_rod 1 0 {ench:[{id:19,lvl:9},{id:16,lvl:10}],Unbreakable:1,HideFlags:1023,display:{Name:"§cBlaze Rod"},stick:true}
scoreboard players tag @a[m=2] remove giveStick {Inventory:[{tag:{stick:true}}]}
replaceitem entity @a[m=2,tag=giveStick] slot.hotbar.0 stick 1 0 {ench:[{id:19,lvl:10},{id:16,lvl:10}],Unbreakable:1,HideFlags:1023,display:{Name:"§eStick"},stick:true}

scoreboard players tag @a[m=2] add giveBow
scoreboard players tag @a[m=2] remove giveBow {Inventory:[{tag:{bow:true}}]}
clear @a[tag=giveBow] bow 0 64 {bow:true}
replaceitem entity @a[m=2,tag=giveBow] slot.hotbar.1 bow 1 0 {ench:[{id:49,lvl:4},{id:51,lvl:1}],Unbreakable:1,HideFlags:1023,display:{Name:"§aBow"},bow:true}
