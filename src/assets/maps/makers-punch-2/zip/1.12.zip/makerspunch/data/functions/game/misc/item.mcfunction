stats entity @s set SuccessCount @s random
scoreboard players set @s random 0

scoreboard players operation seed! random *= a! random
scoreboard players operation seed! random += c! random
scoreboard players test seed! random -2147483648 -1
execute @s[score_random_min=1] ~ ~ ~ scoreboard players operation seed! random *= inv! random
scoreboard players operation result! random = seed! random
scoreboard players operation result! random /= b! random
scoreboard players operation result! random %= m! random

summon area_effect_cloud ~ ~ ~ {CustomName:"summonItem"}
scoreboard players set @s random 0

scoreboard players test !arena const 0 0
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 1000 1000 0 50 false @e[type=area_effect_cloud,name=summonItem]

scoreboard players test !arena const 1 1
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 2000 1000 0 50 false @e[type=area_effect_cloud,name=summonItem]

scoreboard players test !arena const 2 2
execute @s[score_random_min=1] ~ ~ ~ spreadplayers 3000 1000 0 50 false @e[type=area_effect_cloud,name=summonItem]

scoreboard players test result! random 0 2
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:potion",Count:1b,Damage:0s,tag:{display:{Name:"§7Potion of Invisibility"},CustomPotionEffects:[{Id:14,Amplifier:0,Duration:500,ShowParticles:false}],Potion:"minecraft:water",HideFlags:1023}}}
scoreboard players test result! random 3 11
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:golden_boots",Count:1b,Damage:0s,tag:{ench:[{id:0,lvl:1}],AttributeModifiers:[{AttributeName:"generic.armor",Name:"generic.armor",Amount:0,Operation:0,UUIDMost:76307,UUIDLeast:109672}],HideFlags:1023,display:{Name:"§eRocket"}}}}
scoreboard players test result! random 12 24
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:ender_pearl",Count:1b,Damage:0s,tag:{display:{Name:"§2Ender Pearl"}}}}
scoreboard players test result! random 25 31
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:carrot_on_a_stick",Count:1b,Damage:0s,tag:{display:{Name:"§9Gravity Canceller"}}}}
scoreboard players test result! random 32 41
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:snowball",Count:1b,Damage:0s,tag:{display:{Name:"§bFrozen Ball"}}}}
scoreboard players test result! random 42 48
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:splash_potion",Count:1b,Damage:0s,tag:{display:{Name:"§5Potion of Nausea"},CustomPotionEffects:[{Id:9,Amplifier:0,Duration:500,ShowParticles:false}],Potion:"minecraft:strong_leaping",HideFlags:1023}}}
scoreboard players test result! random 49 58
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:splash_potion",Count:1b,Damage:0s,tag:{display:{Name:"§9Potion of Blindness"},CustomPotionEffects:[{Id:15,Amplifier:0,Duration:300,ShowParticles:false}],Potion:"minecraft:water",HideFlags:1023}}}
scoreboard players test result! random 59 72
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:diamond_sword",Count:1b,Damage:1561s,tag:{display:{Name:"§9Super Sword"},HideFlags:1023,ench:[{id:19,lvl:255},{id:16,lvl:10}]}}}
scoreboard players test result! random 73 86
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:elytra",Count:1b,Damage:420s,tag:{HideFlags:1023,display:{Name:"§9Elytra"}}}}
scoreboard players test result! random 87 93
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:spawn_egg",Count:1b,Damage:0s,tag:{EntityTag:{id:"minecraft:skeleton",HandItems:[{id:"minecraft:bow",Count:1b,tag:{ench:[{id:49,lvl:6}]}}],ArmorItems:[{},{},{},{id:"minecraft:obsidian",Count:1b}],Attributes:[{Name:generic.movementSpeed,Base:0.7}],ActiveEffects:[{Id:20,Amplifier:1,Duration:100000,ShowParticles:false}],SkeletonType:0b},CanPlaceOn:["minecraft:snow","minecraft:stained_hardened_clay","minecraft:packed_ice","minecraft:ice","minecraft:concrete"],display:{Name:"§fSkeleton Egg"},HideFlags:1023}}}
scoreboard players test result! random 94 97
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:spawn_egg",Count:1b,Damage:0s,tag:{EntityTag:{id:"minecraft:zombie",HandItems:[{id:"minecraft:stick",Count:1b,tag:{ench:[{id:19,lvl:6}]}}],ArmorItems:[{},{},{},{id:"minecraft:obsidian",Count:1b}],Attributes:[{Name:generic.movementSpeed,Base:0.7}],ActiveEffects:[{Id:20,Amplifier:1,Duration:100000,ShowParticles:false}],ZombieType:0b},CanPlaceOn:["minecraft:snow","minecraft:stained_hardened_clay","minecraft:packed_ice","minecraft:ice","minecraft:concrete"],display:{Name:"§2Zombie Egg"},HideFlags:1023}}}
scoreboard players test result! random 98 100
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:golden_axe",Count:1b,Damage:32s,tag:{ench:[{id:16,lvl:10}],HideFlags:1023,display:{Name:"§6Mjilnor"}}}}
scoreboard players test result! random 101 108
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:fireworks",Count:1b,Damage:0s,tag:{CanPlaceOn:["minecraft:snow","minecraft:stained_hardened_clay","minecraft:packed_ice","minecraft:ice","minecraft:concrete"],HideFlags:1023,display:{Name:"§bFireworks"}}}}
scoreboard players test result! random 109 111
execute @s[score_random_min=1] ~ ~ ~ execute @e[type=area_effect_cloud,name=summonItem] ~ ~ ~ summon item ~ ~ ~ {Tags:["bonus","invulnerable"],NoGravity:1,Item:{id:"minecraft:emerald",Count:1b,Damage:0s}}
kill @e[type=area_effect_cloud,name=summonItem]

stats entity @s clear SuccessCount
scoreboard players reset @s random