gamerule gameLoopFunction game:loopgame
title @a subtitle [{"text":"The Game has just started! ","color":"yellow"}]
title @a times 0 50 10
scoreboard players set !gameStatus const 2
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 10000 
effect @a clear
clear @a
effect @a minecraft:weakness 1000000 100 true
effect @a minecraft:resistance 1000000 255 true
effect @a minecraft:jump_boost 2 255 true
scoreboard teams option player friendlyfire true

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !life const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set @a[m=2] currentLife 1

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !life const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set @a[m=2] currentLife 3

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !life const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set @a[m=2] currentLife 5

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !life const 3 3
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players set @a[m=2] currentLife 9
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ advancement grant @a[m=2] only game:lives

execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 0 0
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena1
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 1 1
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena2
execute @e[type=area_effect_cloud,name=success] ~ ~ ~ scoreboard players test !arena const 2 2
execute @e[type=area_effect_cloud,name=success,score_const_min=1] ~ ~ ~ scoreboard players tag @a[m=2] add arena3

execute @a[tag=arena1] ~ ~ ~ execute @s[tag=arena2] ~ ~ ~ advancement grant @s[tag=arena3] only game:arena


advancement grant @a[m=2] only game:root
