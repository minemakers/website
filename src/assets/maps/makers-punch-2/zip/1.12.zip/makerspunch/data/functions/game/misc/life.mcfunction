tellraw @s {"text":"You found a new life!","color":"green"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 100000 1
scoreboard players add @s currentLife 1
clear @s emerald 0 1
advancement grant @s[score_currentLife_min=10] only game:luck
scoreboard players tag @s remove life