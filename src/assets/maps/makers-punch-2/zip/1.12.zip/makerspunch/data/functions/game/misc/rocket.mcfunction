playsound minecraft:entity.generic.explode master @a ~ ~ ~
particle explode ~ ~-0.2 ~ 0.3 0.10 0.3 0.1 100 force
effect @s minecraft:levitation 1 50 true
replaceitem entity @s slot.armor.feet minecraft:air
scoreboard players tag @s remove bootsRocket