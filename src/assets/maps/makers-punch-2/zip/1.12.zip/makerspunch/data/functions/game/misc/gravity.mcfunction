effect @a[m=2] minecraft:levitation 15 2 true
playsound minecraft:entity.player.breath master @a ~ ~ ~ 10000 1
scoreboard players tag @s add mainHand
scoreboard players tag @s remove mainHand {Inventory:[{Slot:-106b,id:"minecraft:carrot_on_a_stick"}]}
replaceitem entity @s[tag=!mainHand] slot.weapon.offhand air
replaceitem entity @s[tag=mainHand] slot.weapon air
scoreboard players tag @s remove mainHand

scoreboard players reset @s rightClick