gamerule gameLoopFunction game:looplobby
scoreboard players set !gameStatus const 0
playsound minecraft:entity.enderdragon.ambient master @a ~ ~ ~ 10000 1.5
title @a times 0 100 10
title @a subtitle [{"text":""}]
title @a title [{"text":"Draw","color":"red"}]

scoreboard players set !timer const 0

scoreboard teams option player color gold
execute @a[m=2,c=1] ~ ~ ~ title @a title [{"text":"The Winner is","color":"red"}]
execute @a[m=2,c=1] ~ ~ ~ title @a subtitle [{"selector":"@a[m=2]"}]
execute @a[m=2,c=1] ~ ~ ~ tellraw @a [{"selector":"@a[m=2]"},{"text":" won the game!","color":"yellow"}]
advancement grant @a[m=2,c=1] only game:win1
scoreboard players add @a[m=2,c=1] winGame 1
advancement grant @a[m=2,c=1,score_winGame_min=5] only game:win2
advancement grant @a[m=2,c=1,score_winGame_min=15] only game:win3
advancement grant @a[m=2,c=1,tag=invisible] only game:invisible
scoreboard teams option player friendlyfire false
scoreboard teams option player color gray

kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=skeleton]




execute @a ~ ~ ~ stats entity @s set SuccessCount @s const
scoreboard players set @a const 0

execute @a ~ ~ ~ advancement test @s game:root
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win1
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:arena
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:sniper
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win2
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:stick1
execute @a[score_const_min=1] ~ ~ ~ scoreboard players set @s cosStick 1

execute @a ~ ~ ~ advancement test @s game:stick1
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:hammer
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:invisible
execute @a[score_const_min=1] ~ ~ ~ advancement test @s game:win3
execute @a[score_const_min=1] ~ ~ ~ advancement grant @s only game:stick2
execute @a[score_const_min=1] ~ ~ ~ scoreboard players set @s cosStick 2

scoreboard players reset * currentLife

stats entity @a clear SuccessCount
scoreboard players reset @a const

scoreboard players set @a connection 0