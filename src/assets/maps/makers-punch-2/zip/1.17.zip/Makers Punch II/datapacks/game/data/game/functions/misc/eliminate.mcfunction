scoreboard players remove @s lives 1
effect clear @s
effect give @s jump_boost 1 255 true
effect give @s minecraft:weakness 1000000 100 true
effect give @s minecraft:resistance 1000000 255 true

execute as @s[scores={lives=1..}] at @s run playsound minecraft:entity.zombie.death master @a ~ ~ ~ 100000 1

execute if score arena var matches 1 run spreadplayers 1000 1000 0 50 false @s[scores={lives=1..}]
execute if score arena var matches 2 run spreadplayers 2000 1000 0 50 false @s[scores={lives=1..}]
execute if score arena var matches 3 run spreadplayers 3000 1000 0 50 false @s[scores={lives=1..}]

gamemode spectator @s[scores={lives=..0}]

execute as @s[scores={lives=..0}] run tellraw @a {"text":"Sorry ","color":"red","extra":[{"selector":"@s","color":"yellow"},{"text":", you are eliminated!","color":"red"}]}
execute as @s[scores={lives=..0}] run playsound minecraft:entity.wither.death master @a ~ ~ ~ 100000 1

scoreboard players set @s[scores={lives=..0}] connection 0
scoreboard players reset @s[scores={lives=..0}] lives