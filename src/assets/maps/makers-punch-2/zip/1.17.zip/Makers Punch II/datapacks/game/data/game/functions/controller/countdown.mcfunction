scoreboard players set status var 1
scoreboard players set countdown var 6
effect give @a minecraft:resistance 1000000 255 true
effect give @a minecraft:invisibility 1000000 0 true
effect give @a minecraft:instant_health 1 100 true
effect give @a minecraft:weakness 1000000 100 true
title @a times 0 50 10
tag @a[tag=resurrected] remove resurrected

execute if score arena var matches 1 run spreadplayers 1000 1000 0 50 false @a
execute if score arena var matches 2 run spreadplayers 2000 1000 0 50 false @a
execute if score arena var matches 3 run spreadplayers 3000 1000 0 50 false @a
execute as @a at @s run tp @s ~ 136 ~
effect give @a levitation 1000000 255 true

kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=skeleton]

tellraw @a [{"text":"Rules: ","color":"gold"},{"text":"You have to punch your enemies out of the arena with either your stick or your bow.","color":"gray"}]