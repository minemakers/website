execute if score players var matches ..1 run tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"}]
execute if score players var matches ..1 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute if score players var matches 2.. run function game:controller/countdown