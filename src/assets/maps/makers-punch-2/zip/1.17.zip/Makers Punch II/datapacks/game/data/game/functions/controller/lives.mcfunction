data merge block 6 151 6 {Text1:"",Text2:"",Text3:"",Text4:""}
data merge block 6 151 6 {Text1:"{\"text\":\"Life count\",\"color\":\"dark_gray\",\"bold\":true}",Text2:"",Text3:"{\"text\":\"\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"scoreboard players add lives var 1\"}}",Text4:"{\"text\":\"click to change\",\"italic\":true,\"clickEvent\":{\"action\":\"run_command\",\"value\":\"function game:controller/lives\"}}"}

execute if score lives var matches 5.. run scoreboard players set lives var 1

execute if score lives var matches 1 run data merge block 6 151 6 {Text2:"{\"text\":\"1 life\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute if score lives var matches 1 run playsound minecraft:block.note_block.xylophone master @s ~ ~ ~ 1 .8

execute if score lives var matches 2 run data merge block 6 151 6 {Text2:"{\"text\":\"3 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute if score lives var matches 2 run playsound minecraft:block.note_block.xylophone master @s ~ ~ ~ 1 .85

execute if score lives var matches 3 run data merge block 6 151 6 {Text2:"{\"text\":\"5 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute if score lives var matches 3 run playsound minecraft:block.note_block.xylophone master @s ~ ~ ~ 1 .9

execute if score lives var matches 4 run data merge block 6 151 6 {Text2:"{\"text\":\"9 lives\",\"color\":\"dark_purple\",\"bold\":\"true\"}"}
execute if score lives var matches 4 run playsound minecraft:block.note_block.xylophone master @s ~ ~ ~ 1 .95