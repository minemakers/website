playsound minecraft:entity.generic.explode master @a ~ ~ ~
particle explosion_emitter ~ ~-0.2 ~ 0.3 0.10 0.3 0.1 1 force
effect give @s minecraft:levitation 1 50 true
item replace entity @s armor.feet with air