data merge block 7 151 6 {Text1:"",Text2:"",Text3:"",Text4:""}
data merge block 7 151 6 {Text1:"{\"text\":\"Bunny\",\"color\":\"dark_gray\",\"bold\":true}",Text2:"",Text3:"{\"text\":\"\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"scoreboard players add bunny var 1\"}}",Text4:"{\"text\":\"click to change\",\"italic\":true,\"clickEvent\":{\"action\":\"run_command\",\"value\":\"function game:controller/bunny\"}}"}

execute if score bunny var matches 2.. run scoreboard players set bunny var 0

execute if score bunny var matches 0 run data merge block 7 151 6 {Text2:"{\"text\":\"Disabled\",\"color\":\"dark_red\",\"bold\":\"true\"}"}
execute if score bunny var matches 0 run data merge entity @e[type=item,tag=bunnyController,limit=1] {Item:{id:"minecraft:barrier"}}

execute if score bunny var matches 1 run data merge block 7 151 6 {Text2:"{\"text\":\"Enabled\",\"color\":\"dark_green\",\"bold\":\"true\"}"}
execute if score bunny var matches 1 run data merge entity @e[type=item,tag=bunnyController,limit=1] {Item:{id:"minecraft:feather"}}

playsound minecraft:block.stone_button.click_on master @s ~ ~ ~ 1 1.5
