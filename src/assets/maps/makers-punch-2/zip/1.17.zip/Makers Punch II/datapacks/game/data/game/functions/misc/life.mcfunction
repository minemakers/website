tellraw @s {"text":"You found a new life!","color":"green"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 100000 1
scoreboard players add @s lives 1
clear @s emerald 1
advancement grant @s[scores={lives=10..}] only game:luck