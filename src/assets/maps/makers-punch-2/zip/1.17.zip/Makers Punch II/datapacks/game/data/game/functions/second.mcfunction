scoreboard players set second var 20

execute if score countdown var matches 1..6 run function game:misc/countdown

xp set @a 0 levels
clear @a arrow
item replace entity @a[gamemode=adventure] inventory.0 with minecraft:arrow
execute as @e[type=arrow] run data merge entity @s {life:1198}
effect give @a minecraft:saturation 100000 100 true

execute if score status var matches 2 if score bonuses var matches 1 run scoreboard players remove timer_bonus var 1
execute if score status var matches 2 if score bonuses var matches 1 if score timer_bonus var matches 0 run function game:misc/item