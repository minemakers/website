data merge block 4 151 6 {Text1:"",Text2:"",Text3:"",Text4:""}
data merge block 4 151 6 {Text1:"{\"text\":\"Arena\",\"color\":\"dark_gray\",\"bold\":true}",Text2:"",Text3:"{\"text\":\"\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"scoreboard players add arena var 1\"}}",Text4:"{\"text\":\"click to change\",\"italic\":true,\"clickEvent\":{\"action\":\"run_command\",\"value\":\"function game:controller/arena\"}}"}

execute if score arena var matches 4.. run scoreboard players set arena var 1

execute if score arena var matches 1 run data merge block 4 151 6 {Text2:"{\"text\":\"Classic\",\"color\":\"dark_green\",\"bold\":\"true\"}"}
execute if score arena var matches 1 run data merge entity @e[type=item,tag=arena,limit=1] {Item:{id:"minecraft:grass"}}
execute if score arena var matches 1 run playsound minecraft:block.grass.place master @s ~ ~ ~ 10 1.5

execute if score arena var matches 2 run data merge block 4 151 6 {Text2:"{\"text\":\"Nether\",\"color\":\"dark_red\",\"bold\":\"true\"}"}
execute if score arena var matches 2 run data merge entity @e[type=item,tag=arena,limit=1] {Item:{id:"minecraft:netherrack"}}
execute if score arena var matches 2 run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 10 2

execute if score arena var matches 3 run data merge block 4 151 6 {Text2:"{\"text\":\"Ice\",\"color\":\"dark_aqua\",\"bold\":\"true\"}"}
execute if score arena var matches 3 run data merge entity @e[type=item,tag=arena,limit=1] {Item:{id:"minecraft:ice"}}
execute if score arena var matches 3 run playsound minecraft:block.glass.break master @s ~ ~ ~ 10 1