effect give @a[gamemode=adventure] minecraft:levitation 15 2 true
playsound minecraft:entity.player.breath master @a ~ ~ ~ 10000 1
item replace entity @s[nbt={Inventory:[{Slot:-106b,id:"minecraft:carrot_on_a_stick"}]}] weapon.offhand with air
item replace entity @s[nbt=!{Inventory:[{Slot:-106b,id:"minecraft:carrot_on_a_stick"}]}] weapon with air
scoreboard players reset @s gravity