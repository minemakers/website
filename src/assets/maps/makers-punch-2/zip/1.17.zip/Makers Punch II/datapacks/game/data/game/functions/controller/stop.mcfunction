scoreboard players set status var 0
playsound minecraft:entity.ender_dragon.ambient master @a ~ ~ ~ 10000 1.5
title @a times 0 100 10
title @a subtitle [{"text":""}]
title @a title [{"text":"Draw","color":"red"}]

team modify player color gold
execute as @a[gamemode=adventure,limit=1] run title @a title [{"text":"The Winner is","color":"red"}]
execute as @a[gamemode=adventure,limit=1] run title @a subtitle [{"selector":"@s"}]
execute as @a[gamemode=adventure,limit=1] run tellraw @a [{"selector":"@s"},{"text":" won the game!","color":"yellow"}]

scoreboard players add @a[gamemode=adventure,limit=1] win 1
advancement grant @a[gamemode=adventure,limit=1,scores={win=1}] only game:win1
advancement grant @a[gamemode=adventure,limit=1,scores={win=5}] only game:win2
advancement grant @a[gamemode=adventure,limit=1,scores={win=15}] only game:win3

advancement grant @a[gamemode=adventure,limit=1,nbt={ActiveEffects:[{Id:14b}]}] only game:invisible

team modify player friendlyFire false
team modify player color gray

kill @e[type=ender_pearl]
kill @e[type=snowball]
kill @e[type=item,tag=bonus]
kill @e[type=zombie]
kill @e[type=skeleton]

advancement grant @a[advancements={game:root=true,game:win1=true,game:arena=true,game:sniper=true,game:win2=true}] only game:stick1
scoreboard players set @a[advancements={game:root=true,game:win1=true,game:arena=true,game:sniper=true,game:win2=true}] stick 1
advancement grant @a[advancements={game:stick1=true,game:hammer=true,game:invisible=true,game:win3=true}] only game:stick2
scoreboard players set @a[advancements={game:stick1=true,game:hammer=true,game:invisible=true,game:win3=true}] stick 2

scoreboard players reset * lives
scoreboard players set @a connection 0
