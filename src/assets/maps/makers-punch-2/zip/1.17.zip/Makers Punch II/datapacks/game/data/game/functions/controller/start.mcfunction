title @a subtitle [{"text":"The Game has just started! ","color":"yellow"}]
title @a times 0 50 10
scoreboard players set status var 2
scoreboard players set timer_bonus var 6
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 10000
effect clear @a
clear @a
effect give @a minecraft:weakness 1000000 100 true
effect give @a minecraft:resistance 1000000 255 true
effect give @a minecraft:jump_boost 2 255 true
team modify player friendlyFire true

execute if score lives var matches 1 run scoreboard players set @a[gamemode=adventure] lives 1
execute if score lives var matches 2 run scoreboard players set @a[gamemode=adventure] lives 3
execute if score lives var matches 3 run scoreboard players set @a[gamemode=adventure] lives 5
execute if score lives var matches 4 run scoreboard players set @a[gamemode=adventure] lives 9
execute if score lives var matches 4 run advancement grant @a[gamemode=adventure] only game:lives

execute if score arena var matches 1 run tag @a[gamemode=adventure] add arena1
execute if score arena var matches 2 run tag @a[gamemode=adventure] add arena2
execute if score arena var matches 3 run tag @a[gamemode=adventure] add arena3

execute as @a[tag=arena1,tag=arena2,tag=arena3] run advancement grant @s only game:arena
advancement grant @a[gamemode=adventure] only game:root

scoreboard players reset @a sneak
