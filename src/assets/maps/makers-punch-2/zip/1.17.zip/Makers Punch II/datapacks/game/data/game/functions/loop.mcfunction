

scoreboard players set @a[tag=!initialized] connection 1
execute as @a[scores={connection=0..}] run function game:misc/connection

scoreboard players set players var 0
execute as @a[gamemode=adventure] run scoreboard players add players var 1

scoreboard players remove second var 1
execute if score second var matches ..0 run function game:second

execute if score status var matches 2 run function game:game

kill @e[type=item,tag=!invulnerable]
item replace entity @a[x=0,y=100,z=0,distance=..100,gamemode=adventure] weapon with minecraft:air

advancement grant @a[scores={arrow=200}] only game:arrow
advancement grant @a[scores={jump=500}] only game:jump


item replace entity @a[nbt={ActiveEffects:[{Id:14b}],Inventory:[{Slot:103b}]}] armor.head with air

clear @a[nbt=!{ActiveEffects:[{Id:14b}]},nbt=!{Inventory:[{Slot:103b}]},scores={hat=1}] chain_command_block
clear @a[nbt=!{ActiveEffects:[{Id:14b}]},nbt=!{Inventory:[{Slot:103b}]},scores={hat=2}] observer
clear @a[nbt=!{ActiveEffects:[{Id:14b}]},nbt=!{Inventory:[{Slot:103b}]},scores={hat=3}] tnt
clear @a[nbt=!{ActiveEffects:[{Id:14b}]},nbt=!{Inventory:[{Slot:103b}]},scores={hat=4}] oak_sign
item replace entity @a[nbt=!{ActiveEffects:[{Id:14b}]},scores={hat=1}] armor.head with chain_command_block{display:{Name:'{"text":"Chain Command Hat","color":"aqua","italic":false}'}}
item replace entity @a[nbt=!{ActiveEffects:[{Id:14b}]},scores={hat=2}] armor.head with observer{display:{Name:'{"text":"Observer Hat","color":"light_purple","italic":false}'}}
item replace entity @a[nbt=!{ActiveEffects:[{Id:14b}]},scores={hat=3}] armor.head with tnt{display:{Name:'{"text":"Explosive Hat","color":"red","italic":false}'}}
item replace entity @a[nbt=!{ActiveEffects:[{Id:14b}]},scores={hat=4}] armor.head with oak_sign{display:{Name:'{"text":"Bert\'s Sign","color":"yellow","italic":false}'}}

execute at @a[scores={particle=1},nbt=!{ActiveEffects:[{Id:14b}]}] run particle spit ~ ~.2 ~ 0.2 0.3 0.2 0.01 1 force @a
execute at @a[scores={particle=2},nbt=!{ActiveEffects:[{Id:14b}]}] run particle item_snowball ~ ~.7 ~ 0.3 0.3 0.3 0.001 2 force @a
execute at @a[scores={particle=3},nbt=!{ActiveEffects:[{Id:14b}]}] run particle entity_effect ~ ~.2 ~ 0.3 0.3 0.3 1 1 force @a
execute at @a[scores={particle=4},nbt=!{ActiveEffects:[{Id:14b}]}] run particle totem_of_undying ~ ~1 ~ 0.2 0.2 0.2 0.1 1


effect give @a minecraft:resistance 1000000 255 true
particle minecraft:block minecraft:barrier 9 152 5 0.2 0.2 0.2 0.1 3 force @a

particle spit 11 152 7 0.2 0.3 0.2 0.01 1 force @a
particle item_snowball 11 152.4 13 0.3 0.3 0.3 0.001 1 force @a
particle entity_effect 11 152 10 0.3 0.3 0.3 1 1 force @a
particle totem_of_undying 11 152.5 16 0.2 0.2 0.2 0.1 1