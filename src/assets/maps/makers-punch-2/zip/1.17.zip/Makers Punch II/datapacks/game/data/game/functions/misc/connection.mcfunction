title @s[scores={connection=1..}] title [{"text":"Welcome to","color":"green"}]
title @s[scores={connection=1..}] subtitle [{"text":"Makers Punch","color":"gold"}]
playsound minecraft:entity.player.levelup master @s[scores={connection=1..}] ~ ~ ~ 10000

spawnpoint @s 5 151 12
effect clear @s 
clear @s
effect give @s minecraft:instant_health 1 10 true
team join player @s

execute if score status var matches 0 run tp @s[scores={connection=0..}] 5 151 12 -180 0
execute if score status var matches 0 run gamemode adventure @s[scores={connection=0..}]
execute if score status var matches 1.. if score arena var matches 1 run tp @s[scores={connection=0..}] 1000 123 1033 -180 30
execute if score status var matches 1.. if score arena var matches 2 run tp @s[scores={connection=0..}] 2000 123 1033 -180 30
execute if score status var matches 1.. if score arena var matches 3 run tp @s[scores={connection=0..}] 3000 123 1041 -180 30
execute if score status var matches 1.. run gamemode spectator @s[scores={connection=0..}]

scoreboard players reset @s connection
tag @s add initialized
tag @s remove resurrected

scoreboard players reset @s lives