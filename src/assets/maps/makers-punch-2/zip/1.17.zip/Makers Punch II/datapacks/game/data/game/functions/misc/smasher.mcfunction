tag @a[nbt={HurtTime:10s},sort=nearest,limit=1,distance=0.0001..] add damage
execute as @a[tag=damage] at @s run playsound minecraft:entity.generic.big_fall master @a ~ ~ ~ 1 0.1
execute as @a[tag=damage] at @s run tp @s ~ ~-3.3 ~
tag @a[tag=damage] remove damage
advancement grant @s only game:hammer
scoreboard players reset @s damage