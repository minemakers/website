execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool run scoreboard players add yellow_point var 1
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool run effect give @s instant_health 1 10 true
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool run effect give @s strength 5 1
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool run playsound minecraft:entity.player.levelup master @a[team=yellow] ~ ~ ~ 1000 1.7
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool run playsound minecraft:entity.zombie_villager.cure master @a[team=blue] ~ ~ ~ 1000 2



execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool run scoreboard players add blue_point var 1
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool run effect give @s instant_health 1 10 true
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool run effect give @s strength 5 1
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool run playsound minecraft:entity.player.levelup master @a[team=blue] ~ ~ ~ 100000 1.7
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool run playsound minecraft:entity.zombie_villager.cure master @a[team=yellow] ~ ~ ~ 1000 2


scoreboard players operation total_point var = yellow_point var
scoreboard players operation total_point var += blue_point var
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:cyan_wool if score total_point var > #5 var run scoreboard players remove blue_point var 1
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:yellow_wool if score total_point var > #5 var run scoreboard players remove yellow_point var 1


execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:light_gray_wool run scoreboard players add yellow_point var 1
execute at @s[team=yellow] if block ~ ~-1 ~ minecraft:light_gray_wool run playsound minecraft:entity.player.levelup master @a[team=yellow] ~ ~ ~ 100000 1.7
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:light_gray_wool run scoreboard players add blue_point var 1
execute at @s[team=blue] if block ~ ~-1 ~ minecraft:light_gray_wool run playsound minecraft:entity.player.levelup master @a[team=blue] ~ ~ ~ 100000 1.7


execute if score yellow_point var >= #1 var run summon minecraft:area_effect_cloud -29 38 -100 {Tags:["yellow_point"]}
execute if score yellow_point var > #1 var run tag @e[type=area_effect_cloud,tag=yellow_point] add locked_point
execute if score yellow_point var >= #2 var run summon minecraft:area_effect_cloud -29 38 -50 {Tags:["yellow_point"]}
execute if score yellow_point var > #2 var run tag @e[type=area_effect_cloud,tag=yellow_point] add locked_point
execute if score yellow_point var >= #3 var run summon minecraft:area_effect_cloud -29 38 0 {Tags:["yellow_point"]}
execute if score yellow_point var > #3 var run tag @e[type=area_effect_cloud,tag=yellow_point] add locked_point
execute if score yellow_point var >= #4 var run summon minecraft:area_effect_cloud -29 38 50 {Tags:["yellow_point"]}
execute if score yellow_point var > #4 var run tag @e[type=area_effect_cloud,tag=yellow_point] add locked_point
execute if score yellow_point var >= #5 var run summon minecraft:area_effect_cloud -29 38 100 {Tags:["yellow_point"]}

execute if score blue_point var >= #1 var run summon minecraft:area_effect_cloud -29 38 100 {Tags:["blue_point"]}
execute if score blue_point var > #1 var run tag @e[type=area_effect_cloud,tag=blue_point] add locked_point
execute if score blue_point var >= #2 var run summon minecraft:area_effect_cloud -29 38 50 {Tags:["blue_point"]}
execute if score blue_point var > #2 var run tag @e[type=area_effect_cloud,tag=blue_point] add locked_point
execute if score blue_point var >= #3 var run summon minecraft:area_effect_cloud -29 38 0 {Tags:["blue_point"]}
execute if score blue_point var > #3 var run tag @e[type=area_effect_cloud,tag=blue_point] add locked_point
execute if score blue_point var >= #4 var run summon minecraft:area_effect_cloud -29 38 -50 {Tags:["blue_point"]}
execute if score blue_point var > #4 var run tag @e[type=area_effect_cloud,tag=blue_point] add locked_point
execute if score blue_point var >= #5 var run summon minecraft:area_effect_cloud -29 38 -100 {Tags:["blue_point"]}


execute at @e[type=area_effect_cloud,tag=locked_point] run setblock ~ ~ ~ bedrock

execute at @e[type=area_effect_cloud,tag=yellow_point,tag=!locked_point] run setblock ~ ~ ~ minecraft:yellow_wool
execute at @e[type=area_effect_cloud,tag=yellow_point,tag=!locked_point] run fill ~1 ~5 ~1 ~-1 ~5 ~-1 minecraft:yellow_stained_glass

execute at @e[type=area_effect_cloud,tag=blue_point,tag=!locked_point] run setblock ~ ~ ~ minecraft:cyan_wool
execute at @e[type=area_effect_cloud,tag=blue_point,tag=!locked_point] run fill ~1 ~5 ~1 ~-1 ~5 ~-1 minecraft:cyan_stained_glass




execute if block -29 38 -100 minecraft:cyan_wool run function game:misc/win_blue
execute if block -29 38 100 minecraft:yellow_wool run function game:misc/win_yellow

function game:misc/actionbar
