team join blue @s[x=-6.5,y=51,z=5.5,distance=..5]
tellraw @s[x=-6.5,y=51,z=5.5,distance=..5] {"text":"You have just joined the Blue Team!","color":"dark_aqua","bold":"true"}

team join yellow @a[x=-6.5,y=51,z=-5.5,distance=..5]
tellraw @a[x=-6,y=51,z=-5.5,distance=..5] {"text":"You have just joined the Yellow Team!","color":"yellow","bold":"true"}

playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 100000 1
scoreboard players reset @s villager