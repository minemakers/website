scoreboard players remove second var 1
execute if score second var <= #0 var run function game:second

execute as @a[gamemode=!spectator] at @s if block ~ ~-1 ~ #minecraft:wool run function game:misc/capture

execute if score game_status var = #2 var as @a[gamemode=adventure,nbt=!{Inventory:[{Slot:-106b},{Slot:0b},{Slot:1b},{Slot:2b}]}] run function game:misc/hotbar
execute if score game_status var = #2 var as @a[gamemode=adventure,team=blue,nbt={Inventory:[{id:"minecraft:glass_bottle"}]}] run replaceitem entity @s hotbar.2 minecraft:potion{CustomPotionEffects:[{Id:22b,Amplifier:1,Duration:600},{Id:10b,Amplifier:0,Duration:300}],CustomPotionColor:1923762,display:{Name:"{\"text\":\"Potion of Absorption\",\"color\":\"dark_aqua\",\"underlined\":\"false\",\"italic\":\"false\"}"}} 1
execute if score game_status var = #2 var as @a[gamemode=adventure,team=yellow,nbt={Inventory:[{id:"minecraft:glass_bottle"}]}] run replaceitem entity @s hotbar.2 minecraft:potion{CustomPotionEffects:[{Id:22b,Amplifier:1,Duration:600},{Id:10b,Amplifier:0,Duration:300}],CustomPotionColor:16774944,display:{Name:"{\"text\":\"Potion of Absorption\",\"color\":\"yellow\",\"underlined\":\"false\",\"italic\":\"false\"}"}} 1

fill -28 46 101 -30 39 99 air replace #game:stained_terracotta
fill -28 46 51 -30 39 49 air replace #game:stained_terracotta
fill -28 46 1 -30 39 -1 air replace #game:stained_terracotta
fill -28 46 -49 -30 39 -51 air replace #game:stained_terracotta
fill -28 46 -99 -30 39 -101 air replace #game:stained_terracotta

execute as @a[gamemode=adventure] at @s if entity @s[y=27,dy=-10] run kill @s
execute as @a[scores={kill=1..}] at @s run tellraw @a [{"selector":"@a[scores={death=1..},sort=nearest,limit=1]"},{"text":" was killed by ","color":"gold"},{"selector":"@s"}]
execute as @a[x=-29,y=68,z=0,distance=..1,gamemode=adventure] run function game:misc/death

scoreboard players reset @a[nbt={OnGround:1b}] nofall
scoreboard players add @a[nbt={OnGround:0b}] nofall 1
scoreboard players remove @a[scores={jump=1..}] nofall 7
scoreboard players reset @a jump
effect give @a[scores={nofall=9..},nbt={OnGround:0b}] minecraft:slow_falling 1 0 true
effect give @a[scores={nofall=17..},nbt={OnGround:0b}] minecraft:slow_falling 2 0 true
execute as @a[nbt={OnGround:0b}] at @s if block ~.3 ~-1 ~.3 air if block ~-.3 ~-1 ~-.3 air if block ~-.3 ~-1 ~.3 air if block ~.3 ~-1 ~-.3 air run effect clear @s slow_falling
execute as @a[nbt={OnGround:1b}] run effect clear @s slow_falling

execute if score game_status var = #2 var as @a[gamemode=adventure] at @s unless blocks ~3 44 ~3 ~-3 44 ~-3 0 5 0 all run fill ~-3 44 ~-3 ~3 46 ~3 air replace #game:stained_terracotta
