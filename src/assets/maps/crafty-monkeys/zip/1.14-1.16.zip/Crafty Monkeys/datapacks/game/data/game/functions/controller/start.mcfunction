fill -32 43 22 -26 49 28 air replace barrier
fill -26 49 -22 -32 43 -28 air replace barrier

tp @a[team=yellow,gamemode=adventure] -29 45 -100 0 10
tp @a[team=blue,gamemode=adventure] -29 45 100 180 10

spawnpoint @a[gamemode=adventure] -29 68 0

scoreboard players set game_status var 2

title @a title [{"text":"Crafty Monkeys","color":"green"}]
title @a subtitle [{"text":"The game has just started!","color":"yellow"}]
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 100000

scoreboard players reset @a death
scoreboard players reset @a kill

effect clear @a
clear @a
