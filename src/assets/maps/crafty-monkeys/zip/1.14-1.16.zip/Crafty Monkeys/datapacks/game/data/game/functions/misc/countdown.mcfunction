title @a title [{"text":"Crafty Monkeys","color":"green"}]
title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"countdown","objective":"var"}},{"text":" seconds"}]
execute if score game_timer var = #1 var run title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"game_timer","objective":"var"}},{"text":" second"}]
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000
title @a times 0 55 10