setblock -29 38 -100 minecraft:cyan_wool
fill -30 43 -101 -28 43 -99 minecraft:cyan_stained_glass

title @a times 2 80 25
title @a title [{"text":"The Blue Team","color":"dark_aqua"}]
title @a subtitle [{"text":"won the game!","color":"dark_aqua"}]

title @a[gamemode=adventure] actionbar [{"text":"█•█•█•█•█","color":"dark_aqua","bold":"true"}]

function game:controller/stop
