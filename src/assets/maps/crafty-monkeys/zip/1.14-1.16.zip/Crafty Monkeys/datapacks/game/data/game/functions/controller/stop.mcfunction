playsound minecraft:entity.wither.death master @a 0 50 0 10000 2
scoreboard players set @a connection 0
scoreboard players set game_status var 0
scoreboard players set countdown var -1
scoreboard players set second var 0

title @a actionbar [{"text":""}]
