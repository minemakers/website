function game:misc/hotbar

execute if score blue_point var = #1 var run teleport @s[team=blue,gamemode=adventure] -29 44 100 180 0
execute if score blue_point var = #2 var run teleport @s[team=blue,gamemode=adventure] -29 44 50 180 0
execute if score blue_point var = #3 var run teleport @s[team=blue,gamemode=adventure] -29 44 0 180 0
execute if score blue_point var = #4 var run teleport @s[team=blue,gamemode=adventure] -29 44 -50 180 0

execute if score yellow_point var = #1 var run teleport @s[team=yellow,gamemode=adventure] -29 44 -100 0 0
execute if score yellow_point var = #2 var run teleport @s[team=yellow,gamemode=adventure] -29 44 -50 0 0
execute if score yellow_point var = #3 var run teleport @s[team=yellow,gamemode=adventure] -29 44 0 0 0
execute if score yellow_point var = #4 var run teleport @s[team=yellow,gamemode=adventure] -29 44 50 0 0
