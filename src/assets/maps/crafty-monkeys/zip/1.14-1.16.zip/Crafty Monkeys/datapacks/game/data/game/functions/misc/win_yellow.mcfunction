setblock -29 38 100 minecraft:yellow_wool
fill -28 43 99 -30 43 101 minecraft:yellow_stained_glass

title @a times 2 80 25
title @a title [{"text":"The Yellow Team","color":"gold"}]
title @a subtitle [{"text":"won the game!","color":"gold"}]

title @a[gamemode=adventure] actionbar [{"text":"█•█•█•█•█","color":"gold","bold":"true"}]

function game:controller/stop
