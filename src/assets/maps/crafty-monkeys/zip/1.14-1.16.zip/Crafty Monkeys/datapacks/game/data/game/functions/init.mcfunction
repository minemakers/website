scoreboard objectives add kill playerKillCount
scoreboard objectives add death deathCount
scoreboard objectives add var dummy
scoreboard objectives add villager minecraft.custom:minecraft.talked_to_villager
scoreboard objectives add connection minecraft.custom:minecraft.leave_game
scoreboard objectives add trigger trigger

#function game:misc/reset
scoreboard players set #0 var 0
scoreboard players set #1 var 1
scoreboard players set #2 var 2
scoreboard players set #3 var 3
scoreboard players set #4 var 4
scoreboard players set #5 var 5
