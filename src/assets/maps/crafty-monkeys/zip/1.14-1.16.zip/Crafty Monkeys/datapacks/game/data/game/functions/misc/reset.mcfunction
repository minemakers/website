fill -23 30 0 -35 48 103 minecraft:air replace #game:stained_terracotta
fill -23 30 0 -35 48 -103 minecraft:air replace #game:stained_terracotta

summon minecraft:area_effect_cloud -29 29 -100 {Tags:["reset_point"]}
summon minecraft:area_effect_cloud -29 29 -50 {Tags:["reset_point"]}
summon minecraft:area_effect_cloud -29 29 0 {Tags:["reset_point"]}
summon minecraft:area_effect_cloud -29 29 50 {Tags:["reset_point"]}
summon minecraft:area_effect_cloud -29 29 100 {Tags:["reset_point"]}
execute at @e[type=area_effect_cloud,tag=reset_point] run fill ~1 ~ ~1 ~-1 ~7 ~-1 minecraft:brown_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run fill ~1 ~8 ~1 ~-1 ~9 ~-1 minecraft:lime_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run fill ~1 ~8 ~ ~-1 ~8 ~ minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run fill ~ ~8 ~1 ~ ~8 ~-1 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run setblock ~1 ~7 ~1 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run setblock ~-1 ~7 ~1 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run setblock ~1 ~7 ~-1 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run setblock ~-1 ~7 ~-1 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_point] run setblock ~ ~9 ~ minecraft:light_gray_wool
execute at @e[type=area_effect_cloud,tag=reset_point] run fill ~1 ~14 ~1 ~-1 ~14 ~-1 minecraft:light_gray_stained_glass

summon minecraft:area_effect_cloud -29 29 -75 {Tags:["reset_bridge"]}
summon minecraft:area_effect_cloud -29 29 -25 {Tags:["reset_bridge"]}
summon minecraft:area_effect_cloud -29 29 25 {Tags:["reset_bridge"]}
summon minecraft:area_effect_cloud -29 29 75 {Tags:["reset_bridge"]}
execute at @e[type=area_effect_cloud,tag=reset_bridge] run fill ~ ~1 ~-23 ~ ~7 ~23 minecraft:brown_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run fill ~ ~8 ~-23 ~ ~8 ~23 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run fill ~ ~9 ~-23 ~ ~9 ~23 minecraft:lime_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~9 ~ minecraft:glowstone
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~8 ~ minecraft:lime_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~7 ~ minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~8 ~23 minecraft:lime_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~7 ~23 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~8 ~-23 minecraft:lime_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~7 ~-23 minecraft:green_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~ ~23 minecraft:brown_terracotta
execute at @e[type=area_effect_cloud,tag=reset_bridge] run setblock ~ ~ ~-23 minecraft:brown_terracotta

setblock -29 38 100 minecraft:cyan_wool
fill -30 43 101 -28 43 99 minecraft:cyan_stained_glass

setblock -29 38 -100 minecraft:yellow_wool
fill -30 43 -101 -28 43 -99 minecraft:yellow_stained_glass

scoreboard players set yellow_point var 1
scoreboard players set blue_point var 1

scoreboard players set game_status var 0
scoreboard players set countdown var -1
scoreboard players set second var 0
