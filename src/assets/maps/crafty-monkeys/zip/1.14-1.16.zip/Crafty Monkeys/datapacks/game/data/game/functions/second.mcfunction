scoreboard players set second var 21

execute if score countdown var matches 1..5 run function game:misc/countdown
execute if score countdown var = #0 var run function game:controller/start
execute if score countdown var >= #0 var run scoreboard players remove countdown var 1

function game:misc/actionbar
