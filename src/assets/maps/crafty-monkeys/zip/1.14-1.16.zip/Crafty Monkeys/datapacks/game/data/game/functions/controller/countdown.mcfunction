function game:misc/reset


gamemode adventure @a[team=yellow]
gamemode adventure @a[team=blue]

tp @a[team=yellow,gamemode=adventure] -29 45 -25 0 10
tp @a[team=blue,gamemode=adventure] -29 45 25 180 10

fill -32 43 22 -26 48 28 barrier replace air
fill -27 44 23 -31 48 27 air replace barrier

fill -26 48 -22 -32 43 -28 barrier replace air
fill -31 44 -27 -27 48 -23 air replace barrier

scoreboard players set game_status var 1
scoreboard players set countdown var 6
