scoreboard players set @a[tag=!initialized] connection 1
execute as @a[scores={connection=0..}] run function game:misc/connection
execute as @a[scores={villager=1..}] run function game:misc/team

scoreboard players set players var 0
execute as @a[gamemode=adventure] run scoreboard players add players var 1

execute as @a[scores={trigger=4318}] run tellraw @s [{"text":"\nRules: ","color":"green"},{"text":"The objective is to capture the five points.\nStand on the wool to capture them! You respawn on your last captured point.","color":"gray"},{"text":"\n\nBe Crafty as a Monkey and find a way to pass through the enemies!\n","color":"dark_gray","italic":"true"}]
execute as @a[scores={trigger=4318}] run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 10000 1
scoreboard players reset @a[scores={trigger=0..}] trigger
scoreboard players enable @a trigger

effect give @a[nbt=!{foodLevel:20}] minecraft:saturation 1 0 true
effect give @a[x=0,y=50,z=0,distance=..15] minecraft:weakness 1000000 200 true

execute if score game_status var > #0 var run function game:game

kill @e[type=item]
scoreboard players reset @a death
scoreboard players reset @a kill
