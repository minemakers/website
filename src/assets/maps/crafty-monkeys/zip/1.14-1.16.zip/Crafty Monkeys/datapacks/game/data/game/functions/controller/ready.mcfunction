execute if score players var matches ..1 run tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"}]
execute if score players var matches ..1 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute if score players var matches 2.. unless entity @a[team=blue] run tellraw @a [{"text":"The blue team is empty! ","color":"red"}]
execute if score players var matches 2.. unless entity @a[team=blue] run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute if score players var matches 2.. unless entity @a[team=yellow] run tellraw @a [{"text":"The yellow team is empty! ","color":"red"}]
execute if score players var matches 2.. unless entity @a[team=yellow] run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000
execute if score players var matches 2.. if entity @a[team=blue] if entity @a[team=yellow] run function game:controller/countdown
