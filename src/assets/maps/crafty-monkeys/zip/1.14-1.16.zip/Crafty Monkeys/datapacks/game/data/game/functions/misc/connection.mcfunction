tellraw @s[scores={connection=1..}] [{"text":"\nWelcome to ","color":"gold"},{"text":"Crafty Monkeys!","color":"gold","bold":"true"},{"text":"\n\nClick ","color":"gray"},{"text":"[here]","color":"gray","italic":"true","hoverEvent":{"action":"show_text","value":"click"},"clickEvent":{"action":"run_command","value":"/trigger trigger set 4318"}},{"text":" to show the rules!\n","color":"gray"}]


title @s[scores={connection=1..}] title [{"text":"Welcome to","color":"red"}]
title @s[scores={connection=1..}] subtitle [{"text":"Crafty Monkeys","color":"gold","bold":"true"}]
playsound minecraft:entity.shulker.death master @s[scores={connection=1..}] ~ ~ ~ 10000 1.5
scoreboard players reset @s connection

execute if score game_status var = #0 var run tp @s -1 52 0 90 5
execute if score game_status var = #0 var run gamemode adventure @s

execute if score game_status var > #0 var run tp @s 10 66 0 90 15
execute if score game_status var > #0 var run gamemode spectator @s

spawnpoint @s -1 51 0
team join players @s[scores={connection=1..}]
effect clear @s
clear @s
effect give @s minecraft:instant_health 1 100 true

tag @s add initialized