give @s[scores={shop_id=1}] stone 6
give @s[scores={shop_id=2}] grass_block 6
give @s[scores={shop_id=3}] dirt 8
give @s[scores={shop_id=4}] gravel 24
give @s[scores={shop_id=5}] oak_wood 3
give @s[scores={shop_id=6},team=p1] light_gray_wool 6
give @s[scores={shop_id=6},team=p2] cyan_wool 6
give @s[scores={shop_id=6},team=p3] yellow_wool 6
give @s[scores={shop_id=6},team=p4] white_wool 6
give @s[scores={shop_id=6},team=p5] orange_wool 6
give @s[scores={shop_id=6},team=p6] black_wool 6
give @s[scores={shop_id=6},team=p7] lime_wool 6
give @s[scores={shop_id=6},team=p8] red_wool 6
give @s[scores={shop_id=7}] bricks 8
give @s[scores={shop_id=8},team=p1] light_gray_stained_glass 5
give @s[scores={shop_id=8},team=p2] cyan_stained_glass 5
give @s[scores={shop_id=8},team=p3] yellow_stained_glass 5
give @s[scores={shop_id=8},team=p4] white_stained_glass 5
give @s[scores={shop_id=8},team=p5] orange_stained_glass 5
give @s[scores={shop_id=8},team=p6] black_stained_glass 5
give @s[scores={shop_id=8},team=p7] lime_stained_glass 5
give @s[scores={shop_id=8},team=p8] red_stained_glass 5
give @s[scores={shop_id=9}] ice 4
give @s[scores={shop_id=10}] snow_block 4
give @s[scores={shop_id=11}] obsidian
give @s[scores={shop_id=12}] carved_pumpkin 2
give @s[scores={shop_id=13}] end_stone 6
give @s[scores={shop_id=14}] soul_sand 4
give @s[scores={shop_id=15}] light_gray_terracotta 18
give @s[scores={shop_id=16}] coal_ore 16
give @s[scores={shop_id=17}] iron_ore 5
give @s[scores={shop_id=18}] redstone_ore 12
give @s[scores={shop_id=19}] lapis_ore 6
give @s[scores={shop_id=20}] diamond_ore 5
give @s[scores={shop_id=21}] redstone_block
give @s[scores={shop_id=22}] tnt 2
give @s[scores={shop_id=23}] slime_block
give @s[scores={shop_id=24}] dispenser
give @s[scores={shop_id=25}] sticky_piston
give @s[scores={shop_id=26}] bookshelf 2
give @s[scores={shop_id=27}] enchanting_table
give @s[scores={shop_id=28}] anvil
give @s[scores={shop_id=29}] trapped_chest
give @s[scores={shop_id=30}] cobweb 3
give @s[scores={shop_id=31}] tripwire_hook 2
give @s[scores={shop_id=32}] redstone_torch 10
give @s[scores={shop_id=33}] repeater 5
give @s[scores={shop_id=34}] firework_rocket
give @s[scores={shop_id=35}] oak_sign 2
give @s[scores={shop_id=36}] fire_charge 8
give @s[scores={shop_id=37}] experience_bottle 6
give @s[scores={shop_id=38}] bread 3
give @s[scores={shop_id=39}] chicken_spawn_egg 2
give @s[scores={shop_id=40}] witch_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=41}] rabbit_spawn_egg{EntityTag:{RabbitType:99,Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=42}] shulker_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=43}] blaze_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=44}] creeper_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=45}] spider_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=46}] skeleton_spawn_egg{EntityTag:{Tags:["new_spawned_mob"],CanPickUpLoot:1,ArmorItems:[{},{},{},{id:"minecraft:iron_helmet",Count:1b}]}}
give @s[scores={shop_id=47}] zombie_spawn_egg{EntityTag:{Tags:["new_spawned_mob"],CanPickUpLoot:1,ArmorItems:[{},{},{},{id:"minecraft:iron_helmet",Count:1b}]}}
give @s[scores={shop_id=48}] wolf_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s[scores={shop_id=49}] chest{display:{Name:'{"text":"Filled Chest","color":"dark_green","italic":false}'},BlockEntityTag:{LootTable:"game:classic_chest"}}
give @s[scores={shop_id=50}] bone
give @s[scores={shop_id=51}] oak_sapling
give @s[scores={shop_id=52}] iron_hoe
give @s[scores={shop_id=53}] iron_shovel
give @s[scores={shop_id=54}] iron_axe
give @s[scores={shop_id=55}] stone_pickaxe
give @s[scores={shop_id=56}] iron_pickaxe
give @s[scores={shop_id=57}] diamond_pickaxe
give @s[scores={shop_id=58}] water_bucket
give @s[scores={shop_id=59}] lava_bucket
give @s[scores={shop_id=60}] golden_apple
give @s[scores={shop_id=61}] ender_pearl
give @s[scores={shop_id=62}] elytra
give @s[scores={shop_id=63}] arrow 3
give @s[scores={shop_id=64}] bow
give @s[scores={shop_id=65}] flint_and_steel
give @s[scores={shop_id=66}] fishing_rod
give @s[scores={shop_id=67}] wooden_sword
give @s[scores={shop_id=68}] stone_sword
give @s[scores={shop_id=69}] iron_sword
give @s[scores={shop_id=70}] diamond_sword
give @s[scores={shop_id=71}] shield

scoreboard players operation @s shop_points -= @s shop_cost
