kill @e[type=marker,tag=arena_clone]
execute if score arena var matches 1 run summon marker -17 15 12 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 2 run summon marker -58 15 -29 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 3 run summon marker -58 15 12 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 4 run summon marker -58 15 53 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 5 run summon marker -17 15 53 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 6 run summon marker 24 15 -29 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 7 run summon marker -17 15 -29 {Tags:["arena_clone"],Duration:6}
execute if score arena var matches 8 run summon marker 24 15 53 {Tags:["arena_clone"],Duration:7}
execute if score arena var matches 9 run summon marker 24 15 12 {Tags:["arena_clone"],Duration:6}

kill @e[type=item,tag=!invulnerable]
