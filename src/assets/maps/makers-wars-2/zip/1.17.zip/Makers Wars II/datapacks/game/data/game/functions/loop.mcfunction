
# Makers Wars II - Copyright (c) MineMakers Team (by Aksiome)

scoreboard players set @a[tag=!initialized] connection 1
execute as @a[scores={connection=0..}] run scoreboard players set @s[scores={playing=1..}] connection -1
execute as @a[scores={connection=0..},nbt={DeathTime:0s}] run function game:misc/connection

scoreboard players set players var 0
execute as @a[gamemode=!spectator] run scoreboard players add players var 1

scoreboard players set teams var 0
execute if entity @a[team=p1,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p2,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p3,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p4,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p5,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p6,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p7,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p8,gamemode=!spectator] run scoreboard players add teams var 1

execute if score game_status var matches 0 run function game:lobby
execute if score game_status var matches 1 run function game:shop
execute if score game_status var matches 2 run function game:game

execute if entity @e[type=marker,tag=arena_clone] run function game:structure/clone_arena
execute if entity @e[type=marker,tag=arena_clear] run function game:structure/clear_arena

scoreboard players remove second var 1
execute if score second var matches ..0 run function game:second

execute as @a[scores={death=1..}] run scoreboard players set @s connection 0


execute as @a[gamemode=spectator] at @s if entity @s[y=0,dy=-50] run tp @s ~ 100 ~
scoreboard players reset @a[scores={click_villager=1..}] click_villager
scoreboard players reset @a[scores={death=1..}] death
