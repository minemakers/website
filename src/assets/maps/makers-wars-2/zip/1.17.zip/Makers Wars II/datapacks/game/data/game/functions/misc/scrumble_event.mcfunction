scoreboard players set #mod events 35

scoreboard players operation #seed events *= #a events
scoreboard players operation #seed events += #c events
execute if score #seed events matches ..-1 run scoreboard players operation #seed events *= #inv events
scoreboard players operation #result events = #seed events
scoreboard players operation #result events /= #b events
scoreboard players operation #result events %= #mod events

execute if score #result events matches 0 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.0 with minecraft:dead_bush
execute if score #result events matches 1 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.1 with minecraft:dead_bush
execute if score #result events matches 2 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.2 with minecraft:dead_bush
execute if score #result events matches 3 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.3 with minecraft:dead_bush
execute if score #result events matches 4 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.4 with minecraft:dead_bush
execute if score #result events matches 5 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.5 with minecraft:dead_bush
execute if score #result events matches 6 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.6 with minecraft:dead_bush
execute if score #result events matches 7 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.7 with minecraft:dead_bush
execute if score #result events matches 8 run item replace entity @r[gamemode=!spectator,limit=2] hotbar.8 with minecraft:dead_bush

execute if score #result events matches 9 run item replace entity @r[gamemode=!spectator,limit=2] inventory.0 with minecraft:dead_bush
execute if score #result events matches 10 run item replace entity @r[gamemode=!spectator,limit=2] inventory.1 with minecraft:dead_bush
execute if score #result events matches 11 run item replace entity @r[gamemode=!spectator,limit=2] inventory.2 with minecraft:dead_bush
execute if score #result events matches 12 run item replace entity @r[gamemode=!spectator,limit=2] inventory.3 with minecraft:dead_bush
execute if score #result events matches 13 run item replace entity @r[gamemode=!spectator,limit=2] inventory.4 with minecraft:dead_bush
execute if score #result events matches 14 run item replace entity @r[gamemode=!spectator,limit=2] inventory.5 with minecraft:dead_bush
execute if score #result events matches 15 run item replace entity @r[gamemode=!spectator,limit=2] inventory.6 with minecraft:dead_bush
execute if score #result events matches 16 run item replace entity @r[gamemode=!spectator,limit=2] inventory.7 with minecraft:dead_bush
execute if score #result events matches 17 run item replace entity @r[gamemode=!spectator,limit=2] inventory.8 with minecraft:dead_bush
execute if score #result events matches 18 run item replace entity @r[gamemode=!spectator,limit=2] inventory.9 with minecraft:dead_bush
execute if score #result events matches 19 run item replace entity @r[gamemode=!spectator,limit=2] inventory.10 with minecraft:dead_bush
execute if score #result events matches 20 run item replace entity @r[gamemode=!spectator,limit=2] inventory.11 with minecraft:dead_bush
execute if score #result events matches 21 run item replace entity @r[gamemode=!spectator,limit=2] inventory.12 with minecraft:dead_bush
execute if score #result events matches 22 run item replace entity @r[gamemode=!spectator,limit=2] inventory.13 with minecraft:dead_bush
execute if score #result events matches 23 run item replace entity @r[gamemode=!spectator,limit=2] inventory.14 with minecraft:dead_bush
execute if score #result events matches 24 run item replace entity @r[gamemode=!spectator,limit=2] inventory.15 with minecraft:dead_bush
execute if score #result events matches 25 run item replace entity @r[gamemode=!spectator,limit=2] inventory.16 with minecraft:dead_bush
execute if score #result events matches 26 run item replace entity @r[gamemode=!spectator,limit=2] inventory.17 with minecraft:dead_bush
execute if score #result events matches 27 run item replace entity @r[gamemode=!spectator,limit=2] inventory.18 with minecraft:dead_bush
execute if score #result events matches 28 run item replace entity @r[gamemode=!spectator,limit=2] inventory.19 with minecraft:dead_bush
execute if score #result events matches 29 run item replace entity @r[gamemode=!spectator,limit=2] inventory.20 with minecraft:dead_bush
execute if score #result events matches 30 run item replace entity @r[gamemode=!spectator,limit=2] inventory.21 with minecraft:dead_bush
execute if score #result events matches 31 run item replace entity @r[gamemode=!spectator,limit=2] inventory.22 with minecraft:dead_bush
execute if score #result events matches 32 run item replace entity @r[gamemode=!spectator,limit=2] inventory.23 with minecraft:dead_bush
execute if score #result events matches 33 run item replace entity @r[gamemode=!spectator,limit=2] inventory.24 with minecraft:dead_bush
execute if score #result events matches 34 run item replace entity @r[gamemode=!spectator,limit=2] inventory.25 with minecraft:dead_bush
execute if score #result events matches 35 run item replace entity @r[gamemode=!spectator,limit=2] inventory.26 with minecraft:dead_bush