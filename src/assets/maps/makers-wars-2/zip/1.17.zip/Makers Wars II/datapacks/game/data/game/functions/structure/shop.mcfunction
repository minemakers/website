function game:structure/destroy

#BARRIER BOX
fill 979 120 965 1013 120 985 barrier
fill 979 120 985 1013 127 985 barrier
fill 1013 127 985 1013 120 965 barrier
fill 979 120 965 979 127 985 barrier
fill 979 128 985 1013 128 965 minecraft:barrier

fill 1002 121 982 990 121 982 minecraft:quartz_slab[type=top]
fill 998 121 982 994 121 982 minecraft:quartz_pillar[axis=y]
fill 997 121 982 995 121 982 air
setblock 998 122 982 minecraft:quartz_slab
setblock 994 122 982 minecraft:quartz_slab
setblock 994 121 971 minecraft:quartz_slab[type=top]
setblock 998 121 971 minecraft:quartz_slab[type=top]
setblock 993 121 971 minecraft:quartz_pillar
setblock 992 121 972 minecraft:quartz_pillar
setblock 999 121 971 minecraft:quartz_pillar
setblock 1000 121 972 minecraft:quartz_pillar
fill 992 121 973 992 121 975 minecraft:quartz_slab[type=top]
fill 1000 121 973 1000 121 975 minecraft:quartz_slab[type=top]
setblock 993 122 971 minecraft:quartz_slab
setblock 992 122 972 minecraft:quartz_slab
setblock 999 122 971 minecraft:quartz_slab
setblock 1000 122 972 minecraft:quartz_slab

summon minecraft:armor_stand 989.3 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:stone",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 989.9 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:grass_block",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 990.5 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:dirt",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 991.1 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:gravel",Count:1b}],NoGravity:1,CustomName:'{"text":"20⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 991.7 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:oak_wood",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 992.3 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:white_wool",Count:1b}],NoGravity:1,CustomName:'{"text":"5⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 992.9 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:bricks",Count:1b}],NoGravity:1,CustomName:'{"text":"20⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 993.5 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:glass",Count:1b}],NoGravity:1,CustomName:'{"text":"5⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 994.1 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:ice",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 994.7 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:snow_block",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 995.3 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:obsidian",Count:1b}],NoGravity:1,CustomName:'{"text":"90⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 995.9 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:carved_pumpkin",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 996.5 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:end_stone",Count:1b}],NoGravity:1,CustomName:'{"text":"75⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 997.1 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:soul_sand",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 997.7 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:light_gray_terracotta",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 998.3 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:coal_ore",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 998.9 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_ore",Count:1b}],NoGravity:1,CustomName:'{"text":"35⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 999.5 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:redstone_ore",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1000.1 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:lapis_ore",Count:1b}],NoGravity:1,CustomName:'{"text":"90⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1000.7 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:diamond_ore",Count:1b}],NoGravity:1,CustomName:'{"text":"100⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1001.3 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:redstone_block",Count:1b}],NoGravity:1,CustomName:'{"text":"25⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1001.9 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:tnt",Count:1b}],NoGravity:1,CustomName:'{"text":"35⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1002.5 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:slime_block",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1003.1 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:dispenser",Count:1b}],NoGravity:1,CustomName:'{"text":"35⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1003.7 121.4 967.7 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:sticky_piston",Count:1b}],NoGravity:1,CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}


summon minecraft:armor_stand 1004.3 121.4 968.3 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:bookshelf",Count:1b}],NoGravity:1,Rotation:[90f,0f],CustomName:'{"text":"35⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1004.3 121.4 968.9 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:enchanting_table",Count:1b}],NoGravity:1,Rotation:[90f,0f],CustomName:'{"text":"100⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1004.3 121.4 969.5 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:anvil",Count:1b}],NoGravity:1,Rotation:[90f,0f],CustomName:'{"text":"90⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1004.3 121.4 970.1 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:trapped_chest",Count:1b}],NoGravity:1,Rotation:[90f,0f],CustomName:'{"text":"10⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 1004.1 121.05 970.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:cobweb",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 970.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 971.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:tripwire_hook",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 971.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"20⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.3 121.05 971.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:redstone_torch",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 971.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"35⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.3 121.45 972.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:repeater",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 972.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"35⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 973.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:firework_rocket",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 973.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"35⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 973.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:oak_sign",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 973.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"5⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 974.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:fire_charge",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 974.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"5⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 974.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:experience_bottle",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 974.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"25⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 975.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:bread",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 975.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"5⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 976.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:chicken_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 976.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"20⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 976.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:witch_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 976.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"90⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 977.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:rabbit_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 977.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"350⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 977.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:shulker_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 977.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"90⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 978.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:blaze_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 978.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"200⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 979.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:creeper_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 979.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"90⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 979.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:spider_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 979.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 980.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:skeleton_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 980.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"75⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 980.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:zombie_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 980.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 1004.1 121.05 981.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:wolf_spawn_egg",Count:1b}],NoGravity:1,Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 1004.3 120.9 981.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"65⛁","color":"yellow"}'}


summon minecraft:armor_stand 988.7 121.4 968.3 {Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],NoGravity:1,Rotation:[-90f,0f],CustomName:'{"text":"150⛁","color":"yellow"}',CustomNameVisible:1}
summon minecraft:armor_stand 988.9 121.5 968.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:bone",Count:1b}],NoGravity:1,Rotation:[90f,0f],Pose:{Head:[0f,0f,45f]}}
summon minecraft:area_effect_cloud 988.7 120.9 968.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"5⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 969.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:oak_sapling",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 969.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 970.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_hoe",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 970.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 970.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_shovel",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 970.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"60⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 971.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_axe",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 971.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"70⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 971.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:stone_pickaxe",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 971.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"40⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 972.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_pickaxe",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 972.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"80⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 973.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:diamond_pickaxe",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 973.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"160⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 973.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:water_bucket",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 973.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"60⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 974.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:lava_bucket",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 974.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"100⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 974.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:golden_apple",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 974.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 975.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:ender_pearl",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 975.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"100⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 976.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:elytra",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 976.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"250⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 976.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:arrow",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 976.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"20⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 977.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:bow",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 977.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"100⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 977.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:flint_and_steel",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 977.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 978.5 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:fishing_rod",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 978.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 979.1 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:wooden_sword",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 979.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"10⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 979.7 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:stone_sword",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 979.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"40⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 980.3 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:iron_sword",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 980.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"80⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.05 980.9 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:diamond_sword",Count:1b}],NoGravity:1,Rotation:[-90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 980.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"160⛁","color":"yellow"}'}
summon minecraft:armor_stand 988.9 121.4 981.45 {CustomName:'"Shop Item"',Marker:1,Invisible:1b,Small:1b,ArmorItems:[{},{},{},{id:"minecraft:shield",Count:1b}],NoGravity:1,Pose:{Head:[0f,0f,-90f]},Rotation:[90f,0f]}
summon minecraft:area_effect_cloud 988.7 120.9 981.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"50⛁","color":"yellow"}'}




summon minecraft:area_effect_cloud 989.3 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[10.0f,01.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 989.9 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[10.0f,02.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 990.5 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x8","color":"dark_gray"}',Rotation:[10.0f,03.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 991.1 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x24","color":"dark_gray"}',Rotation:[20.0f,04.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 991.7 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x3","color":"dark_gray"}',Rotation:[10.0f,05.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 992.3 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[5.0f,06.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 992.9 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x8","color":"dark_gray"}',Rotation:[20.0f,07.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 993.5 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x5","color":"dark_gray"}',Rotation:[5.0f,08.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 994.1 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x4","color":"dark_gray"}',Rotation:[25.0f,09.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 994.7 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x4","color":"dark_gray"}',Rotation:[25.0f,10.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 995.3 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[90.0f,11.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 995.9 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[25.0f,12.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 996.5 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[75.0f,13.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 997.1 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x4","color":"dark_gray"}',Rotation:[25.0f,14.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 997.7 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x18","color":"dark_gray"}',Rotation:[25.0f,15.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 998.3 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x16","color":"dark_gray"}',Rotation:[25.0f,16.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 998.9 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x5","color":"dark_gray"}',Rotation:[35.0f,17.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 999.5 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x12","color":"dark_gray"}',Rotation:[25.0f,18.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1000.1 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[90.0f,19.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1000.7 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x5","color":"dark_gray"}',Rotation:[100.0f,20.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1001.3 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[25.0f,21.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1001.9 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[35.0f,22.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1002.5 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[10.0f,23.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1003.1 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[35.0f,24.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1003.7 121.8 967.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[10.0f,25.0f],Tags:["shop_id"]}

summon minecraft:area_effect_cloud 1004.3 121.8 968.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[35.0f,26.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 968.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[100.0f,27.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 969.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[90.0f,28.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 970.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[10.0f,29.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 970.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x3","color":"dark_gray"}',Rotation:[50.0f,30.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 971.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[20.0f,31.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 971.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x10","color":"dark_gray"}',Rotation:[35.0f,32.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 972.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x5","color":"dark_gray"}',Rotation:[35.0f,33.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 973.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[35.0f,34.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 973.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[5.0f,35.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 974.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x8","color":"dark_gray"}',Rotation:[5.0f,36.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 974.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x6","color":"dark_gray"}',Rotation:[25.0f,37.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 975.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x3","color":"dark_gray"}',Rotation:[5.0f,38.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 976.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[20.0f,39.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 976.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[90.0f,40.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 977.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[350.0f,41.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 977.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[90.0f,42.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 978.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[200.0f,43.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 979.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[90.0f,44.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 979.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,45.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 980.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[75.0f,46.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 980.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,47.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 1004.3 121.8 981.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x2","color":"dark_gray"}',Rotation:[65.0f,48.0f],Tags:["shop_id"]}

summon minecraft:area_effect_cloud 988.7 121.8 968.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[150.0f,49.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 968.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[5.0f,50.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 969.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,51.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 970.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,52.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 970.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[60.0f,53.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 971.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[70.0f,54.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 971.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[40.0f,55.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 972.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[80.0f,56.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 973.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[160.0f,57.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 973.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[60.0f,58.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 974.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[100.0f,59.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 974.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,60.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 975.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[100.0f,61.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 976.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[250.0f,62.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 976.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x3","color":"dark_gray"}',Rotation:[20.0f,63.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 977.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[100.0f,64.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 977.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,65.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 978.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,66.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 979.1 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[10.0f,67.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 979.7 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[40.0f,68.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 980.3 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[80.0f,69.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 980.9 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[160.0f,70.0f],Tags:["shop_id"]}
summon minecraft:area_effect_cloud 988.7 121.8 981.5 {Duration:1000000,CustomNameVisible:1,CustomName:'{"text":"x1","color":"dark_gray"}',Rotation:[50.0f,71.0f],Tags:["shop_id"]}


summon item 992 122.5 975 {Invulnerable:1,Item:{id:"minecraft:iron_sword",Count:1b},Age:-32768,PickupDelay:32767}
summon item 992 122.5 974 {Invulnerable:1,Item:{id:"minecraft:chainmail_chestplate",Count:1b},Age:-32768,PickupDelay:32767}
summon item 992 122.5 973 {Invulnerable:1,Item:{id:"minecraft:bow",Count:1b},Age:-32768,PickupDelay:32767}

summon item 994 122.5 971 {Invulnerable:1,Item:{id:"minecraft:tnt",Count:1b},Age:-32768,PickupDelay:32767}
summon item 998 122.5 971 {Invulnerable:1,Item:{id:"minecraft:bricks",Count:1b},Age:-32768,PickupDelay:32767}

summon item 1000 122.5 973 {Invulnerable:1,Item:{id:"minecraft:enchanting_table",Count:1b},Age:-32768,PickupDelay:32767}
summon item 1000 122.5 974 {Invulnerable:1,Item:{id:"minecraft:elytra",Count:1b},Age:-32768,PickupDelay:32767}
summon item 1000 122.5 975 {Invulnerable:1,Item:{id:"minecraft:golden_pickaxe",Count:1b},Age:-32768,PickupDelay:32767}

summon item 1002 122.5 982 {Invulnerable:1,Item:{id:"minecraft:potion",Count:1b,tag:{CustomPotionColor:1751787}},Age:-32768,PickupDelay:32767}
summon item 1001 122.5 982 {Invulnerable:1,Item:{id:"minecraft:brewing_stand",Count:1b},Age:-32768,PickupDelay:32767}
summon item 1000 122.5 982 {Invulnerable:1,Item:{id:"minecraft:cobweb",Count:1b},Age:-32768,PickupDelay:32767}
summon item 999 122.5 982 {Invulnerable:1,Item:{id:"minecraft:ender_eye",Count:1b},Age:-32768,PickupDelay:32767}

summon item 993 122.5 982 {Invulnerable:1,Item:{id:"minecraft:diamond_sword",Count:1b},Age:-32768,PickupDelay:32767}
summon item 992 122.5 982 {Invulnerable:1,Item:{id:"minecraft:redstone_torch",Count:1b},Age:-32768,PickupDelay:32767}
summon item 991 122.5 982 {Invulnerable:1,Item:{id:"minecraft:saddle",Count:1b},Age:-32768,PickupDelay:32767}
summon item 990 122.5 982 {Invulnerable:1,Item:{id:"minecraft:grass",Count:1b},Age:-32768,PickupDelay:32767}


setblock 1002 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 500"}}',Text2:'{"text":"Rusher Kit","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 500","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/rusher"}}'}
setblock 1001 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 500"}}',Text2:'{"text":"Alchemist Kit","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 500","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/alchemist"}}'}
setblock 1000 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 500"}}',Text2:'{"text":"Troll Kit","color":"dark_red","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 500","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/troll"}}'}
setblock 999 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 500"}}',Text2:'{"text":"Spy Kit","color":"dark_gray","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 500","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/spy"}}'}

setblock 993 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 900"}}',Text2:'{"text":"Fighter Kit","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 900","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/fighter"}}'}
setblock 992 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 900"}}',Text2:'{"text":"Engineer Kit","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 900","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/engineer"}}'}
setblock 991 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 900"}}',Text2:'{"text":"Tamer Kit","color":"gold","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 900","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/tamer"}}'}
setblock 990 121 981 minecraft:oak_wall_sign[facing=north]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 900"}}',Text2:'{"text":"Survivor Kit","color":"dark_red","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 900","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/survivor"}}'}

setblock 993 121 975 minecraft:oak_wall_sign[facing=east]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Knight Kit","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/knight"}}'}
setblock 993 121 974 minecraft:oak_wall_sign[facing=east]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Tank Kit","color":"dark_gray","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/tank"}}'}
setblock 993 121 973 minecraft:oak_wall_sign[facing=east]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Archer Kit","color":"dark_green","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/bowman"}}'}
setblock 994 121 972 minecraft:oak_wall_sign[facing=south]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 250"}}',Text2:'{"text":"Cannoneer Kit","color":"dark_red","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 250","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/cannoneer"}}'}
setblock 998 121 972 minecraft:oak_wall_sign[facing=south]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 250"}}',Text2:'{"text":"Architect Kit","color":"dark_blue","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 250","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/architect"}}'}

setblock 999 121 973 minecraft:oak_wall_sign[facing=west]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Enchanter Kit","color":"dark_purple","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/enchanter"}}'}
setblock 999 121 974 minecraft:oak_wall_sign[facing=west]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Aviator Kit","color":"dark_gray","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/aviator"}}'}
setblock 999 121 975 minecraft:oak_wall_sign[facing=west]{Text1:'{"text":"","clickEvent":{"action":"run_command","value":"/scoreboard players set @s shop_cost 300"}}',Text2:'{"text":"Miner Kit","color":"gold","bold":true,"clickEvent":{"action":"run_command","value":"/execute if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000"}}', Text4:'{"text":"","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run scoreboard players operation @s shop_points -= @s shop_cost"}}', Text3:'{"text":"Cost: 300","color":"dark_gray","clickEvent":{"action":"run_command","value":"/execute unless score @s shop_points < @s shop_cost run function game:misc/shop/kit/miner"}}'}

summon area_effect_cloud 996 122.3 982.6 {Duration:1000000,CustomNameVisible:1b,CustomName:'{"text":"- Ready -","bold":true,"color":"aqua"}'}
setblock 996 121 977 minecraft:oak_wall_sign[facing=north]
data merge block 996 121 977 {Text2:"{\"text\":\"Reset your\",\"color\":\"dark_red\",\"bold\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function game:misc/shop/reset\"}}",Text3:"{\"text\":\"inventory\",\"color\":\"dark_red\",\"bold\":\"true\"}"}
setblock 996 121 978 minecraft:oak_wall_sign[facing=south]
data merge block 996 121 978 {Text2:"{\"text\":\"Reset your\",\"color\":\"dark_red\",\"bold\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function game:misc/shop/reset\"}}",Text3:"{\"text\":\"inventory\",\"color\":\"dark_red\",\"bold\":\"true\"}"}