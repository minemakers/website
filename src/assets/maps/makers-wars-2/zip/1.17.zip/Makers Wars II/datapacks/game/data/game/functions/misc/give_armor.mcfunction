item replace entity @s[team=p1] armor.feet with leather_boots{display:{color:10855845}}
item replace entity @s[team=p2] armor.feet with leather_boots{display:{color:5006011}}
item replace entity @s[team=p3] armor.feet with leather_boots{display:{color:15066419}}
item replace entity @s[team=p4] armor.feet with leather_boots{display:{color:16777215}}
item replace entity @s[team=p5] armor.feet with leather_boots{display:{color:14188339}}
item replace entity @s[team=p6] armor.feet with leather_boots{display:{color:0}}
item replace entity @s[team=p7] armor.feet with leather_boots{display:{color:6717235}}
item replace entity @s[team=p8] armor.feet with leather_boots{display:{color:10040115}}

item replace entity @s[team=p1] armor.legs with leather_leggings{display:{color:10855845}}
item replace entity @s[team=p2] armor.legs with leather_leggings{display:{color:5006011}}
item replace entity @s[team=p3] armor.legs with leather_leggings{display:{color:15066419}}
item replace entity @s[team=p4] armor.legs with leather_leggings{display:{color:16777215}}
item replace entity @s[team=p5] armor.legs with leather_leggings{display:{color:14188339}}
item replace entity @s[team=p6] armor.legs with leather_leggings{display:{color:0}}
item replace entity @s[team=p7] armor.legs with leather_leggings{display:{color:6717235}}
item replace entity @s[team=p8] armor.legs with leather_leggings{display:{color:10040115}}

item replace entity @s[team=p1] armor.chest with leather_chestplate{display:{color:10855845}}
item replace entity @s[team=p2] armor.chest with leather_chestplate{display:{color:5006011}}
item replace entity @s[team=p3] armor.chest with leather_chestplate{display:{color:15066419}}
item replace entity @s[team=p4] armor.chest with leather_chestplate{display:{color:16777215}}
item replace entity @s[team=p5] armor.chest with leather_chestplate{display:{color:14188339}}
item replace entity @s[team=p6] armor.chest with leather_chestplate{display:{color:0}}
item replace entity @s[team=p7] armor.chest with leather_chestplate{display:{color:6717235}}
item replace entity @s[team=p8] armor.chest with leather_chestplate{display:{color:10040115}}

item replace entity @s[team=p1] armor.head with leather_helmet{display:{color:10855845}}
item replace entity @s[team=p2] armor.head with leather_helmet{display:{color:5006011}}
item replace entity @s[team=p3] armor.head with leather_helmet{display:{color:15066419}}
item replace entity @s[team=p4] armor.head with leather_helmet{display:{color:16777215}}
item replace entity @s[team=p5] armor.head with leather_helmet{display:{color:14188339}}
item replace entity @s[team=p6] armor.head with leather_helmet{display:{color:0}}
item replace entity @s[team=p7] armor.head with leather_helmet{display:{color:6717235}}
item replace entity @s[team=p8] armor.head with leather_helmet{display:{color:10040115}}