
# Makers Wars II - Copyright (c) MineMakers Team (by Aksiome)

execute if score game_time var < peace_time var run function game:misc/peace/apply
execute as @e[tag=new_spawned_mob] at @s run function game:misc/spawn_mob

execute at @a if block ~.4 ~ ~ nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~-.4 ~ ~ nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~ ~ ~.4 nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~ ~ ~-.4 nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal

tag @a[tag=inside_arena] remove inside_arena
tag @a[x=954,y=0,z=965,dx=86,dy=200,dz=86,gamemode=!spectator] add inside_arena
kill @a[tag=!inside_arena,gamemode=!spectator]

execute as @e[type=armor_stand,tag=falling_chest,nbt={OnGround:1b}] at @s run function game:misc/chest/create
execute as @e[type=armor_stand,tag=falling_chest] at @s run particle minecraft:witch ~ ~3 ~ 0 0 0 0.01 3 force
execute as @e[type=armor_stand,tag=falling_chest] at @s run particle minecraft:smoke ~ ~3 ~ 0 0 0 0.01 3 force


execute as @a[scores={death=1..}] run function game:misc/eliminate

kill @e[x=1040,y=0,z=965,dx=0,dy=200,dz=86,type=ender_pearl]
kill @e[x=954,y=0,z=965,dx=0,dy=200,dz=86,type=ender_pearl]
kill @e[x=954,y=0,z=1051,dx=86,dy=200,dz=0,type=ender_pearl]
kill @e[x=954,y=0,z=965,dx=86,dy=200,dz=0,type=ender_pearl]
clear @a minecraft:ender_chest

execute as @a[scores={connection=-1}] run function game:misc/resume
execute if score teams var matches ..1 run function game:misc/force_stop
execute if score teams var matches 2.. run scoreboard players reset @a confirm

function game:events

execute as @a[nbt={SelectedItem:{id:"minecraft:phantom_spawn_egg"}}] run item modify entity @s[nbt=!{SelectedItem:{id:"minecraft:phantom_spawn_egg",tag:{crafted_egg:true}}}] weapon.mainhand game:phantom_egg
execute as @a[nbt={Inventory:[{Slot:-106b,id:"minecraft:phantom_spawn_egg"}]}] run item modify entity @s[nbt=!{Inventory:[{Slot:-106b,id:"minecraft:phantom_spawn_egg",tag:{crafted_egg:true}}]}] weapon.offhand game:phantom_egg

execute as @a[x=850,y=180,z=850,dx=300,dy=100,dz=300,gamemode=!spectator] at @s run tp @s ~ 178 ~
execute as @a[x=850,y=136,z=850,dx=300,dy=150,dz=300,gamemode=survival] run gamemode adventure @s
execute as @a[x=850,y=134,z=850,dx=300,dy=-150,dz=300,gamemode=adventure] run gamemode survival @s