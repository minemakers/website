execute at @e[type=marker,tag=arena_clone] run clone ~ ~ ~ ~40 ~15 ~40 976 ~35 988 masked
execute as @e[type=marker,tag=arena_clone] at @s run tp @s ~ ~15 ~
