scoreboard players set game_status var 1
scoreboard players set countdown var 67
kill @e[type=marker,tag=team_balance]

function game:structure/shop

tp @a[x=996.5,y=121,z=982.5,distance=..1] 996 122.5 975 0 35

tellraw @a {"text":"\nPress TAB to see how much coins you have! Use them to buy kits and items by right-clicking them.","color":"green"}

scoreboard players reset * death
scoreboard players reset * confirm

clear @a
scoreboard players reset @a shop_cost
scoreboard players reset @a shop_id
scoreboard players operation @a[team=p1,gamemode=adventure] shop_points = team1 shop_points
scoreboard players operation @a[team=p2,gamemode=adventure] shop_points = team2 shop_points
scoreboard players operation @a[team=p3,gamemode=adventure] shop_points = team3 shop_points
scoreboard players operation @a[team=p4,gamemode=adventure] shop_points = team4 shop_points
scoreboard players operation @a[team=p5,gamemode=adventure] shop_points = team5 shop_points
scoreboard players operation @a[team=p6,gamemode=adventure] shop_points = team6 shop_points
scoreboard players operation @a[team=p7,gamemode=adventure] shop_points = team7 shop_points
scoreboard players operation @a[team=p8,gamemode=adventure] shop_points = team8 shop_points

scoreboard objectives setdisplay list shop_points

execute as @a run function game:misc/give_armor
gamerule doTileDrops true


scoreboard players set timer events 45
scoreboard players operation timer events += peace_time var
scoreboard players set @a damage_dealt 0
scoreboard players set @a damage_taken 0
scoreboard players set @a spawn_count 0
scoreboard players set @a kills 0