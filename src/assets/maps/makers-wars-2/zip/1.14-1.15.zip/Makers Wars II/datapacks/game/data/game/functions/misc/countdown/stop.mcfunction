scoreboard players set game_status var 2

title @a title [{"text":"Makers Wars","color":"green"}]
title @a subtitle [{"text":"The game has just started!","color":"yellow"}]
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 100000

fill 1030 92 1010 1034 96 1006 minecraft:air
fill 1017 92 983 1021 96 987 minecraft:air
fill 994 92 971 998 96 975 minecraft:air
fill 971 92 987 975 96 983 minecraft:air
fill 960 92 1010 964 96 1006 minecraft:air
fill 975 92 1032 971 96 1028 minecraft:air
fill 998 92 1045 994 96 1041 minecraft:air
fill 1021 92 1028 1017 96 1032 minecraft:air

effect clear @a
gamemode survival @a[gamemode=adventure]
effect give @a minecraft:slow_falling 3 0 true

scoreboard objectives setdisplay list health

scoreboard players set @a[gamemode=survival] playing 1

scoreboard players operation #peace_remain var = peace_time var
scoreboard players remove #peace_remain var 1

execute store result bossbar game:peace_time max run scoreboard players get #peace_remain var
execute store result bossbar game:peace_time value run scoreboard players get #peace_remain var
execute if score peace_time var matches 1.. run bossbar set game:peace_time players @a

scoreboard players reset freeze events
scoreboard players reset creeper_rain events
scoreboard players reset wither events
scoreboard players reset scrambled_inv events
scoreboard players reset meteorites events
scoreboard players reset bad_effect events
scoreboard players reset cursed_area events
scoreboard players reset gift events
scoreboard players reset spread events
scoreboard players reset swap events
scoreboard players reset rebellion events
scoreboard players reset jump_boost events
scoreboard players reset gravity events
scoreboard players reset suicidal_mobs events
scoreboard players reset super_power events
scoreboard players reset resurrection events