execute if score cursed_area events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"An area has been cursed!","color":"gray"}]

execute if score cursed_area events matches 2 run playsound minecraft:block.end_portal.spawn master @a 1000 100 1000 1000 1.6
execute if score cursed_area events matches 2 run summon area_effect_cloud 0 150 0 {Particle:"ambient_entity_effect",Tags:["cursed_area_new"]}
execute if score cursed_area events matches 13 run summon area_effect_cloud 0 150 0 {Particle:"ambient_entity_effect",Tags:["cursed_area_new"]}
execute if score cursed_area events matches 2..13 run spreadplayers 996 1008 0 40 false @e[x=0,y=150,z=0,distance=..2,tag=cursed_area_new,type=area_effect_cloud]
execute if score cursed_area events matches 2..13 at @e[tag=cursed_area_new] run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",ReapplicationDelay:10,Radius:4f,Duration:2400,Tags:["cursed_area"],Effects:[{Id:2b,Amplifier:0b,Duration:40},{Id:4b,Amplifier:0b,Duration:40},{Id:9b,Amplifier:0b,Duration:40},{Id:17b,Amplifier:0b,Duration:40},{Id:18b,Amplifier:0b,Duration:40},{Id:20b,Amplifier:0b,Duration:40}],CustomName:"{\"text\":\"a cursed area\"}"}

execute if score cursed_area events matches 13 run scoreboard players reset cursed_area events
execute if score cursed_area events matches 1.. run scoreboard players add cursed_area events 1
