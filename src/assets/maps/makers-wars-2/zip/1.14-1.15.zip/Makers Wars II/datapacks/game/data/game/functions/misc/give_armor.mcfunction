replaceitem entity @s[team=p1] armor.feet leather_boots{display:{color:10855845}}
replaceitem entity @s[team=p2] armor.feet leather_boots{display:{color:5006011}}
replaceitem entity @s[team=p3] armor.feet leather_boots{display:{color:15066419}}
replaceitem entity @s[team=p4] armor.feet leather_boots{display:{color:16777215}}
replaceitem entity @s[team=p5] armor.feet leather_boots{display:{color:14188339}}
replaceitem entity @s[team=p6] armor.feet leather_boots{display:{color:0}}
replaceitem entity @s[team=p7] armor.feet leather_boots{display:{color:6717235}}
replaceitem entity @s[team=p8] armor.feet leather_boots{display:{color:10040115}}

replaceitem entity @s[team=p1] armor.legs leather_leggings{display:{color:10855845}}
replaceitem entity @s[team=p2] armor.legs leather_leggings{display:{color:5006011}}
replaceitem entity @s[team=p3] armor.legs leather_leggings{display:{color:15066419}}
replaceitem entity @s[team=p4] armor.legs leather_leggings{display:{color:16777215}}
replaceitem entity @s[team=p5] armor.legs leather_leggings{display:{color:14188339}}
replaceitem entity @s[team=p6] armor.legs leather_leggings{display:{color:0}}
replaceitem entity @s[team=p7] armor.legs leather_leggings{display:{color:6717235}}
replaceitem entity @s[team=p8] armor.legs leather_leggings{display:{color:10040115}}

replaceitem entity @s[team=p1] armor.chest leather_chestplate{display:{color:10855845}}
replaceitem entity @s[team=p2] armor.chest leather_chestplate{display:{color:5006011}}
replaceitem entity @s[team=p3] armor.chest leather_chestplate{display:{color:15066419}}
replaceitem entity @s[team=p4] armor.chest leather_chestplate{display:{color:16777215}}
replaceitem entity @s[team=p5] armor.chest leather_chestplate{display:{color:14188339}}
replaceitem entity @s[team=p6] armor.chest leather_chestplate{display:{color:0}}
replaceitem entity @s[team=p7] armor.chest leather_chestplate{display:{color:6717235}}
replaceitem entity @s[team=p8] armor.chest leather_chestplate{display:{color:10040115}}

replaceitem entity @s[team=p1] armor.head leather_helmet{display:{color:10855845}}
replaceitem entity @s[team=p2] armor.head leather_helmet{display:{color:5006011}}
replaceitem entity @s[team=p3] armor.head leather_helmet{display:{color:15066419}}
replaceitem entity @s[team=p4] armor.head leather_helmet{display:{color:16777215}}
replaceitem entity @s[team=p5] armor.head leather_helmet{display:{color:14188339}}
replaceitem entity @s[team=p6] armor.head leather_helmet{display:{color:0}}
replaceitem entity @s[team=p7] armor.head leather_helmet{display:{color:6717235}}
replaceitem entity @s[team=p8] armor.head leather_helmet{display:{color:10040115}}
