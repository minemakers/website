scoreboard objectives add var dummy
scoreboard objectives add connection minecraft.custom:minecraft.leave_game
scoreboard objectives add shop_points dummy
scoreboard objectives add click_villager minecraft.custom:minecraft.talked_to_villager
scoreboard objectives add shop_id dummy
scoreboard objectives add shop_cost dummy
scoreboard objectives add health health
scoreboard objectives add events dummy
scoreboard objectives add playing dummy
scoreboard objectives add confirm trigger
scoreboard objectives add kills playerKillCount
scoreboard objectives add damage_dealt minecraft.custom:minecraft.damage_dealt
scoreboard objectives add damage_taken minecraft.custom:minecraft.damage_taken

scoreboard objectives add spawn_zombie minecraft.used:minecraft.zombie_spawn_egg
scoreboard objectives add spawn_witch minecraft.used:minecraft.witch_spawn_egg
scoreboard objectives add spawn_rabbit minecraft.used:minecraft.rabbit_spawn_egg
scoreboard objectives add spawn_shulker minecraft.used:minecraft.shulker_spawn_egg
scoreboard objectives add spawn_blaze minecraft.used:minecraft.blaze_spawn_egg
scoreboard objectives add spawn_creeper minecraft.used:minecraft.creeper_spawn_egg
scoreboard objectives add spawn_spider minecraft.used:minecraft.spider_spawn_egg
scoreboard objectives add spawn_skeleton minecraft.used:minecraft.skeleton_spawn_egg
scoreboard objectives add spawn_wolf minecraft.used:minecraft.wolf_spawn_egg
scoreboard objectives add spawn_ghast minecraft.used:minecraft.ghast_spawn_egg
scoreboard objectives add spawn_phantom minecraft.used:minecraft.phantom_spawn_egg
scoreboard objectives add spawn_count dummy

execute unless score game_status var matches 0.. run scoreboard players set game_status var 0
execute unless score shop_points var matches 0.. run scoreboard players set shop_points var 100
scoreboard objectives setdisplay list

gamerule sendCommandFeedback false

scoreboard players set #seed events 103548333
scoreboard players set #a events 1103515245
scoreboard players set #b events 65536
scoreboard players set #c events 12345
scoreboard players set #inv events -1
scoreboard players set #result events 0