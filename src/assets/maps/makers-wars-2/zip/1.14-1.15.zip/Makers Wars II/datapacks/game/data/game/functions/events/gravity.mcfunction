execute if score gravity events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"The gravity will be reversed in 10 seconds! Be prepared!","color":"gray"}]

execute if score gravity events matches 200 run playsound minecraft:block.beacon.activate master @a 1000 100 1000 10000 0.6
execute if score gravity events matches 200 run effect give @e[x=1000,y=100,z=1000,distance=..200,type=!armor_stand,type=!area_effect_cloud,type=!item] minecraft:levitation 5 4 true
execute if score gravity events matches 200 as @e[x=1000,y=100,z=1000,distance=..200,type=item] run data merge entity @s {Motion:[0.0,1.0,0.0]}


execute if score gravity events matches 200 run scoreboard players reset gravity events
execute if score gravity events matches 1.. run scoreboard players add gravity events 1
