execute at @s run tp @s ^ ^ ^.4
scoreboard players add @s shop_id 1
execute if score @s shop_id matches 8.. run tag @s add stop
execute at @s[tag=!stop] unless entity @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] run function game:misc/shop/raycast
