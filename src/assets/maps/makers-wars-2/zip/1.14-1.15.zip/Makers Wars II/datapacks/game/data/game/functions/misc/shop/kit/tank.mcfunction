give @s iron_helmet
give @s chainmail_chestplate
give @s chainmail_leggings
give @s iron_boots
give @s bricks 24
give @s cooked_beef 6