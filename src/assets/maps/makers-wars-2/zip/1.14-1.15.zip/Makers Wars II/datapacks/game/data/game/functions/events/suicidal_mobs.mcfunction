execute if score suicidal_mobs events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Pay attention, some mobs are becoming suicidal!","color":"gray"}]

execute if score suicidal_mobs events matches 27 run tag @e[type=!player,sort=random,limit=1,tag=spawned_mob] add selected
execute if score suicidal_mobs events matches 50 run tag @e[type=!player,sort=random,limit=1,tag=spawned_mob] add selected
execute if score suicidal_mobs events matches 60 run tag @e[type=!player,sort=random,limit=1,tag=spawned_mob] add selected
execute if score suicidal_mobs events matches 80 run tag @e[type=!player,sort=random,limit=1,tag=spawned_mob] add selected
execute if score suicidal_mobs events matches 120 run tag @e[type=!player,sort=random,limit=1,tag=spawned_mob] add selected

execute if score suicidal_mobs events matches 1..120 at @e[type=!player,tag=selected,tag=spawned_mob] run summon minecraft:tnt
execute if score suicidal_mobs events matches 1..120 as @e[type=!player,tag=selected,tag=spawned_mob] run kill @s

execute if score suicidal_mobs events matches 120 run scoreboard players reset suicidal_mobs events
execute if score suicidal_mobs events matches 1.. run scoreboard players add suicidal_mobs events 1
