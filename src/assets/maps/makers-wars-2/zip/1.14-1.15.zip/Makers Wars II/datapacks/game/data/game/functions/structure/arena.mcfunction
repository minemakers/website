kill @e[type=area_effect_cloud,tag=arena_clone]
execute if score arena var matches 1 run summon area_effect_cloud -17 15 12 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 2 run summon area_effect_cloud -58 15 -29 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 3 run summon area_effect_cloud -58 15 12 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 4 run summon area_effect_cloud -58 15 53 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 5 run summon area_effect_cloud -17 15 53 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 6 run summon area_effect_cloud 24 15 -29 {Tags:["arena_clone"],Duration:5}
execute if score arena var matches 7 run summon area_effect_cloud -17 15 -29 {Tags:["arena_clone"],Duration:6}
execute if score arena var matches 8 run summon area_effect_cloud 24 15 53 {Tags:["arena_clone"],Duration:7}
execute if score arena var matches 9 run summon area_effect_cloud 24 15 12 {Tags:["arena_clone"],Duration:6}

kill @e[type=item,tag=!invulnerable]
