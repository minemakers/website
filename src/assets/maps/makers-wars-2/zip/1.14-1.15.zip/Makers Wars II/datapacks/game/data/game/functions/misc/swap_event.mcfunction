tag @r[gamemode=!spectator,limit=1,distance=0.0001..] add is_swapping
tp @s @a[tag=is_swapping,limit=1]
tp @a[tag=is_swapping,limit=1] ~ ~ ~ ~ ~
tag @a[tag=is_swapping,limit=1] remove is_swapping