give @s tnt 24
give @s redstone_block 6
give @s dispenser 3
give @s spruce_planks 36
give @s repeater 3
give @s water_bucket
give @s flint_and_steel
give @s pumpkin_pie 5