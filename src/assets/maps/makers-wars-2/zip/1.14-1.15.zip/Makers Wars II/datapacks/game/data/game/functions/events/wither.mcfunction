execute if score wither events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Wither!","color":"gray"}]

execute if score wither events matches 1 run playsound minecraft:entity.wither.spawn master @a 1000 100 1000 1000 2
execute if score wither events matches 1 run summon minecraft:wither 996 130 1009

execute if score wither events matches 1 run scoreboard players reset wither events
execute if score wither events matches 1.. run scoreboard players add wither events 1
