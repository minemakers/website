give @s iron_axe
#give @s carrot_on_a_stick
#give @s pig_spawn_egg{display:{Name:"{\"text\":\"Hoverpig\",\"color\":\"yellow\",\"italic\":false}",Lore:["§7Can hover above the void"]},EntityTag:{Tags:["new_spawned_mob","flying_pig"],Saddle:1b,Health:30f,CustomName:"{\"text\":\"Hoverpig\",\"color\":\"yellow\",\"italic\":false}",Attributes:[{Name:generic.maxHealth,Base:30}]}}
give @s minecraft:splash_potion{display:{Name:"{\"text\":\"Splash Potion of Regeneration\",\"color\":\"yellow\",\"italic\":false}"},CustomPotionEffects:[{Id:6b,Amplifier:0b,Duration:1},{Id:10b,Amplifier:1b,Duration:600},{Id:11b,Amplifier:0b,Duration:200}],CustomPotionColor:16734553} 2
give @s minecraft:splash_potion{display:{Name:"{\"text\":\"Splash Potion of Instant Damage\",\"color\":\"yellow\",\"italic\":false}"},CustomPotionEffects:[{Id:7b,Amplifier:1b,Duration:1}],CustomPotionColor:4656654} 1

give @s bone 24
give @s wolf_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}} 5
give @s rotten_flesh 16
give @s spider_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}} 3
give @s shulker_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}} 2
give @s blaze_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s zombie_spawn_egg{EntityTag:{Tags:["new_spawned_mob"],ArmorItems:[{},{},{},{id:"minecraft:iron_helmet",Count:1b}]}} 3
give @s skeleton_spawn_egg{EntityTag:{Tags:["new_spawned_mob"],ArmorItems:[{},{},{},{id:"minecraft:iron_helmet",Count:1b}]}} 3
give @s witch_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}

give @s turtle_helmet
give @s stripped_oak_wood 16
give @s apple 24
