give @s minecraft:diamond_pickaxe{display:{Name:"{\"text\":\"Pickaxe of the Miner\",\"color\":\"yellow\",\"italic\":false}"},Enchantments:[{id:"minecraft:sharpness",lvl:2},{id:"minecraft:efficiency",lvl:2},{id:"minecraft:fortune",lvl:2}]}
give @s diamond_ore 6
give @s coal 16
give @s cobblestone 32
give @s torch 32

give @s cooked_cod 7
