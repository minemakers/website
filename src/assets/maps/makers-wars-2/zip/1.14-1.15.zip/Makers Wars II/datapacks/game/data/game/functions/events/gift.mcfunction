execute if score gift events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"A gift from the sky, chests are falling!","color":"gray"}]

execute if score gift events matches 5 run summon armor_stand 0 0 0 {CustomName:"\"Event Chest\"",Tags:["middle_chest","falling_chest","new_gift"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
execute if score gift events matches 35 run summon armor_stand 0 0 0 {CustomName:"\"Event Chest\"",Tags:["middle_chest","falling_chest","new_gift"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
execute if score gift events matches 50 run summon armor_stand 0 0 0 {CustomName:"\"Event Chest\"",Tags:["middle_chest","falling_chest","new_gift"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}

execute if score gift events matches 1..50 if entity @e[type=armor_stand,tag=new_gift] run spreadplayers 996 1008 1 40 false @e[type=armor_stand,tag=new_gift,x=0,y=0,z=0,distance=..25]
execute if score gift events matches 1..50 as @e[type=armor_stand,tag=new_gift] at @s run tp @s ~ 150 ~
execute if score gift events matches 1..50 at @e[type=armor_stand,tag=new_gift] run summon firework_rocket ~ 120 ~ {LifeTime:20,FireworksItem:{id:firework_rocket,Count:1,tag:{Fireworks:{Explosions:[{Type:1,Flicker:1,Colors:[I;16711680],FadeColors:[I;16711680]},{Type:1,Flicker:1,Colors:[I;16748288],FadeColors:[I;16746496]},{Type:1,Flicker:1,Colors:[I;16774400],FadeColors:[I;16769024]},{Type:1,Flicker:1,Colors:[I;3211008],FadeColors:[I;65287]},{Type:1,Flicker:1,Colors:[I;65477],FadeColors:[I;65525]},{Type:1,Flicker:1,Colors:[I;3839],FadeColors:[I;3539199]},{Type:1,Flicker:1,Colors:[I;16711918],FadeColors:[I;16711904]}]}}}}
execute if score gift events matches 1..50 as @e[type=armor_stand,tag=new_gift] run tag @s remove new_gift

execute if score gift events matches 50 run scoreboard players reset gift events
execute if score gift events matches 1.. run scoreboard players add gift events 1