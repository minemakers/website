
# Makers Wars II - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players remove #shop_clock var 1
execute if score #shop_clock var matches ..0 run function game:misc/shop

execute as @a[scores={click_villager=1..}] if score @s shop_points < @s shop_cost at @s run playsound minecraft:entity.item.break master @s ~ ~ ~ 100000
execute as @a[scores={click_villager=1..}] unless score @s shop_points < @s shop_cost run function game:misc/shop/buy

execute if score countdown var matches 7.. run particle minecraft:witch 996 121.1 982.7 0.25 0.1 0.15 0 4 force @a
execute as @a[x=996.5,y=121,z=982.5,distance=..0.6,gamemode=adventure] run function game:misc/shop/ready
execute if score countdown var matches 7..10000 unless entity @a[x=996,y=122,z=975,distance=..25,gamemode=adventure] run scoreboard players set countdown var 6

kill @e[type=item,nbt=!{Invulnerable:1b},x=996,y=125,z=975,distance=..25]
kill @e[type=minecraft:fishing_bobber]
kill @e[type=minecraft:arrow]
kill @e[type=minecraft:experience_bottle]
kill @e[type=minecraft:ender_pearl] 