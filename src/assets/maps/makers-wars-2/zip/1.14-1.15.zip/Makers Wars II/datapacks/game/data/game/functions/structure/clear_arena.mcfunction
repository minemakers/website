execute as @e[type=area_effect_cloud,tag=arena_clear,x=0,y=100,z=0,distance=..3] run function game:structure/lobby
execute as @e[type=area_effect_cloud,tag=arena_clear,x=0,y=80,z=0,distance=..3] run function game:structure/island
execute as @e[type=area_effect_cloud,tag=arena_clear,x=0,y=40,z=0,distance=..3] run scoreboard players set @a connection 0
execute as @e[type=area_effect_cloud,tag=arena_clear,x=0,y=20,z=0,distance=..3] run function game:structure/arena
#execute as @e[type=area_effect_cloud,tag=arena_clear,x=0,y=0,z=0,distance=..3] run tellraw @a [{"text":"Reset done!","color":"red"}]

execute at @e[type=area_effect_cloud,tag=arena_clear] run fill 1040 ~ 1051 954 ~3 965 air replace
execute as @e[type=area_effect_cloud,tag=arena_clear] at @s run tp @s ~ ~-4 ~
