fill 1030 84 1010 1034 84 1006 minecraft:light_gray_terracotta
fill 1017 84 983 1021 84 987 minecraft:red_terracotta
fill 994 84 971 998 84 975 minecraft:lime_terracotta
fill 971 84 987 975 84 983 minecraft:black_terracotta
fill 960 84 1010 964 84 1006 minecraft:orange_terracotta
fill 975 84 1032 971 84 1028 minecraft:white_terracotta
fill 998 84 1045 994 84 1041 minecraft:yellow_terracotta
fill 1021 84 1028 1017 84 1032 minecraft:light_blue_terracotta

fill 1030 92 1010 1034 96 1006 minecraft:barrier
fill 1017 92 983 1021 96 987 minecraft:barrier
fill 994 92 971 998 96 975 minecraft:barrier
fill 971 92 987 975 96 983 minecraft:barrier
fill 960 92 1010 964 96 1006 minecraft:barrier
fill 975 92 1032 971 96 1028 minecraft:barrier
fill 998 92 1045 994 96 1041 minecraft:barrier
fill 1021 92 1028 1017 96 1032 minecraft:barrier

fill 1031 93 1009 1033 95 1007 minecraft:air
fill 1018 93 984 1020 95 986 minecraft:air
fill 995 93 972 997 95 974 minecraft:air
fill 972 93 986 974 95 984 minecraft:air
fill 961 93 1009 963 95 1007 minecraft:air
fill 974 93 1031 972 95 1029 minecraft:air
fill 997 93 1044 995 95 1042 minecraft:air
fill 1020 93 1029 1018 95 1031 minecraft:air
