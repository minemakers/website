scoreboard players set @a shop_id 0
tag @e[type=villager,tag=shop_click] add available
execute as @a[gamemode=!spectator] at @s positioned ^ ^ ^.5 if entity @e[tag=shop_id,distance=..3] run function game:misc/shop/getid
function game:misc/shop/title
scoreboard players set #shop_clock var 4