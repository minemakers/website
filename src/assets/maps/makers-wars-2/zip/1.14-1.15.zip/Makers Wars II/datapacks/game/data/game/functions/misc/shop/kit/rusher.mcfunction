give @s wooden_sword
give @s glass 64
give @s potion{CustomPotionEffects:[{Id:1,Amplifier:2,Duration:1000,ShowParticles:false},{Id:8,Amplifier:2,Duration:1000,ShowParticles:false}],display:{Name:"{\"text\":\"Rusher Potion\",\"italic\":\"false\",\"color\":\"yellow\"}"},CustomPotionColor:1751787}
give @s ender_pearl 2
give @s elytra
give @s firework_rocket{display:{Name:"{\"text\":\"Empty Firework Rocket\",\"color\":\"white\",\"italic\":false}"}} 2
give @s bread 6
