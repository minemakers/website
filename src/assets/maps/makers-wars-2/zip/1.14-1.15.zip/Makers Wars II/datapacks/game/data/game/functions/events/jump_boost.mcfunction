execute if score jump_boost events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Everyone received a jump boost effect!","color":"gray"}]

execute if score jump_boost events matches 1 run playsound minecraft:entity.rabbit.hurt master @a 1000 100 1000 1000 0.1
execute if score jump_boost events matches 1 run effect give @a[gamemode=!spectator] jump_boost 20 8 true

execute if score jump_boost events matches 1 run scoreboard players reset jump_boost events
execute if score jump_boost events matches 1.. run scoreboard players add jump_boost events 1
