execute if score swap events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Swap!","color":"gray"}]

execute if score swap events matches 25 run playsound minecraft:entity.enderman.teleport master @a 1000 100 1000 1000 1
execute if score swap events matches 25 as @r[gamemode=!spectator,limit=1] at @s run function game:misc/swap_event

execute if score swap events matches 25 run scoreboard players reset swap events
execute if score swap events matches 1.. run scoreboard players add swap events 1