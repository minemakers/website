execute if score spread events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Everyone has been spread on the arena!","color":"gray"}]

execute if score spread events matches 1 run spreadplayers 996 1008 1 40 false @a[gamemode=!spectator]
execute if score spread events matches 1 run playsound minecraft:entity.parrot.fly ambient @a 1000 100 1000 10000 0


execute if score spread events matches 1 run scoreboard players reset spread events
execute if score spread events matches 1.. run scoreboard players add spread events 1
