execute as @e[type=!player,tag=spawned_mob,nbt=!{NoAI:1b}] run data merge entity @s {NoAI:1b}
effect give @a[gamemode=!spectator] minecraft:weakness 1000000 255 true
kill @e[type=arrow]
