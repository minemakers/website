execute if score resurrection events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Heroes never die!","color":"gray"}]

execute if score resurrection events matches 1 run playsound minecraft:entity.evoker.prepare_wololo master @a 1000 100 1000 10000 1.5
execute if score resurrection events matches 1 run tag @a[limit=1,sort=random,gamemode=spectator,scores={playing=1..}] add revive
execute if score resurrection events matches 1 run spreadplayers 996 1008 1 40 false @a[tag=revive]
execute if score resurrection events matches 1 run gamemode survival @a[tag=revive]
execute if score resurrection events matches 1 run tag @a[tag=revive] remove revive

execute if score resurrection events matches 1 run scoreboard players reset resurrection events
execute if score resurrection events matches 1.. run scoreboard players add resurrection events 1
