gamerule doTileDrops false
function game:misc/win

scoreboard players reset bad_effect events
scoreboard players reset creeper_rain events
scoreboard players reset cursed_arena events
scoreboard players reset freeze events
scoreboard players reset gift events
scoreboard players reset gravity events
scoreboard players reset jump_boost events
scoreboard players reset meteorites events
scoreboard players reset rebellion events
scoreboard players reset resurrection events
scoreboard players reset scrambled_inv events
scoreboard players reset spread events
scoreboard players reset suicidal_mobs events
scoreboard players reset super_power events
scoreboard players reset swap events
scoreboard players reset wither events
weather clear
time set noon

summon area_effect_cloud 0 140 0 {Tags:["arena_clear"],Duration:36}
kill @e[x=996,y=121,z=975,distance=..300,type=!player]

gamemode spectator @a

scoreboard players set game_status var 0
scoreboard players set game_time var 0
scoreboard players set countdown var -1
scoreboard players reset * playing
scoreboard players reset * confirm
scoreboard players reset * spawn_count

bossbar set game:shop_countdown players

scoreboard objectives setdisplay list