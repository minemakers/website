execute if entity @s[team=p1] run team join p1 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p2] run team join p2 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p3] run team join p3 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p4] run team join p4 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p5] run team join p5 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p6] run team join p6 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p7] run team join p7 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]
execute if entity @s[team=p8] run team join p8 @e[type=shulker,limit=1,sort=nearest,tag=new_spawned_mob]

scoreboard players add @s spawn_count 1
scoreboard players reset @s spawn_shulker