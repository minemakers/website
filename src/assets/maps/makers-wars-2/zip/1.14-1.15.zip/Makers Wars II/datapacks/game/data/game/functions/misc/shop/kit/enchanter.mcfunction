give @s enchanting_table 1
give @s bookshelf 8
give @s experience_bottle 15
give @s lapis_lazuli 6

give @s golden_carrot 5
