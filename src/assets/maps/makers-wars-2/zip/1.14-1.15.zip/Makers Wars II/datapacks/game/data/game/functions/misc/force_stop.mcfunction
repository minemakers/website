execute as @a unless score @s confirm matches 0.. run tellraw @s [{"text":"It seems someone left and you are the only team standing. Do you want to end the game?","color":"red"},{"text":" [yes]","color":"gold","clickEvent":{"action":"run_command","value":"/trigger confirm set 156786"},"hoverEvent":{"action":"show_text","value":"Click to end the game"}}]
execute as @a unless score @s confirm matches 0.. run scoreboard players set @a confirm 1
scoreboard players enable @a confirm
execute if entity @a[scores={confirm=156786}] run function game:controller/stop
