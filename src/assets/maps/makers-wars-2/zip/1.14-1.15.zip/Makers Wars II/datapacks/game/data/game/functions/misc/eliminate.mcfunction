#tellraw @a [{"text":"Sorry, ","color":"red"},{"selector":"@s"},{"text":" you are eliminated!"}]
gamemode spectator @s
scoreboard players reset @s death
scoreboard players set teams var 0
execute if entity @a[team=p1,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p2,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p3,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p4,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p5,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p6,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p7,gamemode=!spectator] run scoreboard players add teams var 1
execute if entity @a[team=p8,gamemode=!spectator] run scoreboard players add teams var 1
execute if score teams var matches ..1 run function game:controller/stop
scoreboard players set teams var 1000000
