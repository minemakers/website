clear @s 
scoreboard players operation @s[team=p1,gamemode=adventure] shop_points = team1 shop_points
scoreboard players operation @s[team=p2,gamemode=adventure] shop_points = team2 shop_points
scoreboard players operation @s[team=p3,gamemode=adventure] shop_points = team3 shop_points
scoreboard players operation @s[team=p4,gamemode=adventure] shop_points = team4 shop_points
scoreboard players operation @s[team=p5,gamemode=adventure] shop_points = team5 shop_points
scoreboard players operation @s[team=p6,gamemode=adventure] shop_points = team6 shop_points
scoreboard players operation @s[team=p7,gamemode=adventure] shop_points = team7 shop_points
scoreboard players operation @s[team=p8,gamemode=adventure] shop_points = team8 shop_points

execute at @s run playsound minecraft:entity.villager.no master @s


function game:misc/give_armor