tellraw @s[scores={connection=1..}] {"text":"Welcome to ","color":"green","extra":[{"text":"Makers Wars II!\n","color":"gold","bold":"true"},{"text":"\nRules:","color":"green"},{"text":" Your goal is to defeat your opponents. The last remaining team wins!","color":"gray"},{"text":"\n\n\u25c6 Classic Mode: Place blocks, attack your foes. Classic Minecraft gameplay!","color":"dark_aqua"},{"text":"\n\u25c6 Insane Mode: Random events will occur throughout the battle. Some are good, some are bad.","color":"red"}]}
title @s[scores={connection=1..}] title [{"text":"Welcome to","color":"green"}]
title @s[scores={connection=1..}] subtitle [{"text":"Makers Wars II","color":"gold"}]
playsound minecraft:entity.player.levelup master @s[scores={connection=1..}] ~ ~ ~ 10000
scoreboard players reset @s connection

xp add @s -10000 levels
spawnpoint @s 996 121 975
effect clear @s
clear @s
execute in minecraft:overworld run tp @s 996 123.5 975 0 35

execute if score game_status var matches 0 run gamemode adventure @s
execute if score game_status var matches 0 run effect give @s minecraft:regeneration 10 50 true
execute if score game_status var matches 0 run effect give @s minecraft:weakness 1000000 200 true
execute if score game_status var matches 0 run effect give @s minecraft:resistance 1000000 200 true
execute if score game_status var matches 0 run effect give @s minecraft:saturation 1000000 200 true

execute if score game_status var matches 1.. run gamemode spectator @s


recipe give @s[tag=!initialized] *

tag @s add initialized