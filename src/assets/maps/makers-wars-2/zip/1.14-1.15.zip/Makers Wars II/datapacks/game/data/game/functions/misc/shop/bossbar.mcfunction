bossbar set game:shop_countdown players @a
bossbar set game:shop_countdown max 60
scoreboard players remove countdown var 6
execute store result bossbar game:shop_countdown value run scoreboard players get countdown var
scoreboard players add countdown var 6