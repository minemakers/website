fill 979 128 965 1013 120 985 air replace
kill @e[x=996,y=121,z=975,distance=..50,type=!player]
