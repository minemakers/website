execute if score freeze events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Everybody has been frozen!","color":"gray"}]

execute if score freeze events matches 2 run playsound minecraft:block.glass.break master @a 1000 100 1000 1000 1
execute if score freeze events matches 2 at @a[gamemode=!spectator] run setblock ~ ~ ~ ice
execute if score freeze events matches 2 run effect give @a[gamemode=!spectator] slowness 100000 255 true
execute if score freeze events matches 2 run effect give @a[gamemode=!spectator] levitation 100000 130 true
execute if score freeze events matches 2 run effect give @a[gamemode=!spectator] mining_fatigue 100000 140 true
execute if score freeze events matches 2..80 at @a[gamemode=!spectator] run particle minecraft:poof ~ ~ ~ 0.2 0.2 0.2 0.1 20


execute if score freeze events matches 80 run effect clear @a[gamemode=!spectator] slowness
execute if score freeze events matches 80 run effect clear @a[gamemode=!spectator] levitation
execute if score freeze events matches 80 run effect clear @a[gamemode=!spectator] mining_fatigue
execute if score freeze events matches 80 run scoreboard players reset freeze events
execute if score freeze events matches 1.. run scoreboard players add freeze events 1
