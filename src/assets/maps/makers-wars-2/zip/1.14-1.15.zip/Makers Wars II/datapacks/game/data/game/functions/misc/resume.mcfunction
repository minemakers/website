effect give @s[gamemode=!spectator] minecraft:nausea 8 4 true
effect give @s[gamemode=!spectator] minecraft:weakness 5 4 true
scoreboard players reset @s connection