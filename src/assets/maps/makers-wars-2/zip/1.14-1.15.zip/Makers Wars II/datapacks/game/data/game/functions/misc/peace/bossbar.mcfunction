scoreboard players operation #peace_remain var = peace_time var
scoreboard players operation #peace_remain var -= game_time var
scoreboard players remove #peace_remain var 1
execute store result bossbar game:peace_time value run scoreboard players get #peace_remain var