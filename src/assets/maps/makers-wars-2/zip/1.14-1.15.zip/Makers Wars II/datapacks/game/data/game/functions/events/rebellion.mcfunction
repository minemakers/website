execute if score rebellion events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Pay attention, some mobs are rebelling against you!","color":"gray"}]

execute if score rebellion events matches 2 run tag @e[sort=random,limit=2,tag=spawned_mob,team=!] add selected
execute if score rebellion events matches 13 run tag @e[sort=random,limit=2,tag=spawned_mob,team=!] add selected
execute if score rebellion events matches 27 run tag @e[sort=random,limit=2,tag=spawned_mob,team=!] add selected
execute if score rebellion events matches 50 run tag @e[sort=random,limit=2,tag=spawned_mob,team=!] add selected
execute if score rebellion events matches 80 run tag @e[sort=random,limit=2,tag=spawned_mob,team=!] add selected

execute if score rebellion events matches 2 if entity @e[tag=selected,tag=spawned_mob] run playsound minecraft:entity.wolf.howl master @a 1000 100 1000 10000 1.4
execute if score rebellion events matches 13 if entity @e[tag=selected,tag=spawned_mob] run playsound minecraft:entity.wolf.howl master @a 1000 100 1000 10000 0.7
execute if score rebellion events matches 27 if entity @e[tag=selected,tag=spawned_mob] run playsound minecraft:entity.wolf.howl master @a 1000 100 1000 10000 1.1
execute if score rebellion events matches 50 if entity @e[tag=selected,tag=spawned_mob] run playsound minecraft:entity.wolf.howl master @a 1000 100 1000 10000 1.8
execute if score rebellion events matches 80 if entity @e[tag=selected,tag=spawned_mob] run playsound minecraft:entity.wolf.howl master @a 1000 100 1000 10000 0.4

execute if score rebellion events matches 1..80 run team leave @e[tag=selected,tag=spawned_mob]
execute if score rebellion events matches 1..80 at @e[tag=selected,tag=spawned_mob] run particle minecraft:angry_villager ~ ~2 ~ 0.4 0.2 0.4 0.1 5 force
execute if score rebellion events matches 1..80 run tag @e[tag=selected,tag=spawned_mob] remove selected

execute if score rebellion events matches 80 run scoreboard players reset rebellion events
execute if score rebellion events matches 1.. run scoreboard players add rebellion events 1
