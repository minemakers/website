execute if score scrambled_inv events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Inventory scrambled!","color":"gray"}]

execute if score scrambled_inv events matches 25 run playsound minecraft:entity.squid.hurt master @a 1000 100 1000 1000 0.7
execute if score scrambled_inv events matches 25 as @a[gamemode=!spectator] run function game:misc/scrumble_event

execute if score scrambled_inv events matches 25 run scoreboard players reset scrambled_inv events
execute if score scrambled_inv events matches 1.. run scoreboard players add scrambled_inv events 1