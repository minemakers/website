execute at @s if block ~ ~-.7 ~ air if block ~.4 ~-.7 ~.4 barrier run tag @s add flying_pig_teleport
execute at @s if block ~ ~-.7 ~ air if block ~-.4 ~-.7 ~.4 barrier run tag @s add flying_pig_teleport
execute at @s if block ~ ~-.7 ~ air if block ~.4 ~-.7 ~-.4 barrier run tag @s add flying_pig_teleport
execute at @s if block ~ ~-.7 ~ air if block ~-.4 ~-.7 ~-.4 barrier run tag @s add flying_pig_teleport
execute at @s if block ~ ~-.7 ~ barrier run tag @s add flying_pig_teleport

execute at @s run tp @s[tag=flying_pig_teleport] ~ ~-.7 ~
tag @s remove flying_pig_teleport