execute as @a[limit=1,sort=nearest,scores={spawn_witch=1..}] run function game:misc/spawn_mob/witch
execute as @a[limit=1,sort=nearest,scores={spawn_rabbit=1..}] run function game:misc/spawn_mob/rabbit
execute as @a[limit=1,sort=nearest,scores={spawn_shulker=1..}] run function game:misc/spawn_mob/shulker
execute as @a[limit=1,sort=nearest,scores={spawn_blaze=1..}] run function game:misc/spawn_mob/blaze
execute as @a[limit=1,sort=nearest,scores={spawn_creeper=1..}] run function game:misc/spawn_mob/creeper
execute as @a[limit=1,sort=nearest,scores={spawn_spider=1..}] run function game:misc/spawn_mob/spider
execute as @a[limit=1,sort=nearest,scores={spawn_skeleton=1..}] run function game:misc/spawn_mob/skeleton
execute as @a[limit=1,sort=nearest,scores={spawn_zombie=1..}] run function game:misc/spawn_mob/zombie
execute as @a[limit=1,sort=nearest,scores={spawn_wolf=1..}] run function game:misc/spawn_mob/wolf
execute as @a[limit=1,sort=nearest,scores={spawn_ghast=1..}] run function game:misc/spawn_mob/ghast
execute as @a[limit=1,sort=nearest,scores={spawn_phantom=1..}] run function game:misc/spawn_mob/phantom


tag @s add spawned_mob
tag @s remove new_spawned_mob
