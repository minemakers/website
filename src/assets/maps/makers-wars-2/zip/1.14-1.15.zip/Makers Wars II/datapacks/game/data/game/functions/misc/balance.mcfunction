scoreboard players set #team_max var 0
scoreboard players set #team_min var 1000000

scoreboard players operation team1 shop_points = shop_points var
scoreboard players operation team2 shop_points = shop_points var
scoreboard players operation team3 shop_points = shop_points var
scoreboard players operation team4 shop_points = shop_points var
scoreboard players operation team5 shop_points = shop_points var
scoreboard players operation team6 shop_points = shop_points var
scoreboard players operation team7 shop_points = shop_points var
scoreboard players operation team8 shop_points = shop_points var


execute if entity @a[team=p1,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team1"]}
execute if entity @a[team=p2,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team2"]}
execute if entity @a[team=p3,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team3"]}
execute if entity @a[team=p4,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team4"]}
execute if entity @a[team=p5,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team5"]}
execute if entity @a[team=p6,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team6"]}
execute if entity @a[team=p7,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team7"]}
execute if entity @a[team=p8,gamemode=adventure] run summon area_effect_cloud 0 0 0 {CustomName:"\"Team balance\"",Tags:["team_balance","team8"]}

execute as @a[team=p1,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team1] var 1
execute as @a[team=p2,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team2] var 1
execute as @a[team=p3,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team3] var 1
execute as @a[team=p4,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team4] var 1
execute as @a[team=p5,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team5] var 1
execute as @a[team=p6,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team6] var 1
execute as @a[team=p7,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team7] var 1
execute as @a[team=p8,gamemode=adventure] run scoreboard players add @e[type=area_effect_cloud,tag=team_balance,tag=team8] var 1

scoreboard players operation #team_max var > @e[type=area_effect_cloud,tag=team_balance] var
scoreboard players operation #team_min var < @e[type=area_effect_cloud,tag=team_balance] var

execute if score #team_max var = #team_min var run function game:controller/start
execute unless score #team_max var = #team_min var run function game:misc/balance/prompt