
# Makers Wars II - Copyright (c) MineMakers Team (by Maxo6)

execute positioned 994 121 981 unless block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b},{Slot:1b},{Slot:2b},{Slot:3b},{Slot:4b},{Slot:5b},{Slot:6b},{Slot:7b},{Slot:8b}]} run function game:controller/arena
execute positioned 998 121 981 unless block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b},{Slot:1b},{Slot:2b},{Slot:3b},{Slot:4b},{Slot:5b},{Slot:6b},{Slot:7b},{Slot:8b}]} run function game:controller/chest

execute as @e[tag=points_controller] unless entity @s[nbt={ArmorItems:[{},{},{},{Count:1b}]}] run function game:controller/points
execute as @e[tag=peace_controller] unless entity @s[nbt={ArmorItems:[{},{},{},{Count:1b}]}] run function game:controller/peace

execute if score peace_time var matches ..60 run title @a actionbar [{"text":"","color":"white"},{"text":"Peace: ","color":"dark_green","bold":"true"},{"score":{"name":"peace_time","objective":"var"}},{"text":"s"},{"text":" / ","color":"gray"},{"text":"Shop: ","color":"gold","bold":"true"},{"score":{"name":"shop_points","objective":"var"}},{"text":"⛁"}]
execute if score peace_time var matches 120 run title @a actionbar [{"text":"","color":"white"},{"text":"Peace: ","color":"dark_green","bold":"true"},{"text":"2"},{"text":"mn"},{"text":" / ","color":"gray"},{"text":"Shop: ","color":"gold","bold":"true"},{"score":{"name":"shop_points","objective":"var"}},{"text":"⛁"}]
execute if score peace_time var matches 300 run title @a actionbar [{"text":"","color":"white"},{"text":"Peace: ","color":"dark_green","bold":"true"},{"text":"5"},{"text":"mn"},{"text":" / ","color":"gray"},{"text":"Shop: ","color":"gold","bold":"true"},{"score":{"name":"shop_points","objective":"var"}},{"text":"⛁"}]

execute if entity @a[scores={click_villager=1..}] at @e[tag=start,type=villager] run function game:misc/ready


execute if entity @a[scores={confirm=7615}] run function game:misc/balance/confirm
execute if entity @a[scores={confirm=7616}] run tellraw @a ["\n",{"text":"The unbalanced team chose to not balance coins.","color":"gray"}]
execute if entity @a[scores={confirm=7616}] run function game:controller/start

scoreboard players reset @a[scores={confirm=7615..7616}] confirm

clear @a[x=996,y=121,z=975,distance=..3]
kill @e[type=item,nbt=!{Invulnerable:1b},x=996,y=125,z=975,distance=..25]
