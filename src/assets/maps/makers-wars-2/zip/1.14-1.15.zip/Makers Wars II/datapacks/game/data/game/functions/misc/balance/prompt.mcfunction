execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team1,limit=1] var = #team_min var as @a[team=p1,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team2,limit=1] var = #team_min var as @a[team=p2,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team3,limit=1] var = #team_min var as @a[team=p3,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team4,limit=1] var = #team_min var as @a[team=p4,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team5,limit=1] var = #team_min var as @a[team=p5,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team6,limit=1] var = #team_min var as @a[team=p6,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team7,limit=1] var = #team_min var as @a[team=p7,gamemode=adventure] run function game:misc/balance/ask
execute if score @e[type=area_effect_cloud,tag=team_balance,tag=team8,limit=1] var = #team_min var as @a[team=p8,gamemode=adventure] run function game:misc/balance/ask

execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team1,limit=1] var = #team_min var as @a[team=p1,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team2,limit=1] var = #team_min var as @a[team=p2,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team3,limit=1] var = #team_min var as @a[team=p3,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team4,limit=1] var = #team_min var as @a[team=p4,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team5,limit=1] var = #team_min var as @a[team=p5,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team6,limit=1] var = #team_min var as @a[team=p6,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team7,limit=1] var = #team_min var as @a[team=p7,gamemode=adventure] run function game:misc/balance/inform
execute unless score @e[type=area_effect_cloud,tag=team_balance,tag=team8,limit=1] var = #team_min var as @a[team=p8,gamemode=adventure] run function game:misc/balance/inform

playsound minecraft:block.note_block.bell ambient @a 996 120 981 10000 0