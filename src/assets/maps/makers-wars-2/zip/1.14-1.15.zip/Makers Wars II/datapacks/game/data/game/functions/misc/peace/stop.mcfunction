execute as @e[type=!player,tag=spawned_mob,nbt={NoAI:1b}] run data merge entity @s {NoAI:0b}
effect clear @a minecraft:weakness

bossbar set game:peace_time players

tellraw @a [{"text":"Peace time is over! You can now start fighting!","color":"green"}]