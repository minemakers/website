execute if score bad_effect events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Everyone received a ","color":"gray"},{"text":"bad","color":"gray","italic":"true"},{"text":" effect!","color":"gray"}]

execute if score bad_effect events matches 2 run effect give @a[gamemode=!spectator] minecraft:nausea 10 0 true
execute if score bad_effect events matches 2..10 at @a[gamemode=!spectator] run summon bat ~ ~ ~
execute if score bad_effect events matches 2 run effect give @a[gamemode=!spectator] minecraft:blindness 3 0 true
execute if score bad_effect events matches 2 at @a[gamemode=!spectator] run particle minecraft:squid_ink ~ ~1.5 ~ 0.3 0.3 0.3 0.05 100 force
execute if score bad_effect events matches 1 at @a[gamemode=!spectator] run particle smoke ~ ~ ~ 0.3 0.3 0.3 0.1 100 force
execute if score bad_effect events matches 1 run replaceitem entity @a[gamemode=!spectator] armor.head minecraft:carved_pumpkin 1
execute if score bad_effect events matches 1 run playsound minecraft:entity.blaze.shoot master @a 1000 100 1000 10000 0.6

execute if score bad_effect events matches 10 run scoreboard players reset bad_effect events
execute if score bad_effect events matches 1.. run scoreboard players add bad_effect events 1
