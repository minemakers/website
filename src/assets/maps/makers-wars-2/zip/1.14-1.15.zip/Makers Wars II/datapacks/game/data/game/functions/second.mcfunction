
# Makers Wars II - Copyright (c) MineMakers Team (by Maxo6)

scoreboard players set second var 20
execute if score countdown var matches 6..66 run function game:misc/shop/bossbar
execute if score countdown var matches 16 run tellraw @a {"text":"10 seconds remaining...","color":"gray"}
execute if score countdown var matches 16 run playsound minecraft:entity.skeleton.death master @a ~ ~ ~ 10000 0.1
execute if score countdown var matches 6 run function game:misc/countdown/start
execute if score countdown var matches 1..5 run function game:misc/countdown/title
execute if score countdown var matches 0 run function game:misc/countdown/stop
execute if score countdown var matches 0..66 run scoreboard players remove countdown var 1


execute if score game_status var matches 2 run scoreboard players add game_time var 1

execute if score game_status var matches 2 if score game_time var matches 5 run playsound minecraft:block.stone_button.click_on master @a ~ ~ ~ 100000 2
execute if score game_status var matches 2 if score game_time var matches 5 run tellraw @a [{"text":"Spawn Chests will fall in 10 seconds...","color":"yellow"}]
execute if score game_status var matches 2 if score game_time var matches 15 run function game:misc/chest/spawn

execute if score game_status var matches 2 if score game_time var matches 35 run playsound minecraft:block.stone_button.click_on master @a ~ ~ ~ 100000 2
execute if score game_status var matches 2 if score game_time var matches 35 run tellraw @a [{"text":"Middle Chests will fall in 30 seconds...","color":"yellow"}]
execute if score game_status var matches 2 if score game_time var matches 65 run function game:misc/chest/middle

execute if score game_time var < peace_time var run function game:misc/peace/bossbar
execute if score game_status var matches 2 if score game_time var = peace_time var run function game:misc/peace/stop

execute if score game_status var matches 1 if score countdown var matches 7.. run particle minecraft:barrier 996 120.8 977.99 0 0 0 1 1

execute if score game_status var matches 2 if score mode var matches 1 if score timer events matches 0 run function game:controller/events
execute if score game_status var matches 2 if score mode var matches 1 if score timer events matches 1.. run scoreboard players remove timer events 1