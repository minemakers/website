title @a title [{"text":"Makers Wars II","color":"green"}]
title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"countdown","objective":"var"}},{"text":" seconds"}]
execute if score countdown var matches 1 run title @a subtitle [{"text":"Starts in ","color":"yellow"},{"score":{"name":"countdown","objective":"var"}},{"text":" second"}]
playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 10000
title @a times 0 55 10
