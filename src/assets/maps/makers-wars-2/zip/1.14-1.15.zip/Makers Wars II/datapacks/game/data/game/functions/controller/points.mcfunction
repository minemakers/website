clear @a[gamemode=adventure]

execute if score shop_points var matches ..0 if entity @s[tag=remove] at @s run playsound minecraft:entity.item.break master @a ~ ~ ~ 0.5 1
execute if score shop_points var matches 10000.. if entity @s[tag=add] at @s run playsound minecraft:entity.item.break master @a ~ ~ ~ 0.5 1

execute unless score shop_points var matches 10000.. if entity @s[tag=add] at @s run playsound minecraft:block.stone_button.click_on master @a ~ ~ ~ 1 2
execute unless score shop_points var matches 10000.. if entity @s[tag=add] run scoreboard players add shop_points var 500
execute unless score shop_points var matches ..0 if entity @s[tag=remove] at @s run playsound minecraft:block.stone_button.click_on master @a ~ ~ ~ 1 2
execute unless score shop_points var matches ..0 if entity @s[tag=remove] run scoreboard players remove shop_points var 500

replaceitem entity @s[tag=add] armor.head player_head{SkullOwner:{Id:"b4f61444-f5fa-4668-91f0-9e00408d6298",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2VkZDIwYmU5MzUyMDk0OWU2Y2U3ODlkYzRmNDNlZmFlYjI4YzcxN2VlNmJmY2JiZTAyNzgwMTQyZjcxNiJ9fX0="}]}}}
replaceitem entity @s[tag=remove] armor.head player_head{SkullOwner:{Id:"1cd93afd-bce6-4e46-b3c6-cb26544b5cef",Properties:{textures:[{Value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmQ4YTk5ZGIyYzM3ZWM3MWQ3MTk5Y2Q1MjYzOTk4MWE3NTEzY2U5Y2NhOTYyNmEzOTM2Zjk2NWIxMzExOTMifX19"}]}}}

stopsound @a neutral minecraft:item.armor.equip_generic

title @a title [{"text":""}]
title @a subtitle [{"text":"Shop coins: ","color":"yellow"},{"score":{"name":"shop_points","objective":"var"}}]
#,{"text":"⛁"}
title @a times 0 30 10
