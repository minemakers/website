execute if score chest var matches 1 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_classic"}
execute if score chest var matches 2 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_high"}
execute if score chest var matches 3 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_extreme"}
execute if score chest var matches 4 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_hardcore"}
execute if score chest var matches 5 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_build"}
execute if score chest var matches 6 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_redstone"}
execute if score chest var matches 7 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_combat"}
execute if score chest var matches 8 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_survivor"}
execute if score chest var matches 9 if entity @s[tag=start_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:start_chest_random"}

execute if score chest var matches 1 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_classic"}
execute if score chest var matches 2 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_high"}
execute if score chest var matches 3 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_extreme"}
execute if score chest var matches 4 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_hardcore"}
execute if score chest var matches 5 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_build"}
execute if score chest var matches 6 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_redstone"}
execute if score chest var matches 7 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_combat"}
execute if score chest var matches 8 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_survivor"}
execute if score chest var matches 9 if entity @s[tag=middle_chest] run setblock ~ ~.3 ~ chest{LootTable:"game:middle_chest_random"}

kill @s

particle minecraft:witch ~ ~.5 ~ .5 .5 .5 0.1 50 force
particle minecraft:crit ~ ~.5 ~ .5 .5 .5 .2 30 force