
# Makers Wars II - Copyright (c) MineMakers Team (by Maxo6)

execute if score game_time var < peace_time var run function game:misc/peace/apply
execute as @e[tag=new_spawned_mob] at @s run function game:misc/spawn_mob

execute at @a if block ~.4 ~ ~ nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~-.4 ~ ~ nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~ ~ ~.4 nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal
execute at @a if block ~ ~ ~-.4 nether_portal run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace minecraft:nether_portal

tag @a[tag=inside_arena] remove inside_arena
tag @a[x=954,y=0,z=965,dx=86,dy=200,dz=86,gamemode=!spectator] add inside_arena
kill @a[tag=!inside_arena,gamemode=!spectator]

execute as @e[type=armor_stand,tag=falling_chest,nbt={OnGround:1b}] at @s run function game:misc/chest/create
execute as @e[type=armor_stand,tag=falling_chest] at @s run particle minecraft:witch ~ ~3 ~ 0 0 0 0.01 3 force
execute as @e[type=armor_stand,tag=falling_chest] at @s run particle minecraft:smoke ~ ~3 ~ 0 0 0 0.01 3 force


execute as @a[scores={death=1..}] run function game:misc/eliminate

kill @e[x=1040,y=0,z=965,dx=0,dy=200,dz=86,type=ender_pearl]
kill @e[x=954,y=0,z=965,dx=0,dy=200,dz=86,type=ender_pearl]
kill @e[x=954,y=0,z=1051,dx=86,dy=200,dz=0,type=ender_pearl]
kill @e[x=954,y=0,z=965,dx=86,dy=200,dz=0,type=ender_pearl]
clear @a minecraft:ender_chest

execute as @a[scores={connection=-1}] run function game:misc/resume
execute if score teams var matches ..1 run function game:misc/force_stop
execute if score teams var matches 2.. run scoreboard players reset @a confirm

function game:events

#execute at @e[type=area_effect_cloud,tag=hover_pig_barrier] run fill ~ ~ ~ ~ ~ ~ air replace barrier
#execute at @e[type=minecraft:pig,tag=flying_pig] if block ~ ~-.7 ~ air run summon area_effect_cloud ~ ~-.7 ~ {Duration:2,CustomName:"\"Hover Pig Barrier\"",Tags:["hover_pig_barrier"]}
#execute at @e[type=minecraft:pig,tag=flying_pig] if block ~ ~-.7 ~ air run particle minecraft:cloud ~ ~-.1 ~ 0.2 0.05 0.2 0 1
#execute at @e[type=minecraft:pig,tag=flying_pig] if block ~ ~-.7 ~ air run setblock ~ ~-.7 ~ barrier
#execute at @e[type=minecraft:pig,tag=flying_pig] as @a[gamemode=!spectator,distance=..1.7,nbt=!{RootVehicle:{Entity:{id:"minecraft:pig",Tags:["flying_pig"]}}}] run function game:misc/flying_pig_fix

execute as @a[nbt={SelectedItem:{id:"minecraft:phantom_spawn_egg"}}] run replaceitem entity @s[nbt=!{SelectedItem:{id:"minecraft:phantom_spawn_egg",tag:{crafted_egg:true}}}] weapon.mainhand minecraft:phantom_spawn_egg{crafted_egg:true,EntityTag:{Health:80f,Tags:["new_spawned_mob"],Size:15,HandItems:[{id:"minecraft:diamond_hoe",Count:1b,tag:{AttributeModifiers:[{AttributeName:"generic.attackDamage",Name:"generic.attackDamage",Amount:-0.2,Operation:2,UUIDLeast:328370,UUIDMost:422585}]}},{}],HandDropChances:[-327.67F,0.85F],ArmorItems:[{},{},{},{id:"minecraft:leather_helmet",Count:1b,tag:{Unbreakable:1b}}],ArmorDropChances:[0.85F,0.85F,0.85F,-327.67F],ActiveEffects:[{Id:12b,Amplifier:0b,Duration:999999999,ShowParticles:0b}],Attributes:[{Name:generic.maxHealth,Base:90},{Name:generic.followRange,Base:100},{Name:generic.knockbackResistance,Base:0.4}]}}
execute as @a[nbt={Inventory:[{Slot:-106b,id:"minecraft:phantom_spawn_egg"}]}] run replaceitem entity @s[nbt=!{Inventory:[{Slot:-106b,id:"minecraft:phantom_spawn_egg",tag:{crafted_egg:true}}]}] weapon.offhand minecraft:phantom_spawn_egg{crafted_egg:true,EntityTag:{Health:90f,Tags:["new_spawned_mob"],Size:15,HandItems:[{id:"minecraft:diamond_hoe",Count:1b,tag:{AttributeModifiers:[{AttributeName:"generic.attackDamage",Name:"generic.attackDamage",Amount:-0.2,Operation:2,UUIDLeast:328370,UUIDMost:422585}]}},{}],HandDropChances:[-327.67F,0.85F],ArmorItems:[{},{},{},{id:"minecraft:leather_helmet",Count:1b,tag:{Unbreakable:1b}}],ArmorDropChances:[0.85F,0.85F,0.85F,-327.67F],ActiveEffects:[{Id:12b,Amplifier:0b,Duration:999999999,ShowParticles:0b}],Attributes:[{Name:generic.maxHealth,Base:90},{Name:generic.followRange,Base:100},{Name:generic.knockbackResistance,Base:0.4}]}}

execute as @a[x=850,y=180,z=850,dx=300,dy=100,dz=300,gamemode=!spectator] at @s run tp @s ~ 178 ~
execute as @a[x=850,y=136,z=850,dx=300,dy=150,dz=300,gamemode=survival] run gamemode adventure @s
execute as @a[x=850,y=134,z=850,dx=300,dy=-150,dz=300,gamemode=adventure] run gamemode survival @s