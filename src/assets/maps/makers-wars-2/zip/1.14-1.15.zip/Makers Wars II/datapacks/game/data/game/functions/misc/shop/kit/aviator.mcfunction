give @s elytra
give @s firework_rocket{display:{Name:"{\"text\":\"Empty Firework Rocket\",\"color\":\"white\",\"italic\":false}"}}
give @s fishing_rod

give @s cooked_chicken 6
