execute if score super_power events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Everyone received super power!","color":"gray"}]

execute if score super_power events matches 1 run effect give @a[gamemode=!spectator] speed 20 4
execute if score super_power events matches 1 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10
execute if score super_power events matches 8 run effect give @a[gamemode=!spectator] jump_boost 20 5
execute if score super_power events matches 8 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10
execute if score super_power events matches 16 run effect give @a[gamemode=!spectator] haste 20 4
execute if score super_power events matches 16 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10
execute if score super_power events matches 24 run effect give @a[gamemode=!spectator] strength 20 0
execute if score super_power events matches 24 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10
execute if score super_power events matches 32 run effect give @a[gamemode=!spectator] resistance 20 0
execute if score super_power events matches 32 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10
execute if score super_power events matches 40 run effect give @a[gamemode=!spectator] slow_falling 20 0
execute if score super_power events matches 40 at @a[gamemode=!spectator] run particle minecraft:crit ~ ~1 ~ 0.3 0.8 0.3 0 10


execute if score super_power events matches 40 run scoreboard players reset super_power events
execute if score super_power events matches 1.. run scoreboard players add super_power events 1
