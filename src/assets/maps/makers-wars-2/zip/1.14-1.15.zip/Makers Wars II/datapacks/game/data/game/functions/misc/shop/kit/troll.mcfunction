give @s slime_block 6
give @s wither_skeleton_skull 1
give @s soul_sand 3
give @s cobweb 9
give @s blue_ice 10
give @s lava_bucket
give @s fishing_rod
give @s flint_and_steel
give @s tnt 5
give @s oak_sign 5

give @s fire_coral_block 24
give @s rotten_flesh 10
give @s spider_eye 5
