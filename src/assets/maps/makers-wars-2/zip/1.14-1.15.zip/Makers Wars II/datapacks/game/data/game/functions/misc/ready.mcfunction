execute if score players var matches ..1 run tellraw @a [{"text":"You have to wait for more players to start the game! ","color":"red"}]
execute if score players var matches ..1 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000

execute if score players var matches 2.. if score teams var matches ..1 run tellraw @a [{"text":"You need at least two teams to start the game! ","color":"red"}]
execute if score players var matches 2.. if score teams var matches ..1 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000

execute if score players var matches 2.. if score teams var matches 2.. as @a[gamemode=adventure,team=] run scoreboard players set players var 0
execute if score players var matches 0 run tellraw @a [{"text":"Some players have to choose a team! ","color":"red"}]
execute if score players var matches 0 run playsound minecraft:entity.item.break master @a ~ ~ ~ 1000000

execute if score players var matches 2.. if score teams var matches 2.. run function game:misc/balance