give @s stone_pickaxe
give @s wooden_axe
give @s wooden_shovel
give @s stone_hoe
give @s oak_sapling 12
give @s chest{display:{Name:"{\"text\":\"Filled Chest\",\"color\":\"dark_green\",\"italic\":\"false\"}"},BlockEntityTag:{LootTable:"game:classic_chest"}} 2
give @s oak_log 8
give @s furnace 4
give @s fishing_rod
give @s coal_ore 12
give @s iron_ore 30
give @s lapis_ore 10
give @s gold_ore 16
give @s diamond_ore 15
give @s milk_bucket
give @s enchanting_table
give @s bone 10
give @s wolf_spawn_egg{EntityTag:{Tags:["new_spawned_mob"]}}
give @s chicken_spawn_egg 10
give @s cobweb 3
give @s obsidian 4
give @s ice 2
give @s wheat_seeds 8
give @s carrot 4
give @s bucket
give @s dirt 64
give @s gravel 32

give @s bread 20
