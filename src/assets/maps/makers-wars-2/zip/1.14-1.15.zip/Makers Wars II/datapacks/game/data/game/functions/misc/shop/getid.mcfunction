summon area_effect_cloud ~ ~ ~ {Tags:["raycast_shop_id","this"]}
tp @e[type=area_effect_cloud,tag=raycast_shop_id] @s
execute as @e[type=area_effect_cloud,tag=raycast_shop_id] at @s run tp @s ~ 122 ~ ~ ~
execute as @e[type=area_effect_cloud,tag=raycast_shop_id] at @s run function game:misc/shop/raycast
execute at @e[type=area_effect_cloud,tag=raycast_shop_id] if entity @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] store result score @s shop_id run data get entity @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] Rotation[1] 1
execute at @e[type=area_effect_cloud,tag=raycast_shop_id] if entity @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] store result score @s shop_cost run data get entity @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] Rotation[0] 1

execute if score @s shop_id matches 1.. unless entity @e[type=villager,tag=shop_click,tag=available] run summon villager 0 0 0 {NoAI:1,Tags:["shop_click","this"],ActiveEffects:[{Id:14,Amplifier:0,Duration:2147483647,ShowParticles:0b}],Silent:1,Invulnerable:1}
team join no_push @e[type=villager,tag=shop_click,tag=this]
execute if score @s shop_id matches 1.. at @s run tp @e[type=villager,tag=shop_click,tag=available,sort=nearest] ^ ^ ^1
execute if score @s shop_id matches 1.. at @s positioned ^ ^ ^1 run tag @e[type=villager,tag=shop_click,tag=available,sort=nearest,distance=..0.2,limit=1] remove available 

execute at @e[type=area_effect_cloud,tag=raycast_shop_id] at @e[tag=shop_id,type=area_effect_cloud,limit=1,sort=nearest,distance=..0.4] run particle minecraft:crit ~ ~.5 ~ .1 .1 .1 .1 10 normal @s
kill @e[tag=raycast_shop_id,tag=this]
tag @e[tag=this] remove this
