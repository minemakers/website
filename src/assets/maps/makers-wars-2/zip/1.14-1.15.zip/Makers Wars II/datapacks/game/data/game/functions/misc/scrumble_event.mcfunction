scoreboard players set #mod events 35

scoreboard players operation #seed events *= #a events
scoreboard players operation #seed events += #c events
execute if score #seed events matches ..-1 run scoreboard players operation #seed events *= #inv events
scoreboard players operation #result events = #seed events
scoreboard players operation #result events /= #b events
scoreboard players operation #result events %= #mod events

execute if score #result events matches 0 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.0 minecraft:dead_bush
execute if score #result events matches 1 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.1 minecraft:dead_bush
execute if score #result events matches 2 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.2 minecraft:dead_bush
execute if score #result events matches 3 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.3 minecraft:dead_bush
execute if score #result events matches 4 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.4 minecraft:dead_bush
execute if score #result events matches 5 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.5 minecraft:dead_bush
execute if score #result events matches 6 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.6 minecraft:dead_bush
execute if score #result events matches 7 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.7 minecraft:dead_bush
execute if score #result events matches 8 run replaceitem entity @r[gamemode=!spectator,limit=2] hotbar.8 minecraft:dead_bush

execute if score #result events matches 9 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.0 minecraft:dead_bush
execute if score #result events matches 10 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.1 minecraft:dead_bush
execute if score #result events matches 11 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.2 minecraft:dead_bush
execute if score #result events matches 12 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.3 minecraft:dead_bush
execute if score #result events matches 13 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.4 minecraft:dead_bush
execute if score #result events matches 14 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.5 minecraft:dead_bush
execute if score #result events matches 15 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.6 minecraft:dead_bush
execute if score #result events matches 16 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.7 minecraft:dead_bush
execute if score #result events matches 17 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.8 minecraft:dead_bush
execute if score #result events matches 18 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.9 minecraft:dead_bush
execute if score #result events matches 19 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.10 minecraft:dead_bush
execute if score #result events matches 20 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.11 minecraft:dead_bush
execute if score #result events matches 21 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.12 minecraft:dead_bush
execute if score #result events matches 22 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.13 minecraft:dead_bush
execute if score #result events matches 23 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.14 minecraft:dead_bush
execute if score #result events matches 24 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.15 minecraft:dead_bush
execute if score #result events matches 25 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.16 minecraft:dead_bush
execute if score #result events matches 26 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.17 minecraft:dead_bush
execute if score #result events matches 27 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.18 minecraft:dead_bush
execute if score #result events matches 28 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.19 minecraft:dead_bush
execute if score #result events matches 29 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.20 minecraft:dead_bush
execute if score #result events matches 30 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.21 minecraft:dead_bush
execute if score #result events matches 31 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.22 minecraft:dead_bush
execute if score #result events matches 32 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.23 minecraft:dead_bush
execute if score #result events matches 33 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.24 minecraft:dead_bush
execute if score #result events matches 34 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.25 minecraft:dead_bush
execute if score #result events matches 35 run replaceitem entity @r[gamemode=!spectator,limit=2] inventory.26 minecraft:dead_bush