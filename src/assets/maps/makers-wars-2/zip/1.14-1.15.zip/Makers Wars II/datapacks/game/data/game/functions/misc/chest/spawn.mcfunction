summon armor_stand 1032 150 1008 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 1019 150 1030 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 996 150 1043 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 973 150 1030 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 962 150 1008 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 973 150 985 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 996 150 973 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}
summon armor_stand 1019 150 985 {CustomName:"\"Spawn Chest\"",Tags:["start_chest","falling_chest"],ArmorItems:[{},{},{},{id:"minecraft:chest",Count:1b}],Invulnerable:1,Invisible:1,NoBasePlate:1}

playsound minecraft:entity.wither.spawn master @a 1000 100 1000 1000000 2