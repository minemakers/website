tp @s[team=p1] 1032 93.5 1008 facing 996.5 83 1008.5
tp @s[team=p2] 1019 93.5 1030 facing 996.5 83 1008.5
tp @s[team=p3] 996 93.5 1043 facing 996.5 83 1008.5
tp @s[team=p4] 973 93.5 1030 facing 996.5 83 1008.5
tp @s[team=p5] 962 93.5 1008 facing 996.5 83 1008.5
tp @s[team=p6] 973 93.5 985 facing 996.5 83 1008.5
tp @s[team=p7] 996 93.5 973 facing 996.5 83 1008.5
tp @s[team=p8] 1019 93.5 985 facing 996.5 83 1008.5

execute if score countdown var matches 67 run tellraw @a [{"text":"\nThe game will start in 60 seconds!","color":"gray"}]
execute if score countdown var matches 67 run scoreboard players set countdown var 66
