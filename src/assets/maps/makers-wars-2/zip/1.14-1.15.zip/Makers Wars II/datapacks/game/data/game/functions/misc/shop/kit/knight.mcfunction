give @s iron_sword
give @s shield
give @s golden_apple 2
give @s bricks 24
give @s cooked_beef 6