scoreboard players set #mod events 34

scoreboard players operation #seed events *= #a events
scoreboard players operation #seed events += #c events
execute if score #seed events matches ..-1 run scoreboard players operation #seed events *= #inv events
scoreboard players operation #result events = #seed events
scoreboard players operation #result events /= #b events
scoreboard players operation #result events %= #mod events


execute if score #result events matches 1..3 run scoreboard players set freeze events 1
execute if score #result events matches 4..5 run scoreboard players set creeper_rain events 1
execute if score #result events matches 6..6 run scoreboard players set wither events 1
execute if score #result events matches 7..8 run scoreboard players set scrambled_inv events 1
execute if score #result events matches 9..10 run scoreboard players set meteorites events 1
execute if score #result events matches 11..13 run scoreboard players set bad_effect events 1
execute if score #result events matches 14..15 run scoreboard players set cursed_area events 1
execute if score #result events matches 16..16 run scoreboard players set gift events 1
execute if score #result events matches 17..19 run scoreboard players set spread events 1
execute if score #result events matches 20..21 run scoreboard players set swap events 1
execute if score #result events matches 22..23 run scoreboard players set rebellion events 1
execute if score #result events matches 24..26 run scoreboard players set jump_boost events 1
execute if score #result events matches 27..28 run scoreboard players set gravity events 1
execute if score #result events matches 29..30 run scoreboard players set suicidal_mobs events 1
execute if score #result events matches 31..33 run scoreboard players set super_power events 1
execute if score #result events matches 34 run scoreboard players set resurrection events 1

scoreboard players set #mod events 30

scoreboard players operation #seed events *= #a events
scoreboard players operation #seed events += #c events
execute if score #seed events matches ..-1 run scoreboard players operation #seed events *= #inv events
scoreboard players operation #result events = #seed events
scoreboard players operation #result events /= #b events
scoreboard players operation #result events %= #mod events

scoreboard players set timer events 20
scoreboard players operation timer events += #result events