give @s diamond_sword
give @s shield
give @s minecraft:potion{display:{Name:"{\"text\":\"Fighter Potion\",\"color\":\"yellow\",\"italic\":false}"},CustomPotionEffects:[{Id:5b,Amplifier:0b,Duration:600},{Id:22b,Amplifier:0b,Duration:600},{Id:17b,Amplifier:1b,Duration:200}],CustomPotionColor:11733257}
give @s bow
give @s arrow 16
give @s iron_axe
give @s iron_pickaxe
give @s diamond_chestplate
give @s iron_boots

give @s chest{display:{Name:"{\"text\":\"Filled Chest\",\"color\":\"dark_green\",\"italic\":\"false\"}"},BlockEntityTag:{LootTable:"game:classic_chest"}} 2
give @s polished_andesite 48
give @s golden_apple 4
give @s cooked_beef 16
