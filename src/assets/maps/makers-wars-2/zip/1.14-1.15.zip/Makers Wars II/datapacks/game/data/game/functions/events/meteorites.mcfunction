execute if score meteorites events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"The sky is dark, meteorites are falling!","color":"gray"}]
execute if score meteorites events matches 1 run time set midnight
execute if score meteorites events matches 1 run weather thunder

execute if score meteorites events matches 1 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~
execute if score meteorites events matches 47 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~
execute if score meteorites events matches 72 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~
execute if score meteorites events matches 95 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~
execute if score meteorites events matches 120 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~
execute if score meteorites events matches 138 at @r[gamemode=!spectator,limit=1] run summon lightning_bolt ~ ~-9 ~

execute if score meteorites events matches 1 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 23 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 48 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 57 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 80 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 110 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 135 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}
execute if score meteorites events matches 165 at @r[gamemode=!spectator,limit=1] run summon fireball ~ ~50 ~ {direction:[0.0,-4.0,0.0],Tags:["meteorites_event"]}

execute if score meteorites events matches 1..180 at @e[type=fireball,tag=meteorites_event] run particle lava ~ ~ ~ 0 0 0 0.1 1 force @a

execute if score meteorites events matches 150 run weather clear
execute if score meteorites events matches 180 run time set noon
execute if score meteorites events matches 180 run kill @e[type=fireball,tag=meteorites_event]
execute if score meteorites events matches 180 run scoreboard players reset meteorites events
execute if score meteorites events matches 1.. run scoreboard players add meteorites events 1