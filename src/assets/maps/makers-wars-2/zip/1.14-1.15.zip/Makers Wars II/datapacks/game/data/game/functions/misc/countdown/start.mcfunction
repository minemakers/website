bossbar set game:shop_countdown players

function game:structure/destroy

tp @a[x=996,y=122,z=975,distance=..75,team=p1] 1032 93.5 1008 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p2] 1019 93.5 1030 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p3] 996 93.5 1043 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p4] 973 93.5 1030 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p5] 962 93.5 1008 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p6] 973 93.5 985 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p7] 996 93.5 973 facing 996.5 83 1008.5
tp @a[x=996,y=122,z=975,distance=..75,team=p8] 1019 93.5 985 facing 996.5 83 1008.5