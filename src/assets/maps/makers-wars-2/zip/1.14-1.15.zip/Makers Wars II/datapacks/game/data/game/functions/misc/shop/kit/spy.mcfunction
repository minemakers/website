give @s stone_sword
give @s bow
give @s minecraft:tipped_arrow{display:{Name:"{\"text\":\"Arrow of Blindness\",\"color\":\"yellow\",\"italic\":false}",Lore:["§cBlindness (0:12)","","§5When Applied:"," §c-15% Speed"]},HideFlags:34,CustomPotionEffects:[{Id:15b,Amplifier:1b,Duration:240}],CustomPotionColor:791682} 8
give @s minecraft:potion{display:{Name:"{\"text\":\"Spy Potion\",\"color\":\"yellow\",\"italic\":false}"},CustomPotionEffects:[{Id:1b,Amplifier:0b,Duration:1200},{Id:14b,Amplifier:0b,Duration:1200},{Id:22b,Amplifier:0b,Duration:200},{Id:28b,Amplifier:0b,Duration:160}],CustomPotionColor:4546303} 2
give @s minecraft:splash_potion{display:{Name:"{\"text\":\"Retreat Potion\",\"color\":\"yellow\",\"italic\":false}"},CustomPotionEffects:[{Id:1b,Amplifier:3b,Duration:60},{Id:14b,Amplifier:0b,Duration:200},{Id:8b,Amplifier:3b,Duration:60},{Id:28b,Amplifier:0b,Duration:120}],CustomPotionColor:1358489} 
give @s bat_spawn_egg{EntityTag:{Tags:["new_spawned_bat"]}} 8

give @s light_gray_concrete 8
give @s bread 12
