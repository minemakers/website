execute if score creeper_rain events matches 1 run tellraw @a [{"text":"Random Event: ","color":"green"},{"text":"Look up... Creeper Rain!","color":"gray"}]

execute if score creeper_rain events matches 1 run playsound minecraft:weather.rain.above master @a 1000 100 1000 10000 0.1
execute if score creeper_rain events matches 1 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}
execute if score creeper_rain events matches 17 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}
execute if score creeper_rain events matches 25 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}
execute if score creeper_rain events matches 40 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}
execute if score creeper_rain events matches 50 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}
execute if score creeper_rain events matches 72 run execute at @r[gamemode=!spectator] run summon creeper ~ ~40 ~ {Tags:["new","creeper_rain"],Fuse:40,ExplosionRadius:2,Attributes:[{Name:"generic.max_health",Base:1000}],ActiveEffects:[{Id:11,Amplifier:100,Duration:200,ShowParticles:false}]}


execute if score creeper_rain events matches 1..72 as @e[type=creeper,tag=new] at @s run playsound minecraft:entity.chicken.egg master @a ~ ~ ~ 100 1
execute if score creeper_rain events matches 1..72 as @e[type=creeper,tag=new] at @s run particle smoke ~ ~ ~ 0.3 0.3 0.3 0.1 100 force
execute if score creeper_rain events matches 1..72 run tag @e[type=creeper,tag=new] remove new

execute if score creeper_rain events matches 390 run execute at @e[tag=creeper_rain] run particle minecraft:cloud ~ ~1 ~ 0.2 0.8 0.2 0.1 6 normal
execute if score creeper_rain events matches 390 run execute at @e[tag=creeper_rain] run playsound minecraft:block.fire.extinguish ambient @a ~ ~ ~ 0.7 1.7
execute if score creeper_rain events matches 390 run tp @e[tag=creeper_rain] ~ -500 ~

execute if score creeper_rain events matches 390 run scoreboard players reset creeper_rain events
execute if score creeper_rain events matches 1.. run scoreboard players add creeper_rain events 1
