give @s stick{display:{Name:'{"text":"Fiery Stick","color":"yellow","italic":false}'},Enchantments:[{id:"sharpness",lvl:1},{id:"fire_aspect",lvl:1}]}
give @s brewing_stand 1
give @s nether_wart 32
give @s blaze_rod 2
give @s sugar 3
give @s glistering_melon_slice
give @s redstone 16
give @s golden_carrot 5
give @s glowstone 2
give @s ice 16
give @s glass_bottle 16
