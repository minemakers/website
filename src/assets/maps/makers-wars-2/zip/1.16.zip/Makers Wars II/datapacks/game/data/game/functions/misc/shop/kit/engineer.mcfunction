give @s stone_sword
give @s stone_axe
give @s spruce_wood 32
give @s arrow 16
give @s redstone_block 12
give @s repeater 10
give @s comparator 5
give @s water_bucket
give @s tnt 64
give @s flint_and_steel
give @s piston 5
give @s dispenser 6
give @s tripwire_hook 4
give @s cobweb 10
give @s fire_charge 64
give @s trapped_chest 2
give @s slime_block 5
give @s chest{display:{Name:'{"text":"Filled Chest","color":"dark_green","italic":false}'},BlockEntityTag:{LootTable:"game:classic_chest"}}
