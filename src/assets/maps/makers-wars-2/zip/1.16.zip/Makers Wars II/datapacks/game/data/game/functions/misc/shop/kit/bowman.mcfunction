give @s minecraft:bow{display:{Name:'{"text":"Power Bow","color":"yellow","italic":false}'},RepairCost:50,Enchantments:[{id:"minecraft:power",lvl:1}]}
give @s minecraft:bow{display:{Name:'{"text":"Punch Bow","color":"yellow","italic":false}'},RepairCost:50,Damage:381,Enchantments:[{id:"minecraft:punch",lvl:1}]}
give @s arrow 16
give @s spectral_arrow 4
give @s minecraft:tipped_arrow{display:{Name:'{"text":"Arrow of Mining Fatigue","color":"yellow","italic":false}',Lore:['{"text":"Mining Fatigue (0:08)","color":"red"}',"",'{"text":"When Applied:","color":"dark_purple"}','{"text":" -20% Attack Speed","color":"red"}']},HideFlags:34,CustomPotionEffects:[{Id:4b,Amplifier:1b,Duration:160}],CustomPotionColor:7366486} 2
give @s minecraft:tipped_arrow{display:{Name:'{"text":"Arrow of Slowness","color":"yellow","italic":false}',Lore:['{"text":"Slowness (0:10)","color":"red"}',"",'{"text":"When Applied:","color":"dark_purple"}','{"text":" -15% Speed","color":"red"}']},HideFlags:34,CustomPotionEffects:[{Id:2b,Amplifier:1b,Duration:200}],CustomPotionColor:6520534} 2

give @s oak_leaves 20
give @s cooked_rabbit 8
