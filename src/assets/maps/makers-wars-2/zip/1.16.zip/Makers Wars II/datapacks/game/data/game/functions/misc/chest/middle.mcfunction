execute if score arena var matches 1 run summon area_effect_cloud 995 85 1008 {Tags:["middle_chest"],CustomName:'"Plains Middle Chest"'}
execute if score arena var matches 1 run summon area_effect_cloud 997 86 1009 {Tags:["middle_chest"],CustomName:'"Plains Middle Chest"'}

execute if score arena var matches 2 run summon area_effect_cloud 997 87 1009 {Tags:["middle_chest"],CustomName:'"Ruins Middle Chest"'}
execute if score arena var matches 2 run summon area_effect_cloud 996 93 1008 {Tags:["middle_chest"],CustomName:'"Ruins Middle Chest"'}

execute if score arena var matches 3 run summon area_effect_cloud 996 85 1008 {Tags:["middle_chest"],CustomName:'"Desert Middle Chest"'}
execute if score arena var matches 3 run summon area_effect_cloud 996 90 1008 {Tags:["middle_chest"],CustomName:'"Desert Middle Chest"'}

execute if score arena var matches 4 run summon area_effect_cloud 999 85 1008 {Tags:["middle_chest"],CustomName:'"Nether Middle Chest"'}
execute if score arena var matches 4 run summon area_effect_cloud 995 91 1008 {Tags:["middle_chest"],CustomName:'"Nether Middle Chest"'}

execute if score arena var matches 5 run summon area_effect_cloud 996 90 1008 {Tags:["middle_chest"],CustomName:'"End Middle Chest"'}
execute if score arena var matches 5 run summon area_effect_cloud 997 86 1009 {Tags:["middle_chest"],CustomName:'"End Middle Chest"'}

execute if score arena var matches 6 run summon area_effect_cloud 1000 80 1003 {Tags:["middle_chest"],CustomName:'"Canyon Middle Chest"'}
execute if score arena var matches 6 run summon area_effect_cloud 992 80 1011 {Tags:["middle_chest"],CustomName:'"Canyon Middle Chest"'}
execute if score arena var matches 6 run summon area_effect_cloud 996 93 1008 {Tags:["middle_chest"],CustomName:'"Canyon Middle Chest"'}

execute if score arena var matches 7 run summon area_effect_cloud 996 74 1008 {Tags:["middle_chest"],CustomName:'"Winter Middle Chest"'}
execute if score arena var matches 7 run summon area_effect_cloud 997 89 1007 {Tags:["middle_chest"],CustomName:'"Winter Middle Chest"'}
execute if score arena var matches 7 run summon area_effect_cloud 994 88 1011 {Tags:["middle_chest"],CustomName:'"Winter Middle Chest"'}
execute if score arena var matches 7 run summon area_effect_cloud 981 72 1010 {Tags:["middle_chest"],CustomName:'"Winter Middle Chest"'}
execute if score arena var matches 7 run summon area_effect_cloud 1011 72 1010 {Tags:["middle_chest"],CustomName:'"Winter Middle Chest"'}

execute if score arena var matches 8 run summon area_effect_cloud 995 93 1011 {Tags:["middle_chest"],CustomName:'"Tower Middle Chest"'}
execute if score arena var matches 8 run summon area_effect_cloud 1001 78 1011 {Tags:["middle_chest"],CustomName:'"Tower Middle Chest"'}
execute if score arena var matches 8 run summon area_effect_cloud 992 104 1011 {Tags:["middle_chest"],CustomName:'"Tower Middle Chest"'}

execute if score arena var matches 9 run summon area_effect_cloud 999 85 1026 {Tags:["middle_chest"],CustomName:'"Village Middle Chest"'}
execute if score arena var matches 9 run summon area_effect_cloud 979 85 1008 {Tags:["middle_chest"],CustomName:'"Village Middle Chest"'}
execute if score arena var matches 9 run summon area_effect_cloud 997 85 993 {Tags:["middle_chest"],CustomName:'"Village Middle Chest"'}
execute if score arena var matches 9 run summon area_effect_cloud 1013 83 1008 {Tags:["middle_chest"],CustomName:'"Village Middle Chest"'}
execute if score arena var matches 9 run summon area_effect_cloud 996 82 1008 {Tags:["middle_chest"],CustomName:'"Village Middle Chest"'}

execute as @e[type=area_effect_cloud,tag=middle_chest] at @s run function game:misc/chest/create

playsound minecraft:entity.wither.spawn master @a 1000 100 1000 1000000 2
give @a[gamemode=survival] minecraft:clay 64
